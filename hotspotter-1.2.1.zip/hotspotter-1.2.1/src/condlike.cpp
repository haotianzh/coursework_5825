/**
 * @file   condlike.cpp
 * @author Michael Na Li
 * @date   Thu Mar 28 00:16:17 2002
 *
 * @brief  Implementation of condlike.hpp
 *
 * $Id: condlike.cpp,v 1.23 2003/02/05 21:52:29 nali Exp $
 */

#include "condlike.hpp"
#include <numeric>

// {{{ class HapLikelihood

dbg::dbg_source HapLikelihood::dbgsrc = "condlike";

double
HapLikelihood::logL (const RecombRate *pR)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    if (nsites_ != 1) {
        idx_ = indices_.begin ();
        for (int i = 0; i < loglike_.size (); ++i, ++idx_) {
            loglike_[i] = 0.0;
            // calculate conditional probabilities
            for (int n = 1; n < hap_.size (); ++n) {
                loglike_[i] += log (this->cond_prob (n, pR));
                dbg::out (dbg::tracing, dbgsrc) << "Accumulated condlike "
                                                << "for order " << i << " = " 
                                                << loglike_[i] << std::endl;
            }
        }
    } else {
        std::cerr << "There are less than 2 sites. Skip." << std::endl;
    }

    return combine_loglike ();
}

double
HapLikelihood::combine_loglike( ) const
{  
    double ave = loglike_[0];
    for (int i = 1; i < loglike_.size (); ++i) {
        if (aveLike_) {
            ave = MLL::add_log (ave, loglike_[i]); // add on non-log scale
        } else {
            ave += loglike_[i];                    // adding on log scale
        }
    }
    if (aveLike_) {
        ave -= log (loglike_.size ());
    } else {
        ave /= loglike_.size ();
    }
    return ave;
}

// }}}

// {{{ class SDLikelihood

double
SDLikelihood::cond_prob (int n, const RecombRate *pR)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    int ctype = allele (n, 0);
    int anstype = 0;
    for (int s = 0; s < n; ++s) {
        probyx_[nsites () - 1][s] = 1.0;
    }

    // Locus  ns - 2, ..., 1
    // Baum-Welch backward algorithm
    double qi = 0.0;
    for (int i = nsites () - 2; i >= 0; --i) {
        int i1 = i + 1;
        ctype = allele (n, i1);
        qi = rrate_m (adj_rate (pR->rate (i)), n);
        if (isnan (qi)) {
            dbg::out(dbg::error, dbgsrc) << "qi is not a number!"
                                         << std::endl;
        }
        dbg::out (dbg::tracing, dbgsrc) << "interval: " << i
                                        << ", n = " << n
                                        << ", rate = " << pR->rate (i)
                                        << ", rrate = "
                                        << rrate_m (pR->rate (i), n)
                                        << "\tqi = " << qi << std::endl;
        double tmpp (0.0);
        for (int s1 = 0; s1 < n; ++s1) {  // x_{i+1}
            anstype = allele(s1, i1);
            tmpp += probyx_[i1][s1] * Q.prob_mut (ctype, anstype, n);
        }
        tmpp *= qi / n;
        for (int s = 0; s < n; ++s) {
            probyx_[i][s] = probyx_[i1][s] *
                Q.prob_mut (ctype, allele (s, i1), n) * (1.0 - qi) + tmpp;
            dbg::out (dbg::tracing, dbgsrc) << "probyx_[" << i << "][" << s
                                            << "] = " << probyx_[i][s]
                                            << std::endl;
        }
    }
    // Likelihood of the data, sum over all states of X_0

    // assume equal probabilities
    double prob_y = 0.0;
    ctype = allele (n, 0);
    for (int s = 0; s < n; ++s) {
        anstype = allele (s, 0);
        prob_y += probyx_[0][s] * Q.prob_mut (ctype, anstype, n);
    }
    dbg::out (dbg::tracing, dbgsrc) << "cond_prob: "
                                    << prob_y / n << std::endl;
    return prob_y / n;
}

// }}} SDLikelihood

// {{{ class FDLikelihood

double
FDLikelihood::cond_prob (int n, const RecombRate *pR)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    double sumw (0.0);
    for (int q = 0; q < Q.quad.n (); ++q) {
        sumw += Q.quad.w (q);
    }
    sumw /= n;
    for (int s = 0; s < n; ++s) {
        for (int q = 0; q < Q.quad.n (); ++q) {
            probyx_[0][s][q] = sumw *
                Q.prob_mut (allele (n, 0), allele (s, 0), n, q);
        }
    }

    for (int i = 0; i < nsites () - 1; ++i) {
        double temppi = 0.0;                                // p_i (\alpha)
        for (int t1 = 0; t1 < Q.quad.n (); ++t1) {
            double sum_s (0.0);
            for (int s1 = 0; s1 < n; ++s1) {
                // w_m * p_i (alpha | s1, t_m) / n
                sum_s += probyx_[i][s1][t1];
            }
            temppi += Q.quad.w (t1) * sum_s;
        }
        temppi /= n;

        int i1 = i + 1;
        int an = allele (n, i1);
        // FD's probability of recombination
        double qi = adj_rate (rrate_nm (pR->rate (i), n));
        for (int s = 0; s < n; ++s) {
            int as = allele (s, i1);                        // H_s_{i+1}
            for (int t = 0; t < Q.quad.n (); ++t) {
                probyx_[i1][s][t] = (1.0 - qi) * probyx_[i][s][t];
                probyx_[i1][s][t] += qi * temppi;
                // Q_{H_s_{i+1}}_{\alpha_{i+1}} (t_m / j)
                probyx_[i1][s][t] *= Q.prob_mut (as, an, n, t);
            }
        }
    }

    // Likelihood of the data, sum over all states of X_0
    // assume equal probabilities
    double prob_y = 0.0;
    for (int s = 0; s < n; ++s) {
        for (int t = 0; t < Q.quad.n (); ++t) {
            prob_y += Q.quad.w (t) * probyx_[nsites () - 1][s][t];
        }
    }
    return prob_y / n;
}

// }}}

double
mean_i (const RecombRate *pR, int i, int sm, double s2k)
{
    dbg::trace dtrace ("mean_i", DBG_HERE);
    double mu (0.0);
    double tweights (0.0);
    // compute the area under the Gaussian kernel for each interval
    std::vector<double> areas (pR->size () + 1);
    // Center of current interval (mean of the Gaussian smooth kernel)
    double center = 0.5 * (pR->mappos (i + 1) + pR->mappos (i));
    switch (sm) {
    case 1 :
    case 2 :
        if (i == 0) {
            mu = log10 (pR->rhos() [i + 1]);
        } else if (i == pR->size () - 1) {
            mu = log10 (pR->rhos() [i - 1]);
        } else {
            double dist1 = pR->mapdist ()[i + 1];
            double dist2 = pR->mapdist ()[i - 1];
            mu = (dist1 * log10 (pR->rhos () [i + 1]) +
                  dist2 * log10 (pR->rhos () [i - 1])) / (dist1 + dist2);
        }
        break;
    case 3 :
        for (int j = 0; j < pR->size (); ++j) {
            // areas[i] = Pr (X > pos[i])
            areas[j] = MLL::pnorm (pR->mappos (j), center, s2k);
        }
        // now compute areas[j] = areas[j] - areas[j-1]
        std::adjacent_difference (areas.begin (), areas.end (),
                                  areas.begin ());
        // Now areas[j] (j > 0) is the area between sites j and j - 1
        for (int j = 1; j < pR->size (); ++j) {
            if (j != i) {            // excluding the current interval
                mu += areas[j] * log10 (pR->rhos() [j-1]);
                tweights += areas[j];
            }
        }
        mu /= tweights;
        break;
    default :
        mu = log10 (pR->rhos()[i]);
        break;
    }
    return mu;
}

double calc_sigma2 (const RecombRate *pR, int sm, double s2)
{
    dbg::trace dtrace ("calc_sigma2", DBG_HERE);
    double mu (0.0);
    double res2 (0.0);
    for (int i = 0; i < pR->size (); ++i) {
        mu = log10 (pR->rhos ()[i]) - mean_i (pR, i, sm, s2);
        res2 += mu * mu;
    }
    return res2 / (pR->size () - 1.0);
}

// {{{ Log
/*
 *  $Log: condlike.cpp,v $
 *  Revision 1.23  2003/02/05 21:52:29  nali
 *  combline_loglike () added in HapLikelihood
 *
 *  Revision 1.22  2003/02/05 21:30:53  nali
 *  Use loglike_ as a class member instead of local variable in logL.
 *
 *  Revision 1.21  2003/02/04 10:23:22  nali
 *  Clean up a bit.
 *
 *  Revision 1.20  2002/12/02 09:07:26  nali
 *  Added 3pt correction
 *
 *  Revision 1.19  2002/11/27 09:37:39  nali
 *  Added adapt_coef() for super-dupe correction.
 *
 *  Revision 1.18  2002/10/31 21:27:41  nali
 *  Minor update.
 *
 *  Revision 1.17  2002/09/20 08:52:46  nali
 *  some dbg statements added
 *
 *  Revision 1.16  2002/09/14 23:20:02  nali
 *  Got the correction wrong.
 *
 *  Revision 1.15  2002/09/14 03:04:08  nali
 *  Added #ifdef DBG_ENABLED guard around dbg::out
 *
 *  Revision 1.14  2002/09/14 00:11:42  nali
 *  Fixed the bug introduced with adjust_rate, don't do anything if
 *  rate == 0.0.
 *
 *  Also uses dbgsrc everywhere to better control dbg info.
 *
 *  Revision 1.13  2002/09/13 05:18:51  nali
 *  Added aveL and aveLogL as options, added function adjust_rate.
 *
 *  Revision 1.12  2002/09/12 03:42:02  nali
 *
 *  Fixed a bug, after ave = log (sum (exp (x))), should - log (n) to get
 *  the average instead of / n.
 *
 *  Revision 1.11  2002/09/02 08:19:41  nali
 *  allow adjust or not adjust
 *
 *  Revision 1.10  2002/08/20 07:17:02  nali
 *  resurrect FDLikelihood
 *
 *  Revision 1.9  2002/08/20 05:11:13  nali
 *  added new constructors with indices matrix.
 *
 *  Revision 1.8  2002/07/16 06:58:44  nali
 *  FIXED: wrap #ifdef DBG_ENABLED ... #endif around dbg::out.
 *
 *  Revision 1.7  2002/07/16 06:52:22  nali
 *  REMOVED: old junk code (FDLikelihood).
 *
 *  FIXED: a bug when the rate is zero (two adjacent sites
 *  have zero distance, it happens with simulated data when
 *  the number of segregating sites is large compared with
 *  the total number of sites, 100 versus 5000), pow (rate * 0.2)
 *  is NaN.
 *
 *  Revision 1.6  2002/05/07 07:56:11  nali
 *  removed member RecombRate *pR, have logL (pR)
 *
 *  Revision 1.5  2002/04/23 17:00:13  nali
 *
 *  Pointer to RecombRate as a member, and all data of HapLikelihood
 *  become private.  Several functions were defined to access them.
 *
 *  Revision 1.4  2002/04/09 00:04:41  nali
 *
 *  Now the MutationSimple::prob_mut has argument n.
 *
 *  Revision 1.3  2002/04/08 21:16:48  nali
 *  Disintegrate rate () and SD versus FD, so all four
 *  combinations of mutation and recombination models
 *  are available at run time.
 *
 *  Revision 1.2  2002/04/05 18:31:29  nali
 *
 *  1.  Modified the original SD method to use a faster
 *      algorithm (O(n)).
 *  2.  Fixed a bug in FD's algorithm, namely the initial
 *      values for probxy_[0].
 *
 *  Revision 1.1  2002/03/28 19:16:15  nali
 *  Move some code to .cpp files
 *
 */
// }}}























































































































































