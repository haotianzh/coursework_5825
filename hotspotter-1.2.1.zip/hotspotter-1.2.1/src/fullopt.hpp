/**
 * @file fullopt.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   Thu, 28 Mar 2002 00:33:32 -0800
 *
 * @brief  Maximize the likelihood for all rho_i's jointly.
 *
 *
 * $Id: fullopt.hpp,v 1.28.2.1 2003/03/08 07:21:44 nali Exp $
 **/
#ifndef FULLOPT_HPP
#define FULLOPT_HPP

#include "condlike.hpp"

#include "stat/distr.hpp"
#include "tnt/tnt.hpp"
#include "tnt/vec.hpp"
#include "tnt/cmat.hpp"

#include <valarray>

const int TRUNC = 6;
const double NEG_INFINITY = -1e10;

class HapFullOptNR
{
public :
    typedef std::vector<double> state_type;

    HapFullOptNR (HapLikelihood * phaplogL, RecombRate *pR)
        : pR_ (pR), phaplogL_ (phaplogL), neval_ (0)
    { }

    virtual ~HapFullOptNR ()
    { }

    virtual double operator () (const state_type & logrhos)
    {
        ++neval_;
        pR_->update_rate (logrhos, true);
        double neglike = - phaplogL_->logL (pR_);
        return neglike;
    }

    template <typename ForwardIteratr>
    double logprob  (ForwardIteratr logb, ForwardIteratr loge)
    {
        ++neval_;
        pR_->update_rate (logb, loge, true);
        return - phaplogL_->logL (pR_);
    }

    virtual double logprob (double rho, int i)
    {
        double oldrho = pR_->rhos ()[i];
        pR_->update_rate (rho, i);
        double like = phaplogL_->logL (pR_);
        pR_->update_rate (oldrho, i);
        return like;
    }

    virtual int operator () () const
    {
        return neval_;
    }

protected :
    RecombRate *pR_;

private :
    HapLikelihood * phaplogL_;
    int neval_;
};

class HapRhoSmoothed : public HapFullOptNR
{
public :
    HapRhoSmoothed (HapLikelihood * phaplogL, RecombRate *pR,
                    double sigma)
        : HapFullOptNR (phaplogL, pR), mu_ (0.0), sigma_ (sigma)
    {
        dbg::assertion (DBG_ASSERTION (sigma > 0.0));
        std::cout << "\tSigma = " << sigma_ << "\n" << std::endl;
    }

    virtual ~HapRhoSmoothed ()
    { }

    virtual double operator () (const HapFullOptNR::state_type & logrhos)
    {
        dbg::trace d_trace (DBG_HERE);
        // The likelihood
        mu_ = logrhos.back ();
        double neglike = HapFullOptNR::logprob (logrhos.begin (),
                                                logrhos.end () - 1);
        // "Prior" probability
        double negprior = 0.0;
        for (int i = 0; i < pR_->size (); ++i) {
            negprior -= logPprior (i);
        }
        return neglike + negprior;
    }

    virtual double logprob (double rho, int i)
    {
        return HapFullOptNR::logprob (rho, i) + logPprior (log (rho), i);
    }

private :
    double mu_;
    double sigma_;

    double mean (int i) const
    {
//         double mu;
//         if (i == 0) {
//             mu = log (pR_->rhos() [i + 1]);
//         } else if (i == pR_->size () - 1) {
//             mu = log (pR_->rhos() [i - 1]);
//         } else {
//             double dist1 = pR_->mapdist ()[i + 1];
//             double dist2 = pR_->mapdist ()[i - 1];
//             mu = (dist1 * log (pR_->rhos () [i + 1]) +
//                   dist2 * log (pR_->rhos () [i - 1])) / (dist1 + dist2);
//         }
        return mu_;
    }

    double sigma (int i) const
    {
//         double d = pR_->mapdist ()[i];
//         double dp1 = 0.0;
//         double dm1 = 0.0;
//         if (i < pR_->size () - 1) {
//             dp1 = pR_->mapdist ()[i + 1];
//         }
//         if (i > 0) {
//             dm1 = pR_->mapdist ()[i - 1];
//         }
//         return sqrt (2.0 * d / (dp1 + dm1)) * sigma_;
        return sigma_;
    }

    double logPprior (int i) const
    {
        double logrho = log (pR_->rhos ()[i]);
        return logPprior (logrho, i);
    }

    double logPprior (double logrho, int i) const
    {
        double prior = 0.0;
        if (std::abs (logrho - mean (i)) < TRUNC * sigma (i)) {
            prior = MLL::logdnorm (logrho, mean (i), sigma (i));
        } else {
            // -infinity
            prior = NEG_INFINITY;
        }
        return prior;
    }
};

class HapRhoSmoothedTwoStep : public HapFullOptNR
{
public :
    HapRhoSmoothedTwoStep (HapLikelihood * phaplogL, RecombRate *pR,
                           double mu, double sigma)
        : HapFullOptNR (phaplogL, pR), mu_ (mu), sigma_ (sigma)
    {
        dbg::assertion (DBG_ASSERTION (sigma_ > 0.0));
        std::cout << "mu = " << mu_
                  << "\tSigma = " << sigma_ << "\n" << std::endl;
    }

    virtual ~HapRhoSmoothedTwoStep ()
    { }

    virtual double operator () (const HapFullOptNR::state_type & logrhos)
    {
        dbg::trace d_trace (DBG_HERE);
        // The likelihood
        double neglike = HapFullOptNR::operator () (logrhos);
        // "Prior" probability
        double negprior = 0.0;
        for (int i = 0; i < pR_->size (); ++i) {
            negprior -= logPprior (i);
        }
        return neglike + negprior;
    }

    virtual double logprob (double rho, int i)
    {
        return HapFullOptNR::logprob (rho, i) + logPprior (log (rho), i);
    }

private :
    double mu_;
    double sigma_;

    double logPprior (int i) const
    {
        double logrho = log (pR_->rhos ()[i]);
        return logPprior (logrho, i);
    }

    double logPprior (double logrho, int i) const
    {
        double prior = 0.0;
        if (std::abs (logrho - mu_) < TRUNC * sigma_) {
            prior = MLL::logdnorm (logrho, mu_, sigma_);
        } else {
            // -infinity
            prior = NEG_INFINITY;
        }
        return prior;
    }
};

class HapRhoGammaPrior : public HapFullOptNR
{
public :
    HapRhoGammaPrior (HapLikelihood * phaplogL, RecombRate *pR,
                 double alpha, double beta)
        : HapFullOptNR (phaplogL, pR), a_ (alpha), b_ (beta)
    {
#ifdef DBG_ENABLED
        dbg::out (dbg::info) << "shape = " << a_ << "\t"
                             << "scale = " << b_ << "\n";
#endif
    }

    ~HapRhoGammaPrior ()
    { }

    double operator () (const HapFullOptNR::state_type & params)
    {
        dbg::trace d_trace (DBG_HERE);
        // The likelihood
#ifdef DBG_ENABLED
        dbg::out (dbg::tracing) << "params = ";
        for (int i = 0; i < params.size (); ++i) {
            dbg::out (dbg::tracing) << params[i] << " ";
        }
        dbg::out (dbg::tracing) << std::endl;
#endif
        double like = HapFullOptNR::logprob (params.begin (), params.end ());
        // "Prior" probability
        double prior = 0.0;
        for (int i = 0; i < pR_->size (); ++i) {
            double di = pR_->mapdist ()[i];
            prior += MLL::logdgamma (exp (params[i]), a_ * di, b_ / di);
        }
#ifdef DBG_ENABLED
        dbg::out (dbg::tracing) << dbg::indent ()
                                << " log (Pr (rho|alpha, beta)) = "
                                << - prior << std::endl;
#endif
        return like + prior;
    }

    int operator () () const
    {
        return HapFullOptNR::operator () ();
    }
private :
    double a_;
    double b_;
};

class LikeSolve
{
public:
    LikeSolve (HapFullOptNR *pfull, int interval, double loglike)
        : pfull_ (pfull), i_ (interval), loglike_ (loglike)
    {}

    double operator () (double newrho)
    {
        return pfull_->logprob (newrho, i_) - loglike_;
    }

private:
    HapFullOptNR *pfull_;
    int i_;
    double loglike_;
};

#endif // FULLOPT_HPP

// {{{ Log
/*
 *  $Log: fullopt.hpp,v $
 *  Revision 1.28.2.1  2003/03/08 07:21:44  nali
 *  reincarcinate two-step optimization
 *
 *  Revision 1.28  2002/11/27 11:04:36  nali
 *  Optimize over both rhobar and rho_i's.
 *  Use _aux.cpp code.
 *
 *  Revision 1.27  2002/10/21 20:59:46  nali
 *  Define TRUNC = 6 and use prior even in maximizing
 *  rho_i's.
 *
 *  Revision 1.26  2002/09/14 03:04:08  nali
 *  Added #ifdef DBG_ENABLED guard around dbg::out
 *
 *  Revision 1.25  2002/07/16 00:40:55  nali
 *  Prepare for distribution.
 *
 *  Revision 1.24  2002/07/08 04:16:20  nali
 *  Updated per changes in mll (dbg.h -> dbg.hpp, use of libmll.a,
 *  etc.
 *
 *  Revision 1.23  2002/05/22 19:20:35  nali
 *  print info at HapRHoSmoothed ()
 *
 *  Revision 1.22  2002/05/20 08:38:10  nali
 *  back to regression to the mean
 *
 *  Revision 1.21  2002/05/19 06:39:54  nali
 *  try spatial smoothing
 *
 *  Revision 1.20  2002/05/16 05:55:26  nali
 *  use simple N(mu, sigma^2) prior
 *
 *  Revision 1.19  2002/05/15 08:35:35  nali
 *  new sigma
 *
 *  Revision 1.18  2002/05/14 20:37:41  nali
 *  Add normal smoothing again
 *
 *  Revision 1.17  2002/05/14 16:56:24  nali
 *  another (last) try for gamma model
 *
 *  Revision 1.16  2002/05/13 22:45:33  nali
 *  commented out smoothing
 *
 *  Revision 1.15  2002/05/13 17:25:31  nali
 *  remove alpha & beta from maximization
 *
 *  Revision 1.14  2002/05/11 05:55:44  nali
 *  reverted to (log)dgamma
 *
 *  Revision 1.13  2002/05/10 17:05:25  nali
 *
 *  Implement Gamma prior for rho.  Joint maximize the likelihood
 *  for alpha, beta and all rho_i's.  Still getting 0 and Inf for
 *  alpha and beta.  Pending further investigating.
 *
 *  Revision 1.12  2002/05/09 17:45:22  nali
 *  implementing gamma prior for recombination rates
 *
 *  Revision 1.11  2002/05/09 05:52:41  nali
 *  updated
 *
 *  Revision 1.10  2002/05/07 07:58:23  nali
 *  Updated
 *
 *  Revision 1.9  2002/05/03 00:10:54  nali
 *  clean up stuff
 *
 *  Revision 1.8  2002/05/02 05:50:59  nali
 *  not ready yet
 *
 *  Revision 1.7  2002/04/23 17:00:55  nali
 *  Updated in response to changes in recomb.hpp and condlike.hpp
 *
 *  Revision 1.6  2002/03/28 19:20:38  nali
 *
 *  Updated with new HapLikelihood classes.  Use
 *  a HapLikelihood * to take advantage of the
 *  polymorphism.
 *
 */
// }}}
