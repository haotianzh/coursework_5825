/*
 * Class Haplotype
 *
 * $Id: haplotype.hpp,v 1.24 2003/02/05 19:42:48 nali Exp $
 */

#ifndef HAPLOTYPE_CLASS_H_
#define HAPLOTYPE_CLASS_H_

#include <vector>
#include <algorithm>
#include <string>
#include <iostream>

#include <cassert>
#include <cmath>

#include "tnt/tnt.hpp"
#include "tnt/vec.hpp"
#include "tnt/cmat.hpp"
#include "dbg/dbg.hpp"

//*
class ClassHaplotype
{
public:

    //* Default constructor, do nothing
    ClassHaplotype ();

    //* Constructor, read in the data file
    ClassHaplotype (std::istream &, int format, int = 0, int = 0);

    ClassHaplotype (const std::vector<double> & mp);

    //* Returns the total number of haplotypes
    int size () const;

    //* Return the total number of segregating loci
    int get_nlocus () const;

    //* Returns one haplotype as a vector
    const std::vector<int>& operator[] (int) const;

    //* Return the distance between locus j and j+1, j = 0, ..., J-1
    double get_dist (int) const;

    //* Return the position of locus j
    double map_pos (int) const;
    //* return the map
    const std::vector<double> & map_pos () const;

    //* Get the number of nonsegregation sites
    int get_nonseg () const;

    /**
     * Calculate the minimal segregrating sites between H_n and
     * H_1, ..., H_{n-1}
     */
    int get_minmut (int, const std::vector<int> &) const;

    /**
     * Count the new mutations
     */
    int get_newmut (int, const std::vector<int> &) const;

    //* Read in data from a file
    int read_data (std::istream & = std::cin, int = 0, int = 0, int = 0);

    //
    //* push in haplotypes
    int push (const std::vector<int> & hap);


    template <typename RandomNumberGenerator>
    void permute_label (RandomNumberGenerator & rand)
    {
        std::random_shuffle (is_affected_.begin (),
                             is_affected_.end (), rand);
    }

    const std::vector<bool> & affected () const
    {
        return is_affected_;
    }
    std::vector<bool> & affected ()
    {
        return is_affected_;
    }
protected:

    int nlocus;        //!* Number of loci
    int nhap;          //!* Number of haplotypes

    std::vector<double> mappos;
    std::vector<std::vector<int> > haplotype;
    std::vector<bool> is_affected_;

    int n_nonseg; // Number of non-segragation sites

    // Convert a character to integer allele: '0' -> 0, '1' -> 1, else 2
    // (missing)
    int char2allele (char);
};

// {{{ Inline functions

inline
ClassHaplotype::ClassHaplotype ()
{}

inline
ClassHaplotype::ClassHaplotype (std::istream & istr, int format,
                                int hapnum, int sites)
{
    read_data (istr, format, hapnum, sites);
}

inline
ClassHaplotype::ClassHaplotype (const std::vector<double> & mp)
    : nlocus (mp.size ()), nhap (0), mappos (mp),
      haplotype (), n_nonseg (0)
{}

inline int
ClassHaplotype::size () const
{
    return nhap;
}

inline int
ClassHaplotype::get_nlocus () const
{
    return nlocus;
}

inline const std::vector<int>&
ClassHaplotype::operator[] (int index) const
{
    return haplotype[index];
}

inline double
ClassHaplotype::get_dist (int j) const
{
    return mappos[j+1] - mappos[j];
}

inline double
ClassHaplotype::map_pos (int j) const
{
    return mappos[j];
}

inline const std::vector<double> &
ClassHaplotype::map_pos () const
{
    return mappos;
}

inline int
ClassHaplotype::get_nonseg () const
{
    return n_nonseg;
}

inline int
ClassHaplotype::push (const std::vector<int> & hap)
{
    dbg::assertion (DBG_ASSERTION (hap.size () == nlocus));
    haplotype.push_back (hap);
    return ++nhap;
}

inline int
ClassHaplotype::char2allele( char c )
{
    return c == '0' ? 0 : (c == '1' ? 1 : 2);
}

// }}}

#endif // HAPLOTYPE_CLASS_H_
