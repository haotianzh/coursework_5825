//
// $Id: popdefs.hpp,v 1.4 2002/02/21 11:04:24 nali Exp $
//

#ifndef POPREC_TYPEDEFS_HPP
#define POPREC_TYPEDEFS_HPP

#include "tnt/tnt.hpp"
#include "tnt/vec.hpp"
#include "tnt/cmat.hpp"

typedef std::vector<ClassHaplotype *> VecPHap;
typedef VecPHap::iterator i_VecPHap;
typedef VecPHap::const_iterator ci_VecPHap;

typedef std::vector<std::vector<int> *> VVecPInt;
typedef VVecPInt::iterator i_VVecPInti;
typedef VVecPInt::const_iterator ci_VVecPInti;

typedef TNT::Matrix<double> DblMat;
typedef std::vector<DblMat> VecDblMat;

#endif // POPREC_TYPEDEFS_HPP
