/**
 * @file   condlike.hpp
 * @author Michael Na Li
 * @date   Thu Mar 28 00:22:53 2002
 *
 * @brief  Classes for computing the likelihood for rho
 *
 * $Id: condlike.hpp,v 1.39 2003/02/05 21:52:29 nali Exp $
 */

#ifndef CONDLIKE_HPP
#define CONDLIKE_HPP

#include "hotspotter.hpp"

#include "recomb.hpp"
#include "mutat.hpp"
#include "stat/sfunc.hpp"
#include "dbg/dbg.hpp"

#include <valarray>

double mean_i (const RecombRate *, int i, int sm, double s2k);

double calc_sigma2 (const RecombRate *, int, double);

class HapLikelihood
{
public:

    static dbg::dbg_source dbgsrc;

    typedef std::vector<std::vector<int> > vvint_type;
    typedef std::vector<std::vector<int> >::const_iterator vvint_citer;
    typedef std::vector<std::vector<int> >::iterator vvint_iter;

    template <typename RandomNumberGenerator>
    HapLikelihood (const ClassHaplotype  & hap,
                   RandomNumberGenerator & rand,
                   int norder,
                   bool adjust,
                   bool aveLike)
        : hap_ (hap),
          indices_ (norder, std::vector<int> (hap.size ())),
          loglike_ (0.0, indices_.size ()),
          nsites_ (hap_.get_nlocus ()),
          adjust_ (adjust),
          aveLike_ (aveLike)
    {
        MLL::arange_n (indices_[0].begin (), indices_[0].end (), 0, 1);
        for (int i = 1; i < indices_.size (); ++i) {
            std::copy (indices_[0].begin (), indices_[0].end (),
                       indices_[i].begin ());
        }
        idx_ = indices_.begin ();
        for (vvint_iter j = indices_.begin (); j != indices_.end (); ++j) {
            std::random_shuffle (j->begin (), j->end (), rand);
            for (std::vector<int>::const_iterator i = j->begin ();
                 i != j->end (); ++i) {
                std::cout << *i << " ";
            }
            std::cout << "\n" << std::endl;
        }
    }

    HapLikelihood (const ClassHaplotype  & hap,
                   vvint_type & indices,
                   bool adjust,
                   bool aveLike)
        : hap_ (hap),
          indices_ (indices),
          loglike_ (0.0, indices_.size ()),
          idx_ (indices_.begin ()),
          nsites_ (hap_.get_nlocus ()),
          adjust_ (adjust),
          aveLike_ (aveLike)
    {}

    virtual ~HapLikelihood ()
    {}

    virtual double cond_prob (int, const RecombRate *) = 0;

    double logL (const RecombRate *pR);

    template <typename RandomNumberGenerator>
    void shuffle (RandomNumberGenerator & rand)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        for (vvint_iter i = indices_.begin (); i != indices_.end (); ++i) {
            std::random_shuffle (i->begin (), i->end (), rand);
        }
    }

    int allele (int n, int j) const
    {
        return hap_[(*idx_)[n]][j];
    }

    int nsites () const
    {
        return nsites_;
    }

    int nhaps( ) const
    {
        return hap_.size ();
    }

    virtual double adj_rate( double rate ) const
    {
        return rate;
    }

protected :
    const ClassHaplotype   & hap_;
    vvint_type indices_;
    std::valarray<double> loglike_;
    vvint_citer idx_;
    int nsites_;
    bool adjust_;
    bool aveLike_;
    double combine_loglike () const;
};

class SDLikelihood : public HapLikelihood
{
public :
    template <typename RandomNumberGenerator>
    SDLikelihood (const ClassHaplotype  & hap,
                  const MutationSimple  & qmut,
                  RandomNumberGenerator & rand,
                  int norder,
                  bool adjust = false,
                  bool aveLike = true)
        : HapLikelihood (hap, rand, norder, adjust, aveLike),
          Q (qmut),
          probyx_ (this->nsites (), hap.size (), 0.0),
          a_ (aveLike ? -0.14 : -0.11),
          b_ (aveLike ? -0.2 : -0.22)
    {
        adaptive_correction_ ();
    }

    SDLikelihood (const ClassHaplotype  & hap,
                  const MutationSimple  & qmut,
                  HapLikelihood::vvint_type & indices,
                  bool adjust = false,
                  bool aveLike = true)
        : HapLikelihood (hap, indices, adjust, aveLike),
          Q (qmut),
          probyx_ (this->nsites (), hap.size (), 0.0),
          a_ (aveLike ? -0.14 : -0.11),
          b_ (aveLike ? -0.2 : -0.22)
    {
        adaptive_correction_ ();
    }

    virtual ~SDLikelihood ()
    {}

    virtual double adj_rate( double rate ) const
    {
        if (adjust_ && rate > 0.0) {
            rate *= pow (10.0, a_ + b_ * log10 (rate));
        }
        return rate;
    }

    double cond_prob( int, const RecombRate *pR );

    // Public Data
    const MutationSimple & Q;

protected :
    DblMat probyx_;
    double a_;
    double b_;

    void adaptive_correction_( )
    {
        double n = nhaps ();
        double S = nsites ();
        if (aveLike_) {
            // a_ = -3.817e-01 + 6.350e-03 * S - 3.833e-05 * S * S;
            // b_ = -1.133e-01 - 2.600e-03 * S + 1.333e-05 * S * S;
            adapt_coef (n, S, &a_, &b_);
        }
        std::cout << "n = "   << n
                  << "\tS = " << S
                  << "\ta = " << a_
                  << "\tb = " << b_ << std::endl;
    }
};

class FDLikelihood : public HapLikelihood
{
public :

    template <typename RandomNumberGenerator>
    FDLikelihood (const ClassHaplotype  & hap,
                  const MutationFD & qmut,
                  RandomNumberGenerator & rand,
                  int norder,
                  bool adjust = false,
                  bool aveLike = true)
        : HapLikelihood (hap, rand, norder, adjust, aveLike),
          Q (qmut),
          probyx_ (this->nsites (), DblMat (hap.size (), Q.quad.n (), 0.0))
    { }

    FDLikelihood (const ClassHaplotype  & hap,
                  const MutationFD & qmut,
                  HapLikelihood::vvint_type & indices,
                  bool adjust = false,
                  bool aveLike = true)
        : HapLikelihood (hap, indices, adjust, aveLike),
          Q (qmut),
          probyx_ (this->nsites (), DblMat (hap.size (), Q.quad.n (), 0.0))
    { }

    virtual ~FDLikelihood ()
    {}

    double cond_prob( int, const RecombRate *pR );

    const MutationFD & Q;
private :
    VecDblMat probyx_;
};

#endif // CONDLIKE_HPP

// {{{ Log
//
// $Log: condlike.hpp,v $
// Revision 1.39  2003/02/05 21:52:29  nali
// combline_loglike () added in HapLikelihood
//
// Revision 1.38  2003/02/05 21:30:54  nali
// Use loglike_ as a class member instead of local variable in logL.
//
// Revision 1.37  2003/02/05 20:39:23  nali
// Declare some private member to be protected so can be used in inherited class.
//
// Revision 1.36  2003/02/04 10:23:21  nali
// Clean up a bit.
//
// Revision 1.35  2002/11/30 20:17:47  nali
// The new super-duper correct is based on log10.  Fix the bug.
//
// Revision 1.34  2002/11/27 09:37:39  nali
// Added adapt_coef() for super-dupe correction.
//
// Revision 1.33  2002/11/06 05:47:10  nali
// Fixed a bug: S undefined without NFIFTY.
//
// Revision 1.32  2002/10/31 22:03:37  nali
// adaptive_correction_ (): typos fixed.
//
// Revision 1.31  2002/10/31 21:28:31  nali
// Added code to adaptive decide the intercept and slope of the correction
// based on the number of sites (number of haplotypes is assumed to be 50).
//
// Revision 1.30  2002/09/15 09:11:57  nali
// updated correction for aveLogL
//
// Revision 1.29  2002/09/14 00:11:42  nali
// Fixed the bug introduced with adjust_rate, don't do anything if
// rate == 0.0.
//
// Also uses dbgsrc everywhere to better control dbg info.
//
// Revision 1.28  2002/09/13 05:18:51  nali
// Added aveL and aveLogL as options, added function adjust_rate.
//
// Revision 1.27  2002/09/02 08:19:41  nali
// allow adjust or not adjust
//
// Revision 1.26  2002/08/21 21:28:52  nali
// remove some debug messages
//
// Revision 1.25  2002/08/20 07:17:02  nali
// resurrect FDLikelihood
//
//
// }}}
