/**
 * @file   mutat.cpp
 * @author Michael Na Li
 * @date   Thu Mar 28 00:12:48 2002
 *
 * @brief  Implementation of mutat.hpp
 *
 * $Id: mutat.cpp,v 1.4 2002/08/20 05:10:37 nali Exp $
 */

#include "mutat.hpp"

double watterson (int nchr)
{
    dbg::trace dtrace (DBG_HERE);
    double wtheta (0.0);
    for (; nchr; --nchr) {
        wtheta += 1.0 / nchr;
    }
    return 1.0 / wtheta;
}

// {{{ class Mutation

const DblMat Mutation::SNP (2, 2, "0.0 1.0 1.0 0.0");

// }}}

// {{{ class MutationSimple

void
MutationSimple::calc_rates_( )
{
    for (int n = 0; n < maxN_; ++n) {
        rates_[n][1] = theta_ / (2.0 * (theta_ + n)); // Prob (Mutation)
        rates_[n][0] = 1.0 - rates_[n][1];
    }
}

// {{{ class Quadrature

const double
Quadrature::QUAD4  [] = { 0.322547689619392312,              // times
                          1.74576110115834658,
                          4.53662029692112798,
                          9.39507091230113313,
                          0.603154104341633602,              // weights
                          0.357418692437799687,
                          0.0388879085150053843,
                          0.000539294705561327450 };
const double
Quadrature::QUAD8  [] = { 0.170279632305,                    // times
                          0.903701776799,
                          2.25108662987,
                          4.26670017029,
                          7.04590540239,
                          10.7585160102,
                          15.7406786413,
                          22.8631317369,
                          0.369188589342,                    // weights
                          0.418786780814,
                          0.175794986637,
                          0.0333434922612,
                          0.00279453623523,
                          9.07650877338E-005,
                          8.48574671626E-007,
                          1.04800117487E-009 };
const double
Quadrature::QUAD16 [] = { 0.0876494104789,                   // times
                          0.462696328915,
                          1.14105777483,
                          2.1292836451,
                          3.43708663389,
                          5.07801861456,
                          7.07033853501,
                          9.43831433649,
                          12.2142233686,
                          15.4415273694,
                          19.1801568554,
                          23.5159056959,
                          28.5787297412,
                          34.5833987032,
                          41.9404526474,
                          51.7011603396,
                          0.206151714958,                    // weights
                          0.331057854951,
                          0.265795777644,
                          0.136296934296,
                          0.0473289286947,
                          0.0112999000801,
                          0.00184907094333,
                          0.000204271915245,
                          1.48445868632E-005,
                          6.8283193539E-007,
                          1.88102485005E-008,
                          2.8623502399E-010,
                          2.12707902829E-012,
                          6.29796700755E-015,
                          5.050473696E-018,
                          4.16146236924E-022 };


// }}}

// {{{ class MutationFD

dbg::dbg_source MutationFD::d_src = "MutationFD";

MutationFD::MutationFD (int maxN, double theta,
                        const Quadrature & q,
                        int n_allele,
                        int maxK)
    : Mutation (maxN, theta),
      quad (q), na_ (n_allele), M_ (na_, na_, 0.0), Mpower_ (maxK, M_),
      vecQt_ (maxN_, VecDblMat (quad.n (), M_))
{
    dbg::assertion (DBG_ASSERTION (na_ > 1));
    dbg::assertion (DBG_ASSERTION (maxN_ > 1));
    /* Initialize the mutation matrix
     * When na_ == 2, this is a SNP
     * When na_ > 2, treat as microsatelite
     */
    for (int a = 1; a < na_ - 1; ++a) {
        M_[a][a-1] = M_[a][a+1] = 0.5;
    }
    M_[0][1] = 1.0;
    M_[na_-1][na_-2] = 1.0;

    init_Mpower_ ();
    reset (theta_);
}

MutationFD::MutationFD (int maxN,
                        const Quadrature & q,
                        int n_allele,
                        int maxK)
    : Mutation (maxN, watterson (maxN)),
      quad (q), na_ (n_allele), M_ (na_, na_, 0.0), Mpower_ (maxK, M_),
      vecQt_ (maxN_, VecDblMat (quad.n (), M_))
{
    dbg::assertion (DBG_ASSERTION (na_ > 1));
    dbg::assertion (DBG_ASSERTION (maxN_ > 1));
    /*
     * Initialize the mutation matrix
     * When na_ == 2, this is a SNP
     * When na_ > 2, treat as microsatelite
     */
    for (int a = 1; a < na_ - 1; ++a) {
        M_[a][a-1] = M_[a][a+1] = 0.5;
    }
    M_[0][1] = 1.0;
    M_[na_-1][na_-2] = 1.0;

    init_Mpower_ ();
    reset (theta_);
}

MutationFD::MutationFD (int maxN, double theta,
                        const Quadrature & q,
                        const DblMat & M,
                        int maxK)
    : Mutation (maxN, theta),
      quad (q), na_ (M.ncols ()), M_ (M), Mpower_ (maxK, M_),
      vecQt_ (maxN_, VecDblMat (quad.n (), M_))
{
    dbg::assertion (DBG_ASSERTION (maxN_ > 1));
    init_Mpower_ ();
    reset (theta_);
}

MutationFD::MutationFD (int maxN,
                        const Quadrature & q,
                        const DblMat & M,
                        int maxK)
    : Mutation (maxN, watterson (maxN)),
      quad (q), na_ (M.ncols ()), M_ (M), Mpower_ (maxK, M_),
      vecQt_ (maxN_, VecDblMat (quad.n (), M_))
{
    dbg::assertion (DBG_ASSERTION (maxN_ > 1));
    init_Mpower_ ();
    reset (theta_);
}

void
MutationFD::init_Mpower_ ()
{
    dbg::trace dtrace (DBG_HERE);
    // Initialize the power of the mutation matrix
    VecDblMat::iterator m = Mpower_.begin ();
    // k == 0
    *m = 0.0;
    for (int a = 0; a < na_; ++a) {
        (*m)[a][a] = 1.0;
    }
    for (++m; m != Mpower_.end (); ++m) {
        (*m) = TNT::matmult (*(m-1), M_);
    }
}

void
MutationFD::reset (double theta)
{
    dbg::trace dtrace (DBG_HERE);
    dbg::assertion (DBG_ASSERTION (theta >= 0.0));
    theta_ = theta;
    for (int n = 1; n < maxN_; ++n) {
        double theta_n (theta_ / n);
        double lambda;
        double explambda;
        double lambda_m;
        double ptemp;
        for (int q = 0; q < quad.n (); ++q) {
            lambda = theta_n * quad.t (q);
            explambda = exp (- lambda);
            lambda_m  = 1.0;     // lambda^m / m!
            // m = 0
            vecQt_[n][q] = explambda * Mpower_[0];
            for (int m = 1; m < Mpower_.size (); ++m) {
                lambda_m  *= lambda / double (m);
                ptemp = explambda * lambda_m;
                // Sum over m
                vecQt_[n][q] += Mpower_[m] * ptemp;
            }
        }
    }
}

// }}}

// {{{ Log
/*
 * $Log: mutat.cpp,v $
 * Revision 1.4  2002/08/20 05:10:37  nali
 * move some stuff to .cpp file.
 *
 * Revision 1.3  2002/07/11 21:38:37  nali
 * Updated, minor.
 *
 * Revision 1.2  2002/03/28 22:22:02  nali
 * Fixed a bug in constructor of MutationFD
 *
 * Revision 1.1  2002/03/28 19:16:16  nali
 * Move some code to .cpp files
 *
 */
// }}}
