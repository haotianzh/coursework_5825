
#ifndef CONST_RHO_HPP
#define CONST_RHO_HPP

#include "optimize.hpp"
#include "minim1D.hpp"
#include "condlike.hpp"

#include "dbg/dbg.hpp"
#include <iomanip>

/**
 * The object function for rho at interval i, fix the rho elsewhere.
 * when i == -1. that's constant rho
 */
class HapOptConstRho : public OneDMinimObjFunc
{
public:

    static dbg::dbg_source dbgsrc;

    HapOptConstRho (HapLikelihood * srho, RecombRate *pR)
        : srho_ (srho), pR_ (pR)
    {}

    double operator () (double logrho)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        incr_neval ();
        pR_->update_rate (exp (logrho));
        double re = - srho_->logL (pR_);
        dbg::out (dbg::tracing, dbgsrc) << "log(rho) = "
                                        << std::setprecision (12) << logrho
                                        << ",\t -logL = "
                                        << std::setprecision (12) << re
                                        << std::endl;
        return re;
    }
private:
    HapLikelihood * srho_;
    RecombRate *pR_;
};

class ConstantRho
{
public :
    static dbg::dbg_source dbgsrc;

    ConstantRho (HapLikelihood * srho, RecombRate *pR, bool trace = false)
        : srho_ (srho), pR_ (pR), neval_ (0), trace_ (trace)
    {}

    double operator () (double logrho)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        ++neval_;
        pR_->update_rate (exp (logrho));
        return - srho_->logL (pR_);
    }

private:
    HapLikelihood * srho_;
    RecombRate *pR_;
    int neval_;
    bool trace_;
};

class ConstLikeSolve
{
public :
    static dbg::dbg_source dbgsrc;

    ConstLikeSolve (HapLikelihood * pHR, RecombRate *pR, double loglike)
        : pHR_ (pHR), pR_ (pR), loglike_ (loglike)
    { }

    double operator () (double rho)
    {
        dbg::trace dtrace (DBG_HERE);
        dbg::assertion (DBG_ASSERTION (rho >= 0.0));
        pR_->update_rate (rho);
        return pHR_->logL (pR_) - loglike_;
    }
private :
    HapLikelihood * pHR_;
    RecombRate *pR_;
    double loglike_;
};

#ifdef __MAIN_PROGRAM__
dbg::dbg_source HapOptConstRho::dbgsrc = "HapOptConstRho";
dbg::dbg_source ConstantRho::dbgsrc = "ConstantRho";
dbg::dbg_source ConstLikeSolve::dbgsrc = "ConstLikeSolve";
#endif


#endif // CONST_RHO_HPP

// {{{ Log
/*
 * $Log: constrho.hpp,v $
 * Revision 1.6  2002/12/03 03:18:03  nali
 * Switch to use simple minded yet fool-proof way of computing second derivative
 *
 * Revision 1.5  2002/11/05 19:48:25  nali
 * Added ifdef __MAIN_PROGRAM__ around dbgsrc.
 *
 */
// }}}
