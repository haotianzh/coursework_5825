
// $Id: hotopts.hpp,v 1.14 2003/02/04 10:23:21 nali Exp $

#ifndef HOTOPT_HPP
#define HOTOPT_HPP

#include "optimize.hpp"
#include "minim1D.hpp"
#include "hotspotter.hpp"
#include "condlike.hpp"
#include "constrho.hpp"
#include "calcCI.hpp"

#include "dbg/dbg.hpp"

#include <cmath>
#include <cstdlib>

/**
 * The object function for h at interval i, fix background rho
 */
class HapOptH_I : public OneDMinimObjFunc
{
public:
    HapOptH_I (HapLikelihood * srho, RecombRate *pR, double rho, int i)
        : srho_ (srho), pR_ (pR), rho_ (rho), i_ (i)
    {}

    double operator () (double loghot)
    {
        incr_neval ();
        pR_->update_rate (rho_, exp (loghot), i_);
        return - srho_->logL (pR_);
    }
private:
    HapLikelihood * srho_;
    RecombRate *pR_;
    double rho_;
    int i_;
};

/**
 * The object function for h at region [left, right), fix rho eslewhere
 */
class HapOptRhoRegion : public OneDMinimObjFunc
{
public:
    HapOptRhoRegion (HapLikelihood * srho, RecombRate *pR,
                     double rho, double le, double ri)
        : srho_ (srho), pR_ (pR), rho_ (rho), le_ (le), ri_ (ri)
    {}

    double operator () (double logh)
    {
        incr_neval ();
        pR_->update_rate (rho_, exp (logh), le_, ri_);
        return - srho_->logL (pR_);
    }
private:
    HapLikelihood * srho_;
    RecombRate *pR_;
    double  rho_;
    double le_;
    double ri_;
};

/**
 * optimize background rho and local h at interval i jointly
 */
class HapOptRH_I
{
public:
    static dbg::dbg_source dbgsrc;

    HapOptRH_I (HapLikelihood * srho, RecombRate *pR, int i)
        : srho_ (srho), pR_ (pR), i_ (i), neval_ (0)
    {}

    double operator () (const std::vector<double> & logRnH)
    {
        ++neval_;
        pR_->update_rate (exp (logRnH[0]), exp (logRnH[1]), i_);
        return - srho_->logL (pR_);
    }
    int operator () () const
    {
        return neval_;
    }

private:
    HapLikelihood *srho_;
    RecombRate    *pR_;
    int i_;
    int neval_;
};


/**
 * optimize background rho and local h at [le, ri) jointly
 */
class HapOptRH_Region
{
public:
    static dbg::dbg_source dbgsrc;

    HapOptRH_Region (HapLikelihood * srho, RecombRate *pR,
                     double le, double ri)
        : srho_ (srho), pR_ (pR), le_ (le), ri_ (ri), neval_ (0)
    {}

    double operator () (const std::vector<double> & logRnH)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        ++neval_;
        pR_->update_rate (exp (logRnH[0]), exp (logRnH[1]), le_, ri_);
        double loglike =  srho_->logL (pR_);
        dbg::out (dbg::tracing, dbgsrc) << "rho = " << exp (logRnH[0])
                                        << ", h = " << exp (logRnH[1])
                                        << ", l(rho, h) = "
                                        << loglike  << std::endl;
        if (isnan (loglike)) {
            std::cerr << "Not a number!" << std::endl;
            abort ();
        }
        return -loglike;
    }

    int operator () () const
    {
        return neval_;
    }

private:
    HapLikelihood * srho_;
    RecombRate *pR_;
    double le_;
    double ri_;
    int    neval_;
};

class HapOptRH_RegionSolveH
{
public :
    HapOptRH_RegionSolveH (HapLikelihood * pHR, RecombRate *pR,
                           double le, double ri, double rhobar,
                           double maxloglike)
        : pHR_ (pHR), pR_ (pR), le_ (le), ri_ (ri),
          rhobar_ (rhobar), maxloglike_ (maxloglike)
    {}

    double operator () (double h)
    {
        dbg::trace dtrace (DBG_HERE);
        pR_->update_rate (rhobar_, h, le_, ri_);
        return pHR_->logL (pR_) - maxloglike_;
    }

private:
    HapLikelihood * pHR_;
    RecombRate *pR_;
    double le_;
    double ri_;
    double rhobar_;
    double maxloglike_;
};


void
variance_rholambda( HapOptRH_Region & negLogL,
                    const std::vector<double> & logPar,
                    double *pLogRhoBarVar,
                    double *pLogLambdaBarVar );

dbg::dbg_source HapOptRH_I::dbgsrc = "HapOptH_I";
dbg::dbg_source HapOptRH_Region::dbgsrc = "HapOptRH_Region";

#endif  // HOTOPT_HPP
