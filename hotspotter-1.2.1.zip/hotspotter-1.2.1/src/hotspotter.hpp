/**
 * @file   hotspotter.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2002/11/21 06:43:51
 *
 * @brief
 *
 * $Id: hotspotter.hpp,v 1.5 2003/02/05 22:35:15 nali Exp $
 */
#ifndef _HOTSPOTTER_HPP
#define _HOTSPOTTER_HPP 1

#include "haplotype.hpp"
#include "popdefs.hpp"

#include "gsl++/gsl_random.hpp"
#include "stat/sfunc.hpp"
#include "mll/strutil.hpp"
#include "mll/nonnum.hpp"
#include "dbg/dbg.hpp"

#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <fstream>

#include <cstdlib>

static const char* SEEDFILE = "random.seeds";

std::ostream*
open_outfile( const char * );

unsigned long
get_seed( const char * = SEEDFILE );

void
put_seed( unsigned long s, const char * = SEEDFILE );

int
read_samples( const char *infile, VecPHap & samples, int, int );

void
adapt_coef( double n, double S, double *pa, double *pb );

extern dbg::dbg_source dbg_hotspotter;

#endif /* _HOTSPOTTER_HPP */

