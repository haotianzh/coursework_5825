
/**
 * Optimization functions
 * $Id: optimize.hpp,v 1.21 2002/11/05 19:47:27 nali Exp $
 */

#ifndef OPTIMIZE_H
#define OPTIMIZE_H

#include <vector>
#include <iostream>
#include "dbg/dbg.hpp"

#include <cmath>

const int MAXEVAL = 100;
const double TOLERANCE = 1e-12;

/**
 * Multidimensional minimization routine using the simplex method.
 * Nelder and Mead, 1965 The Computer Journal
 * Also refer to Numerical Recipe, Chapter 10, p408--412
 */

//
class COptSimplex
{
public:

    COptSimplex () { }
    ~COptSimplex () { }

    static dbg::dbg_source dbgsrc;

    template <typename CObjFunc>
    int optimize ( CObjFunc &,
                   const std::vector<double>  &,
                   const std::vector<double>  &,
                   double tol   = TOLERANCE,
                   int max_eval = MAXEVAL );

    //* return the minimum point
    const std::vector<double> & get_optima () const
    {
        return vertices[lowest];
    }

    //* return the minimum value
    double get_value () const
    {
        return vvalues[lowest];
    }

private :
    //* Dimension of the problem
    int ndim;
    //* Number of vertices
    int nvert;

    int highest;
    int nexthigh;
    int lowest;

    //* ndim+1 vertices defining the simplex
    std::vector<std::vector<double> > vertices;
    //* Initial values ndim+1
    std::vector<double> vvalues;
    //* Column sum of the starting points to find the centroid
    std::vector<double> colsum;


    void calc_colsum ();
    void find_hl ();
    double deviance () const;

    template <typename CObjFunc>
    double extrapolate (CObjFunc &, double);

    template <typename CObjFunc>
    void initialize (CObjFunc &,
                     const std::vector<double> &,
                     const std::vector<double>  &);
};

#ifdef __MAIN_PROGRAM__
dbg::dbg_source COptSimplex::dbgsrc = "COptSimplex";
#endif

inline void
COptSimplex::calc_colsum ()
{
    for (int i = 0; i < ndim; ++i) {
        colsum[i] = 0.0;
        for (int j = 0; j < nvert; ++j) {
            colsum[i] += vertices[j][i];
        }
    }
}

inline void
COptSimplex::find_hl ()
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    /* First determine which point is the highest (worst)
     * next-highest and lowest (best), by looping over the points
     * int the simplex.
     */
    if ( vvalues[0] > vvalues[1] ) {
        nexthigh = lowest = 1;
        highest = 0;
    } else {
        nexthigh = lowest = 0;
        highest = 1;
    }
    for (int i = 2; i < nvert; ++i) {
        if ( vvalues[i] <= vvalues[lowest] ) {
            lowest = i;
        } else if ( vvalues[i] > vvalues[highest] ) {
            nexthigh = highest;
            highest = i;
        } else if ( vvalues[i] > vvalues[nexthigh] ) {
            nexthigh = i;
        }
    }
    dbg::out (dbg::tracing, dbgsrc) << "Lowest = " << lowest
        << ", f(x) = " << vvalues[lowest] << "\n"
        << "Nexthight = " << nexthigh << ", f(x) = " << vvalues[nexthigh]
        << "\n"
        << "Highest = " << highest << ", f(x) = " << vvalues[highest]
        << std::endl;
}

inline double
COptSimplex::deviance () const
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    return 2.0 * std::abs (vvalues[highest] - vvalues[lowest]) /
        (std::abs (vvalues[highest]) + std::abs (vvalues[lowest]));
}


template <typename CObjFunc>
inline void
COptSimplex::initialize(CObjFunc & fobj,
                        const std::vector<double> & start,
                        const std::vector<double> & steps)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);

    ndim = start.size();
    nvert = ndim + 1;
    vertices = std::vector <std::vector<double> > (nvert, start);
    vvalues  = std::vector <double> (nvert, 0.0);
    colsum   = std::vector <double> (ndim,  0.0);

#ifdef DEBUG
    // This part can be rewritten to throw exceptions instead.
    if (ndim < 2) {
        std::cerr << "Dimension of the parameter space less than 2!\n"
                  << "Try one dimensional optimization instead." << std::endl;
        exit (1);
    }
    if (start.size() != steps.size()) {
        std::cerr << "Initial steps length not equal initial values!"
                  << std::endl;
        exit (1);
    }
#endif // DEBUG

    // set up the initial simplex
    vvalues[0]  = fobj (vertices[0]);

    int j = 0;
    for (int i = 1; i < nvert; ++i) {
        // None of the steps should be zero
        vertices[i][j] += steps[j];
        ++j;
        vvalues[i] = fobj ( vertices[i] );
    }
    // sum of columns (for the centroid)
    calc_colsum();
}


/**
 * Extrapolate by a factor through the face of the simplex across from
 * the high point, tries it and replaces the high point if the new
 * point is better.
 */
template <typename CObjFunc>
inline double
COptSimplex::extrapolate (CObjFunc & fobj, double factor)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);

    double fac1 = (1.0 - factor) / ndim;
    double fac2 = fac1 - factor;

    std::vector<double> vert_try ( ndim, 0.0 );
    for (int i = 0; i < ndim; ++i) {
        vert_try[i] = colsum[i] * fac1 - vertices[highest][i] * fac2;
    }

    // Evaluate the function at the trial point
    double valuetry = fobj ( vert_try );
    if ( valuetry < vvalues[highest] ) { // if it is better, replaces it
        vvalues[highest] = valuetry;

        for (int i = 0; i < ndim; ++i) {
            colsum[i] += vert_try[i] - vertices[highest][i];
            vertices[highest][i] = vert_try[i];
        }
    }
    return valuetry;
}

/**
 * Multidimensional minimization by Nelder and Mead algorithm.
 */
template <typename CObjFunc>
int
COptSimplex::optimize (CObjFunc & fobj,
                       const std::vector<double> & init,
                       const std::vector<double> & ss,
                       double tol,
                       int max_eval )
{

    initialize (fobj, init, ss);

    while (1) {

        // Find the highest, next highest, and lowest (best) points
        find_hl ();

        // Compute the fractional range from highest to lowest
        // return if satisfactory
        if ( fobj() > max_eval ) {
            std::cout << "Max evaluation exceeded!" << fobj ()
                      << "\tDeviance = " << deviance () << ".\n"
                      << "Current best guess : ";
            std::cout << "[";
            for (std::vector<double>::const_iterator i =
                    vertices[lowest].begin (); i != vertices[lowest].end ();
                    ++i) {
                std::cout << *i << ", ";
            }
            std::cout << "], with function value = " << vvalues[lowest]
                      << std::endl;
            return 1;
        } else if ( deviance() < tol )  {
            return 0;
        }

        /* Begin a new iteration. First extrapolate by a factor -1
           through the face of the simplex across from the high point.
           i.e., reflect the simplex from the high point. */

        double vtry = extrapolate (fobj, - 1.0);
        if (vtry < vvalues[lowest]) {

            /* Gives a result better than the best point, so try an
               additional extrapolation by a factor of 2. */
            vtry = extrapolate (fobj, 2.0);
        } else if (vtry > vvalues[nexthigh]) {

            /* The reflected point is worse than the second-highest,
               so look for an intermediate lower point, ie., do a
               one-dimensinal constraction. */
            double vsave = vvalues[highest];
            vtry = extrapolate (fobj, 0.5);
            if (vtry >= vsave) {
                // Can't seem to get rid of that high point. Better contract
                // around the lowest (best) point.
                for (int i = 0; i < ndim + 1; ++i) {
                    if (i != lowest) {
                        for (int j = 0; j < ndim; ++j) {
                            vertices[i][j] =
                                0.5 * (vertices[i][j] + vertices[lowest][j]);
                        }
                        vvalues[i] = fobj ( vertices[i] );
                    }
                    // Keep track of function evalutaions
                    calc_colsum ();
                }
            }
        }
    }
    return 1;
}

#endif // OPTIMIZE_H

// {{{ Log
/*
 * $Log: optimize.hpp,v $
 * Revision 1.21  2002/11/05 19:47:27  nali
 * Added ifdef __MAIN_PROGRAM__ around dbgsrc.
 *
 * Revision 1.20  2002/09/19 22:42:55  nali
 * Added dbg statements
 *
 * Revision 1.19  2002/09/13 05:19:59  nali
 * have get_optima() to return a const reference
 *
 * Revision 1.18  2002/08/21 20:14:51  nali
 * include <cmath> for std::abs
 *
 * Revision 1.17  2002/04/24 07:13:34  nali
 * Updated
 *
 * Revision 1.16  2002/03/14 07:58:39  nali
 * Fullopt works
 *
 * Revision 1.15  2001/12/19 01:38:15  nali
 * Updated to be STL comformant
 *
 * Revision 1.14  2001/11/29 17:35:49  nali
 * Updated
 *
 * Revision 1.13  2001/10/18 05:11:26  nali
 * Updated
 *
 * Revision 1.12  2001/10/17 07:04:02  nali
 * Updated
 *
 * Revision 1.11  2001/10/08 07:54:07  nali
 * Cleanup junk codes
 *
 * Revision 1.10  2001/10/03 07:14:07  nali
 * Jointly find mle of rho and h for fixed i
 *
 * Revision 1.9  2001/09/28 22:28:55  nali
 * MLE for newmut
 *
 * Revision 1.8  2001/09/28 00:02:12  nali
 * Move COneD to opt
 *
 * Revision 1.7  2001/05/15 07:23:09  nali
 * Add maximiztion fuinction for theta with sum of conditional probabilities.
 *
 * Revision 1.6  2001/05/11 00:43:34  nali
 * Compiled but have segmentation fault.
 *
 * Revision 1.5  2001/05/06 21:38:53  nali
 * Reorganizing of the codes. Add quadrature integeration in the mutation
 * matrix computation.
 *
 * Revision 1.4  2001/05/04 19:27:30  nali
 *
 * Changes the structure of COptSimplex to make it having template member
 * function instead of being a template class. Avoids creating unnecessary
 * objects.
 *
 * Revision 1.3  2001/05/04 00:06:16  nali
 *
 * Optimization working. Solved the constrain problem by log transformation.
 * Fixed a bug in the backward algorithm.
 *
 * Revision 1.2  2001/05/03 17:15:32  nali
 * Optimization routine works now.
 *
 * Revision 1.1  2001/05/02 17:13:12  nali
 * Simplex optimization class. Not tested yet.
 *
 */
// }}}
