// $Id: minim1D.hpp,v 1.15 2002/08/20 05:09:36 nali Exp $

#ifndef MININ1D_HPP
#define MININ1D_HPP

#include <stat/sfunc.hpp>

#include <algorithm>
#include <cmath>
#include <cassert>

//* The default ratio by which successive
const double GOLDR   = 0.61803399;
const double GOLD    = 1.0 + GOLDR;
const double GOLDC   = 1.0 - GOLDR;
//* Maximum magnification allowed by a parabolic-fit step
const int    GLIMIT  = 100;
const double TOL     = 1.0e-7;
const double TINY    = 1.0e-20;

const int GOLD_MAXEVAL = 150;

/**
 * One dimensional minima search, without calculating derivatives.
 * Note it does not quarantee global minimum.
 *
 * See Section 10.1, 10.2 of Press et al (1992) Numerical Recipe in C.
 */
class COptOneDNoDeriv
{

    double ax, bx, cx;
    double fmin;

    /**
     * Fiven a functor, and distinct initial points a and b, this routine
     * searches in the downhill direction (defined by the function as
     * evaluated at the initial points) and stores new points in ax, bx, cx
     * that bracket a minimum of the functor.
     */
    template <typename CObjFunc>
    void mnbrak (CObjFunc & fobj, double, double);

    /**
     * Given a function f, this routine performs golden section search for the
     * minimum in the bracket ax, bx, cx, isolating it to a fractional
     * precision of about tol. The abscissa of the minimum is returned and
     * the minimum function value is in fmin.
     *
     * Because ax, bx and cx have to set before hand, this function is private
     * and cannot be called directly.
     */
    template <typename CObjFunc>
    double golden (CObjFunc & fobj, double tol);

public:

    //* Constructor for the sake of sanity.
    COptOneDNoDeriv () : ax (0.0), bx (0.0), cx (0.0), fmin (0.0) {}

    /**
     * Given bracket a, b and c. Initialize ax, bx and cx and then
     * call gold(fobj, tol).
     */
    template <typename CObjFunc>
    double golden (CObjFunc & fobj,
                   double a, double b, double c,
                   double tol = TOL);

    /**
     * This routine only requires two distinct initial points a and b
     * calls mnbrak to find the bracketing points. It then calls gold(fobj,
     * tol).
     */
    template <typename CObjFunc>
    double golden (CObjFunc & fobj,
                   double a, double b,
                   double tol = TOL);
    /**
     * Returns the minimal function value found.
     */
    double get_fmin () const { return fmin; }

};

template <typename CObjFunc>
void COptOneDNoDeriv::mnbrak (CObjFunc & fobj, double a, double b)
{

    ax = a;
    double fa = fobj (ax);
    bx = b;
    double fb = fobj (bx);

    if ( fb > fa ) {
        // switch roles of a and b so that we can go downhill in the direction
        // from a to b
        std::swap (ax, bx);
        std::swap (fa, fb);
    }

    // First guess for c.
    cx = bx + GOLD * (bx - ax);
    double fc = fobj (cx);

    while (fb > fc) {    // Keep returning here until we bracket.
        double r = (bx - ax) * (fb - fc);
        double q = (bx - cx) * (fb - fa);
        // Compute u by parabolic extrapolation from a, b, c. TINY is used to
        // prevent any possible divide by zero.
        double u = bx - (bx - cx) * q - (bx - ax) * r /
            (2.0 * MLL::absmax (q-r, TINY));
        double fu;
        // We won't go further than this. Test various possibilities
        double ulim = bx + GLIMIT * (cx - bx);
        if ((bx - u) * (u - cx) > 0.0) { // parabolic b < u < c, try it
            fu = fobj (u);
            if (fu < fc) {                // Got a minimum between b and c
                ax = bx;
                fa = fb;
                bx = u;
                fb = fu;
                break;
            } else if (fu > fb) {         // Got a minimum between a and u
                cx = u;
                fc = fu;
                break;
            }
            // parabolic fit was not use, use default magnification.
            u = cx + GOLD * (cx - bx);
            fu = fobj (u);
        } else if ((cx - u) * (u - ulim) > 0.0) {
            // Parabolic fit is between c and its allowed limit
            fu = fobj (u);
            if (fu < fc) {
                bx = cx;
                fb = fc;
                cx = u;
                fc = fu;
                // There is an ambiguity in the macro defined in NR in C
                // refer to the Fortran 90 code
                u  = cx + GOLD * (cx - bx);
                fu = fobj (u);
            }
        } else if ((u - ulim) * (ulim - cx) >= 0.0) {
            // Limit parabolic u to maximum allowed value
            u = ulim;
            fu = fobj (u);
        } else {
            u = cx + GOLD * (cx - bx);
            fu = fobj(u);
        }
        // eliminate oldest point and continue
        ax = bx;
        fa = fb;
        bx = cx;
        fb = fc;
        cx = u;
        fc = fu;
    }

#if defined(DEBUG) && DEBUG == 4
    std::cout << "The braket is "
              << ax << " " << bx << " " << cx << std::endl;
    std::cout << "The function values are "
              << fa << " " << fb << " " << fc << std::endl;
#endif
}


template <typename CObjFunc>
inline double COptOneDNoDeriv::golden (CObjFunc & fobj,
                                       double a,
                                       double b,
                                       double tol)
{
    mnbrak (fobj, a, b);
    return golden (fobj, tol);
}

template <typename CObjFunc>
inline double COptOneDNoDeriv::golden (CObjFunc & fobj,
                                       double a,
                                       double b,
                                       double c,
                                       double tol)
{
    ax = a;
    bx = b;
    cx = c;
    return golden (fobj, tol);
}

template <typename CObjFunc>
double COptOneDNoDeriv::golden (CObjFunc & f, double tol)
{
    // At any given time we will keep track of four points
    double x0 = ax;
    double x1 = 0.0;
    double x2 = 0.0;
    double x3 = cx;

    // make x0 to x1 the smaller segment
    if (std::abs (cx - bx) > std::abs (bx - ax)) {
        x1 = bx;
        x2 = bx + GOLDC * (cx - bx);
    } else {
        x2 = bx;
        x1 = bx - GOLDC * (bx - ax);
    }
    // The initial evaluations. Note that we never need evaluate the
    // function at the original endpoints.
    double f1 = f (x1);
    double f2 = f (x2);
    while (std::abs (x3 - x0) > tol * (std::abs(x1) + std::abs(x2))) {
#if defined(DEBUG) && DEBUG == 4
        std::cout << "Current bracket (and function values) are "
                  << x1 << " ( " << f1 << " ),\t "
                  << x2 << " ( " << f2 << " )  "
                  << std::endl;
#endif

        if (f2 < f1) {
            x0 = x1;
            x1 = x2;
            x2 = GOLDR * x1 + GOLDC * x3;
            f1 = f2;
            f2 = f (x2);
        } else {
            x3 = x2;
            x2 = x1;
            x1 = GOLDR * x2 + GOLDC * x0;
            f2 = f1;
            f1 = f (x1);
        }
        if (f.neval () > GOLD_MAXEVAL) {
            break;
        }
    } // Back to see if we are done.

    // We are done, output the best of the two current values.
    if (f1 < f2) {
        fmin = f1;
    } else {
        fmin = f2;
        x1 = x2;
    }
    return x1;
}

// class OneDMinimObjFunc
class OneDMinimObjFunc
{
private:
    int neval_;
    double minimum_;
public:
    OneDMinimObjFunc() : neval_(0), minimum_ (1e20) { }
    virtual ~OneDMinimObjFunc () { }
    virtual double operator () (double) = 0;
    int operator () () const;
    int neval () const;
    void incr_neval ();
    double minimize (const std::vector<double> & intervals);
    double minimum ();
};

// Inline functions of OneDMinimObjFunc

inline int
OneDMinimObjFunc::operator () () const
{
    return neval_;
}

inline int
OneDMinimObjFunc::neval () const
{
    return neval_;
}
    
inline void
OneDMinimObjFunc::incr_neval ()
{
    ++neval_;
}

inline double
OneDMinimObjFunc::minimum ()
{
    return minimum_;
}

inline double
OneDMinimObjFunc::minimize (const std::vector<double> & intervals)
{
    assert (intervals.size() > 1);

    double local_min  = 0.0;
    double global_min = 0.0;
    double lmin_value = 0.0;

    COptOneDNoDeriv maxi;

    for (std::vector<double>::const_iterator i = intervals.begin() + 1;
         i != intervals.end(); ++i ) {
        local_min  = maxi.golden (*this, *(i-1), *i);
        lmin_value = maxi.get_fmin();
        if (lmin_value < minimum_) {
            // smaller
            global_min = local_min;
            minimum_  = lmin_value;
        }
    }
    return global_min;
}

#endif  // MININ1D_HPP

// {{{ Log
// $Log: minim1D.hpp,v $
// Revision 1.15  2002/08/20 05:09:36  nali
// endl -> std::endl
//
// Revision 1.14  2002/03/20 21:24:14  nali
//
// Updated.
//
// Revision 1.13  2002/03/08 07:58:20  nali
// Updated
//
// Revision 1.12  2002/02/23 10:21:29  nali
// minor changes so rholike gives logL_max
//
// Revision 1.11  2002/02/23 08:10:46  nali
// Updated some names
//
// Revision 1.10  2001/12/19 01:38:15  nali
// Updated to be STL comformant
//
// Revision 1.9  2001/10/08 09:31:57  nali
// Add reparametrization of hot region
//
// Revision 1.8  2001/10/08 07:54:05  nali
// Cleanup junk codes
//
// Revision 1.7  2001/09/30 06:31:59  nali
// Simple recombination model
//
// Revision 1.6  2001/09/28 22:28:54  nali
// MLE for newmut
//
// Revision 1.5  2001/06/26 06:56:16  nali
// Fixed a type in golden()
//
// Revision 1.4  2001/05/24 08:07:47  nali
// Not much real changes.
//
//
// }}}
