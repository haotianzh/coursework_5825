/*
 * $Id: rholike.cpp,v 1.64 2003/02/05 22:35:35 nali Exp $
 */

#define __MAIN_PROGRAM__ "rholike"

#include "haplotype.hpp"
#include "popdefs.hpp"
#include "condlike.hpp"
#include "constrho.hpp"
#include "calcCI.hpp"
#include "hotspotter.hpp"

#include "mll/simpleoption.hpp"
#include "mll/timer.hpp"
#include "boost/format.hpp"

#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>

#include <cstdlib>

// Number of grid points, when discretizing the posterior to compute CI
#ifdef DBG_ENABLED
const int NGRID = 10;
#else
const int NGRID = 1000;
#endif
const double SIGMA = 2.3;

const char *na_str = "NA";
dbg::dbg_source dbgsrc = __MAIN_PROGRAM__;

int main (int argc, char **argv)
{
    // {{{ Parsing command line options

    // Format flag
    // input file format
    MLL::IntOption  format_flag ('f', "format", "number 1-3",
                                 "Input file format", 0);
    // Number of populations to use, default is 0, which means all
    MLL::IntOption maxpop ('n', "npop", "number",
                           "Number of Populations to Use", 0);
    MLL::IntOption  n_order ('r', "order", "number",
                             "Number of random orders", 10);
    MLL::BoolOption save_seed ('v', "save-seed", "toggle",
                               "Save Seed? (default no)", false);
    MLL::BoolOption adj ('a', "adjust", "toggle",
                         "Adjust rho * d? (default yes)", true);
    MLL::StringOption out_file_name ('o', "output-file", "filename",
                                     "Output file name", "");
    MLL::StringOption input_file_name ('\0', "input-file", "filename",
                                       "Input file name", "");
    // skip some populations ?
    MLL::IntOption skip ('k', "skip", "number",
                         "Skip some populations", 0);
    MLL::DoubleOption theta ('t', "theta", "real",
                             "The specified value for theta", -1.0);
    // compute likelihood curve
    MLL::DoubleOption rhostart ('b', "begin", "real positive",
                                "Start value for rho", 0.0);
    MLL::DoubleOption rhoend ('e', "end", "real positve",
                              "End value for rho", -1.0);
    MLL::DoubleOption rhostep ('s', "step", "real positive",
            "Step for rho", 1.0);
    MLL::BoolOption avelike ('L', "avelike", "toggle",
            "Average Likelihod? (default yes)", true);
    MLL::BoolOption calcCI ('c', "calcCI", "toggle",
            "Compute credible intervals? (default no)", false);

    // compute MLE by default
    bool compute_mle = true;

    MLL::SimpleGetOption sgetopt ("rholike",
                                  "Estimating constant recombination rate",
                                  &format_flag,
                                  &n_order,
                                  &maxpop,
                                  &save_seed,
                                  &skip,
                                  &theta,
                                  &rhostart,
                                  &rhoend,
                                  &rhostep,
                                  &adj,
                                  &avelike,
                                  &calcCI,
                                  &out_file_name,
                                  // this is a positional option
                                  &input_file_name,
                                  0);
    if (sgetopt.parse (argc, argv) != 0) {
        return EXIT_FAILURE;
    }

    sgetopt.print_summary (std::cout);

    // }}}

    if (double (rhoend) >= double (rhostart)) {
        std::cout << "Compute likelihood curve, not MLE\n";
        compute_mle = false;
    }

    // Readin random seed
    unsigned long s1 = get_seed ();
    GSL::RandomGenerator rng (s1);
    GSL::UniformRandomGenerator myrand (rng);
    
    VecPHap samples;
    int popsize = read_samples (input_file_name.c_str (),
                                samples, format_flag, maxpop);
    
    // theta's estimator for single site mutation rate
    if (theta < 0.0) {
        theta = watterson (popsize);
    }
    std::cout << "Mutation rate (per site, theta's) = "
              << theta << std::endl;

    // initial values for rho
    std::vector<double> rhos_init (2, -10.0);
    rhos_init[1] = 10.0;

    // a sequence of rhos to compute likelihood curve
    std::vector<double> rhos;
    if (!compute_mle) {
        MLL::arange (std::inserter (rhos, rhos.begin()),
                     double (rhostart), double (rhoend), double (rhostep));
    }

    MLL::Timer timer; // Start timing
    std::cout << "Start computing ... " << std::endl;

    // For each population
    int counter = skip;

    std::ostream *out = open_outfile (out_file_name.c_str ());

    boost::format fmtReal ("%12.6g ");
    boost::format fmtNA ("%10s ");
    boost::format fmtReals ("%12.6g %12.6g %12.6g %12.6g %12.6g %12.6g %12.6g");
    boost::format fmtLogL ("%5s %12.6g %12.6g");
    if (compute_mle) {
        std::cout << "Computing MLE\n";
        *out << boost::format ("%5s %12s %12s %12s %12s %12s %12s %12s\n")
            % "pop"
            % "rhohat" % "var" % "logLhat"
            % "HPlow" % "HPupp" % "CIlow" % "CIupp";
    } else {
        std::cout << "Evaluating Likelihoods\n";
        *out << boost::format ("%5s %5d %12s %12s\n")
            % "pop" % "order" % "rho" % "logLrho";
    }

    double rhomle (0.0);
    HapLikelihood *plike = 0;

    dbg::enable (dbg::tracing, false);
    dbg::enable (dbg::tracing, dbgsrc, false);
    dbg::enable (dbg::tracing, ConstLikeSolve::dbgsrc, false);
    dbg::enable (dbg::tracing, RecombRate::dbgsrc, false);
    dbg::attach_ostream (dbg::all, std::cerr);

    MutationSimple Qsimple (popsize, theta);
    RecombRate *pR;

    std::valarray<double> grid (NGRID + 1);

    std::pair<double, double> credItvl (-1.0, -1.0);
    std::pair<double, double> confItvl (-1.0, -1.0);

    for (ci_VecPHap sptr = samples.begin() + counter;
         sptr != samples.end(); ++sptr) {

        std::cout << "\n# Population " << counter++ << std::endl;

        if ((*sptr)->get_nlocus () < 2) {
            std::cout << "Less than 2 sites, skipped." << std::endl;
            if (compute_mle) {
                *out << boost::format ("%5d %12s %12s %12s %12s %12s %12s %12s")
                    % counter % na_str % na_str % na_str % na_str
                    % na_str % na_str % na_str;
            } else {
                *out << boost::format ("%5d %12s %12s")
                    % counter % na_str % na_str;
            }
            *out << std::endl;
            continue;
        }

        pR = new RecombRate ((*sptr)->map_pos (), 0.0);
        plike = new SDLikelihood (**sptr, Qsimple,
                                  myrand, compute_mle ? n_order : 1,
                                  adj, avelike);

        HapOptConstRho opt_rho (plike, pR);
        if (compute_mle) {
            // maximize the likelihood for rho with no hot spot
            rhomle = opt_rho.minimize (rhos_init);
            double maxL = - opt_rho.minimum ();
            double var = variance_constrho (opt_rho, rhomle);
            std::cout << "RHOBAR = " << rhomle << std::endl;

            if (calcCI) {
                // credItvl = cred_interval (plike, pR, grid, rhomle, SIGMA);
                confItvl = conf_interval (ConstLikeSolve (plike, pR,
                                                          maxL - LOGDIFF),
                                          exp (rhomle), true);
            }
            *out << boost::format ("%5d ") % counter
                 << fmtReals % exp (rhomle) % var % maxL
                % credItvl.first % credItvl.second
                % confItvl.first % confItvl.second << std::endl;
        } else {
            for (int order = 1; order <= n_order; ++order) {
                std::cout << "Order " << order << std::endl;
                plike->shuffle (myrand);
                for (std::vector<double>::const_iterator i = rhos.begin ();
                     i != rhos.end (); ++i) {
                    std::cout << "Rho =  " << *i << std::endl;
                    pR->update_rate (*i);
                    *out << boost::format ("%5d ") % counter
                         << fmtLogL % order % *i  % plike->logL (pR)
                         << std::endl;
                }
            }
        }

        delete plike;
        delete pR;
    }

    if (out != &std::cout) {
        delete out;
    }

    std::cout << "\n\n" << std::endl;
    // Clean up
    std::for_each (samples.begin(), samples.end(), MLL::free_object ());

    // Save random seeds (append)
    if (save_seed) {
        put_seed (rng.get ());
    }
    return EXIT_SUCCESS;
}

// {{{ Log
//
// $Log: rholike.cpp,v $
// Revision 1.64  2003/02/05 22:35:35  nali
// Use read_samples () to read in data
//
// Revision 1.63  2003/02/04 10:23:20  nali
// Clean up a bit.
//
// Revision 1.62  2003/01/22 11:14:20  nali
// comment out credItvl
//
// Revision 1.61  2003/01/22 11:04:50  nali
// Get rid of MLL::format completely and use the template based version
// of conf_itvl.
//
// Revision 1.60  2002/12/03 03:18:03  nali
// Switch to use simple minded yet fool-proof way of computing second derivative
//
// Revision 1.59  2002/12/02 09:47:53  nali
// Fix output when computing the likelihood curve.
//
// Revision 1.58  2002/12/02 09:07:26  nali
// Added 3pt correction
//
// Revision 1.57  2002/11/30 20:26:27  nali
// Fixed out put when nsite < 2.
//
// Revision 1.56  2002/11/27 20:03:38  nali
// flush out as we go
//
// Revision 1.55  2002/11/27 09:40:29  nali
// Use code from hotspotter_aux.hpp, notably the variance computation
// based on approximate second derivative.
//
// Revision 1.54  2002/11/06 05:49:09  nali
// Moved computing credible interval stuff into calcCI.[hc]pp.
// Added computing confidence interval.
// Removed -q option (for true rho).
// Started using boost::format.
//
// Revision 1.53  2002/09/25 21:43:33  nali
// keep the options available for development.
//
// Revision 1.52  2002/09/25 21:42:37  nali
// Change the default setting of -a, to use correction.
//
// Revision 1.51  2002/09/14 05:36:30  nali
// Added a switch to turn of CI computing by default
//
// Revision 1.50  2002/09/14 03:04:08  nali
// Added #ifdef DBG_ENABLED guard around dbg::out
//
// Revision 1.49  2002/09/14 00:11:43  nali
// Fixed the bug introduced with adjust_rate, don't do anything if
// rate == 0.0.
//
// Also uses dbgsrc everywhere to better control dbg info.
//
// Revision 1.48  2002/09/13 19:40:45  nali
// Comput 90% CI
//
// Revision 1.47  2002/09/13 05:22:42  nali
// added -L option to switch between aveL and aveLogL
//
// Revision 1.46  2002/09/12 08:05:54  nali
// Adopted to new credint.hpp
//
// Revision 1.45  2002/09/02 08:20:11  nali
// enable adjustment again
//
// Revision 1.44  2002/08/20 07:19:17  nali
// 1. remove AdjustedRecombRate class.
// 2. New functions rrate_m and rrate_nm to simplify rate () member function
//    so that there both SD and FD can share the same RecombRate.
//
// Revision 1.43  2002/08/20 05:14:05  nali
// added option to specify theta.
//
// Revision 1.42  2002/07/27 19:14:43  nali
// move the exp (logL) to credint
//
// Revision 1.41  2002/07/26 22:46:31  nali
// remove command line options adj and calcCI.
// Never use adjustments.
// Always compute CI with credint.hpp instead of gsl_root.hpp.
//
// Revision 1.40  2002/07/25 20:58:10  nali
// Change the default number of orders to 10.
//
// Revision 1.39  2002/07/16 06:52:22  nali
// REMOVED: old junk code (FDLikelihood).
//
// FIXED: a bug when the rate is zero (two adjacent sites
// have zero distance, it happens with simulated data when
// the number of segregating sites is large compared with
// the total number of sites, 100 versus 5000), pow (rate * 0.2)
// is NaN.
//
// Revision 1.38  2002/07/12 00:22:24  nali
// Updated to use the constructor for SimpleOption.
//
// Revision 1.37  2002/07/08 04:16:19  nali
// Updated per changes in mll (dbg.h -> dbg.hpp, use of libmll.a,
// etc.
//
// Revision 1.36  2002/07/07 01:04:54  nali
// Cleaned up options to use simpletoption.hpp.
//
// Revision 1.35  2002/07/06 23:53:35  nali
// Updated option
//
// Revision 1.34  2002/07/04 22:56:26  nali
// removed MutationFD
//
// Revision 1.33  2002/07/04 22:50:21  nali
//
// Always use Markovian approximation, remove unnecessary options -d and -m.
//
// Revision 1.32  2002/06/24 22:34:10  nali
//
// Print out adj info then -e option is not given.
//
// Revision 1.31  2002/05/07 07:58:24  nali
// Updated
//
// Revision 1.30  2002/05/02 05:50:38  nali
// dbg related
//
// Revision 1.29  2002/04/24 18:19:55  nali
// fixed output, really
//
// Revision 1.28  2002/04/24 18:14:03  nali
// fixed output
//
// Revision 1.27  2002/04/23 20:08:21  nali
// test CompositeRecomRate works
//
// Revision 1.26  2002/04/23 17:00:56  nali
// Updated in response to changes in recomb.hpp and condlike.hpp
//
// Revision 1.25  2002/04/15 17:43:01  nali
// \p not a valid control sequence
//
// Revision 1.24  2002/04/15 17:27:17  nali
// Makes compute 'CI' optional.
//
// Revision 1.23  2002/04/10 17:44:59  nali
// useMarkov = false by default
//
// Revision 1.22  2002/04/08 21:15:16  nali
// Updated, wrt new HapLikelihood.
//
// Revision 1.21  2002/04/05 21:15:41  nali
// don't print log messages in solve ().
//
// Revision 1.20  2002/03/29 00:33:26  nali
// Added CI computation for constant background rho
//
// Revision 1.19  2002/03/28 22:11:02  nali
// added debug info
//
// Revision 1.18  2002/03/28 19:20:40  nali
//
// Updated with new HapLikelihood classes.  Use
// a HapLikelihood * to take advantage of the
// polymorphism.
//
// Revision 1.17  2002/03/25 08:31:45  nali
//
// * Fixed problem with nlocus < 2.
// * Cleanup output.
//
// Revision 1.16  2002/03/21 00:30:44  nali
// Updated
//
// Revision 1.15  2002/03/20 21:24:14  nali
//
// Updated.
//
// Revision 1.14  2002/02/23 10:21:29  nali
// minor changes so rholike gives logL_max
//
// Revision 1.13  2002/02/23 08:10:46  nali
// Updated some names
//
// Revision 1.12  2002/02/22 21:07:31  nali
//
// Handle the case where random.seeds doesn't exist in current
// directory.
//
// Revision 1.11  2002/02/22 09:21:15  nali
// Updated HapLikelihood for multiple orders
//
// Revision 1.10  2002/02/22 01:24:04  nali
// Updated to fully use mll
//
// Revision 1.9  2002/02/14 18:41:42  nali
// Updated
//
// Revision 1.8  2002/01/31 08:22:24  nali
// Move the MLE part out of the innermost loop
//
// Revision 1.7  2002/01/27 01:55:35  nali
// compute mle also
//
// Revision 1.6  2002/01/27 01:24:02  nali
// Updated
//
// Revision 1.5  2002/01/23 09:27:48  nali
// Updated
//
// Revision 1.4  2001/12/19 01:38:16  nali
// Updated to be STL comformant
//
// Revision 1.3  2001/12/17 19:25:49  nali
//
// * Merge hotspot.hpp and hotregion.hpp into one class.
// * Rid of quadrature method.
//
// Revision 1.2  2001/11/26 22:15:09  nali
// Added option to skip some populations
//
// Revision 1.1  2001/10/31 22:38:29  nali
// Compute MLE for rho with no hot spot
//
// Revision 1.10  2001/10/17 07:04:02  nali
// Updated
//
// Revision 1.9  2001/10/11 08:16:52  nali
// updated
//
// Revision 1.8  2001/10/10 20:22:10  nali
// Updated
//
// Revision 1.7  2001/10/10 07:42:59  nali
// Updated
//
// Revision 1.6  2001/10/08 09:31:57  nali
// Add reparametrization of hot region
//
// Revision 1.5  2001/10/08 07:54:05  nali
// Cleanup junk codes
//
// Revision 1.4  2001/10/05 06:44:08  nali
// Use theta's estimator for per site mutation rate
//
// Revision 1.3  2001/10/03 07:14:07  nali
// Jointly find mle of rho and h for fixed i
//
// Revision 1.2  2001/10/03 05:26:25  nali
// Ues per base mutation rate
//
// Revision 1.1  2001/10/02 08:21:04  nali
// quadrature recomb model
//
// Revision 1.2  2001/10/01 20:14:10  nali
// minor update
//
// Revision 1.1  2001/09/30 06:33:35  nali
// Simple recombination model
//
//
// }}}
