/**
 * @file   hotspotter_aux.cpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2002/11/21 06:47:08
 *
 * @brief
 *
 * \$Id: hotspotter_aux.cpp,v 1.6 2003/02/05 22:35:15 nali Exp $
 */

#include "hotspotter.hpp"
#include "gsl++/gsl_interp.hpp"

dbg::dbg_source dbg_hotspotter = "hotspotter";

std::ostream*
open_outfile( const char *ofname )
{
    std::ostream *out = 0;
    if (ofname && ofname[0] != '\0') {
        out = new std::ofstream (ofname, std::ios::out);
        if (out->bad ()) {
            std::cerr << "Cannot open " << ofname << std::endl;
            delete out;
        }
    }
    if (!out) {
        out = &std::cout;
    }
    return out;
}

unsigned long
get_seed( const char *sfname )
{
    std::ifstream rs (sfname);
    unsigned long s1 = 0u;
    if (rs.good ()) {
        while (rs >> s1) {
        }
        std::cout << "Seed recovered from random.seeds : ";
    } else {
        std::cout << "Default seed is used : ";
    }
    std::cout << s1 << std::endl;
    return s1;
}

void
put_seed( unsigned long s, const char * sfname )
{
    std::ofstream ors (sfname, std::ios::app);
    ors << s << std::endl;
}

int
read_samples( const char *infile, VecPHap & samples,
              int format_flag, int maxpop )
{
    std::ifstream input (infile) ;
    if (input.fail ()) {
        std::cerr << "Cannot open " << infile << std::endl;
        throw std::runtime_error ("Cannot open input file!");
    }
    int numpop  = 1;                 // Number of populations
    int popsize = 1000;              // Population size
    int nsite   = 0;                 // Total number of sits
    std::string temp;                // Temporary variable

    if (format_flag == 1) {
        // use stdin as input, read in hudson format
        input >> temp;
        input >> popsize;
        input >> nsite;
        input >> temp >> temp >> temp;
        input >> numpop;
    } else if (format_flag == 2){
        // read in number of populations
        input >> numpop >> popsize >> nsite;
    } else if (format_flag == 3) {
        // new Hudson's format
        input >> temp;
        input >> popsize;
        input >> numpop;
    }
    // Limit the number of populations used.
    if (maxpop > 0 && numpop > maxpop) {
        numpop = maxpop;
    }

    for (int i = 0; i < numpop; ++i) {
        samples.push_back (new ClassHaplotype (input, format_flag,
                                               popsize, nsite));
    }
    input.close();

    std::cout << "Total number of populations = " << samples.size ()
              << std::endl;
    popsize = samples[0]->size ();
    std::cout << "First population size = " << popsize<< std::endl;
    std::cout << "Finished reading data\n" << std::endl;

    return popsize;
}

void adapt_coef( double n, double S, double *pa, double *pb )
{
    dbg::trace dtrace (DBG_HERE);
    static const int LEN_N = 4;
    static const double NN[LEN_N] = { 20, 50, 100, 200 };
    static const int LEN_S = 4;
    static const double SS[LEN_S] = { 10, 20, 50, 100 };
    static const double INTERCEPTS[LEN_S][LEN_N] = {
        { -0.12548194032029, -0.100286910805797, -0.156773361966507,
          -0.117979872238384 },
        { -0.164457358498351, -0.118622098670573, -0.120533135414677,
          -0.102640073195858 },
        { -0.119057771883168, -0.0712850231013675, -0.063998111673405,
          -0.0540142212967708 },
        { -0.086922630276413, -0.0584719142418379, -0.0380763152099587,
          -0.0249354466873294 }
    };
    static const double SLOPES[LEN_S][LEN_N] = {
        { -0.199256519765044, -0.167243709941538, -0.0891878470870548,
          -0.0612684392514612 },
        { -0.178157529178485, -0.160659755071709, -0.086918381351024,
          -0.0612738994021919 },
        { -0.214673848725183, -0.209665833993973, -0.169348844872214,
          -0.138266386072648 },
        { -0.262015515658456, -0.236178431221567, -0.207447062653844,
          -0.171683591885102}
    };

    static GSL::Interpolation intercepts_S10  (NN, INTERCEPTS[0], LEN_N);
    static GSL::Interpolation intercepts_S20  (NN, INTERCEPTS[1], LEN_N);
    static GSL::Interpolation intercepts_S50  (NN, INTERCEPTS[2], LEN_N);
    static GSL::Interpolation intercepts_S100 (NN, INTERCEPTS[3], LEN_N);
    static GSL::Interpolation slopes_S10  (NN, SLOPES[0], LEN_N);
    static GSL::Interpolation slopes_S20  (NN, SLOPES[1], LEN_N);
    static GSL::Interpolation slopes_S50  (NN, SLOPES[2], LEN_N);
    static GSL::Interpolation slopes_S100 (NN, SLOPES[3], LEN_N);

    // Interpolate along n
    double SS_intercepts[LEN_S];
    SS_intercepts[0] = intercepts_S10  (n);
    SS_intercepts[1] = intercepts_S20  (n);
    SS_intercepts[2] = intercepts_S50  (n);
    SS_intercepts[3] = intercepts_S100 (n);
    double SS_slopes[LEN_S];
    SS_slopes[0] = slopes_S10  (n);
    SS_slopes[1] = slopes_S20  (n);
    SS_slopes[2] = slopes_S50  (n);
    SS_slopes[3] = slopes_S100 (n);

#ifdef THREEPOINTS
    std::cout << "THREEPOINTS" << std::endl;
    // Interpolate along S
    GSL::Interpolation intercepts (SS+1, SS_intercepts+1, LEN_S-1);
    GSL::Interpolation slopes (SS+1, SS_slopes+1, LEN_S-1);
#else
    // Interpolate along S
    GSL::Interpolation intercepts (SS, SS_intercepts, LEN_S);
    GSL::Interpolation slopes (SS, SS_slopes, LEN_S);
#endif // THREEPOINTS

    *pa = intercepts (S);
    *pb = slopes (S);
}

/* {{{ Log */
/*
 * $Log: hotspotter_aux.cpp,v $
 * Revision 1.6  2003/02/05 22:35:15  nali
 * Finished read_samples ()
 *
 * Revision 1.5  2003/02/04 10:23:20  nali
 * Clean up a bit.
 *
 * Revision 1.4  2003/01/22 11:06:25  nali
 * variance_rholambda(): new function.
 *
 */
/* }}} */
