/*
 * Implementation of member functions of ClassHaplotype
 * $Id: haplotype.cpp,v 1.26 2003/02/05 09:49:01 nali Exp $
 */

#include "haplotype.hpp"

#include <string>
#include <sstream>
#include <cmath>
#include <cstdlib>

int ClassHaplotype::read_data (std::istream & istr,
                               int format,
                               int hapnum,
                               int nsites)
{
    char tmp;

    switch (format) {
    case 1:
        nhap = hapnum;
        // Read until first ':'
        do {
            istr >> tmp;
        } while ( tmp != ':' );
        // Read in number of loci
        istr >> nlocus;
        break;
    case 2:
        istr >> nhap >> nlocus;
        break;
    case 3:
        nhap = hapnum;
        // new hudson's format
        do {
            istr >> tmp;
        } while (tmp != ':');
        // read in number of loci
        istr >> nlocus;
        do {
            istr >> tmp;
        } while (tmp != ':');
        break;
    default:
        // default format
        istr >> nhap >> nlocus;
        break;
    }
    // Number of nonsegregation sites
    if (nsites > 0) {
        n_nonseg  = nsites - nlocus;
    }

    mappos    = std::vector<double> (nlocus, 0.0);
    // Read in map position
    for (int j = 0; j < nlocus; ++j) {
        istr >> mappos[j];
        // check if there is any pair of sites with 0 distance
        if (j > 0 && mappos[j] - mappos[j-1] == 0.0) {
            std::cerr << "Warning: the distance between sites " << j
                      << " and " << j - 1 << "is 0." << std::endl;
        }
    }

    std::vector<int> tmphap (nlocus, 0);
    haplotype.reserve (nhap * 2);

    switch (format) {
    case 1:                   // Hudson data
    case 3:
        // Read in haplotype
        for (int i = 0; i < nhap; ++i) {
            for (int j = 0; j < nlocus; ++j) {
                istr >> tmp;
                tmphap[j] = char2allele (tmp);
            }
            haplotype.push_back (tmphap);
        }
        break;
    case 2:                  // Other format, MS, etc.
        // Read in haplotype
        for (int i = 0; i < nhap; ++i) {
            for (int j = 0; j < nlocus; ++j) {
                istr >> tmphap[j];
            }
            haplotype.push_back (tmphap);
        }
        break;
    case 4:
        // read in haplotype, similar to default format but without haplotype
        // count
        for (int i = 0; i < nhap; ++i) {
            for (int j = 0; j < nlocus; ++j) {
                istr >> tmp;
                tmphap[j] = char2allele (tmp);
            }
            haplotype.push_back (tmphap);
        }
        break;
    case 5:
        // similar to above, but with affectation status
        int is_case;
        is_affected_ = std::vector<bool> (nhap);
        for (int i = 0; i < nhap; ++i) {
            istr >> is_case;
            is_affected_[i] = (is_case == 1);
            for (int j = 0; j < nlocus; ++j) {
                istr >> tmp;
                tmphap[j] = char2allele (tmp);
            }
            haplotype.push_back (tmphap);
        }
        break;
    default:
        // read in haplotype
        int ntypes (nhap);
        int typecount (0);
        nhap = 0;
        for (int i = 0; i < ntypes; ++i) {
            istr >> typecount;                        // counts for each type
            nhap += typecount;
            for (int j = 0; j < nlocus; ++j) {
                istr >> tmp;
                tmphap[j] = char2allele (tmp);
            }
            for (int j = 0; j < typecount; ++j) {
                haplotype.push_back (tmphap);
            }
        }
        break;
    }
    dbg::out (dbg::info) << "# of Haplotypes = " << nhap
                         << " # of Loci = "      << nlocus << std::endl;
    return nhap;
}

int
ClassHaplotype::get_minmut (int n, const std::vector<int> & idx) const
{
    int mut (0);
    int minmut (-1);
    assert (n > 0);
    const std::vector<int> & targethap = haplotype[idx[n]];
    for (int i = 0; i < n; ++i) {
        const std::vector<int> & sourcehap = haplotype[idx[i]];
        std::vector<int>::const_iterator j = sourcehap.begin();
        std::vector<int>::const_iterator k = targethap.begin();
        mut = 0;
        for (; j != sourcehap.end (); ++j, ++k) {
            if (*j != *k) {
                ++mut;
            }
        }
        if (minmut == -1 || minmut > mut) {
            minmut = mut;
        }
    }
    return minmut;
}


int
ClassHaplotype::get_newmut (int n, const std::vector<int> & idx) const
{
    int newmut (0);
    assert (n > 0);
    const std::vector<int> & targethap = haplotype[idx[n]];

    for (int s = 0; s < nlocus; ++s) {
        int nonpolymorphic = true;
        int observed_allele = haplotype[idx[0]][s];
        if (targethap[s] != observed_allele) {
            for (int i = 1; i < n && nonpolymorphic; ++i) {
                nonpolymorphic = haplotype[idx[i]][s] == observed_allele;
            }
            if (nonpolymorphic) {
                ++newmut;
            }
        }
    }
    return newmut;
}
