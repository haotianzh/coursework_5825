/**
 * @file   mutat.hpp
 * @author Michael Na Li
 * @date   Thu Mar 28 00:11:25 2002
 *
 * @brief  Mutation models
 *
 * $Id: mutat.hpp,v 1.8 2002/08/20 05:10:37 nali Exp $
 */

#ifndef MUTAT_HPP
#define MUTAT_HPP

#include "haplotype.hpp"
#include "popdefs.hpp"

#include "tnt/tnt.hpp"
#include "tnt/cmat.hpp"
#include "tnt/vec.hpp"
#include "dbg/dbg.hpp"

#include <vector>

double watterson (int nchr);

class Mutation
{
public :

    static const DblMat SNP;

    Mutation (int maxN, double theta)
        : maxN_ (maxN), theta_ (theta)
    {}

    virtual ~Mutation( )
    {}

    /**
     * Reset theta value
     */
    virtual void reset (double theta)
    {
        theta_ = theta;
    }

    int maxN () const
    {
        return maxN_;
    }

    double theta () const
    {
        return theta_;
    }

protected :
    int maxN_;
    double theta_;
};

class MutationSimple : public Mutation
{
public :
    MutationSimple( int maxN, double theta )
        : Mutation (maxN, theta),
          rates_ (maxN_, 2)
    {
        calc_rates_ ();
    }

    MutationSimple( int maxN )
        : Mutation (maxN, watterson (maxN)),
          rates_ (maxN_, 2)
    {
        calc_rates_ ();
    }

    void reset( double theta )
    {
        theta_ = theta;
        calc_rates_ ();
    }

    double prob_mut (int from, int to, int n) const
    {
        return from == to ? rates_[n][0] : rates_[n][1];
    }

private :
    TNT::Matrix<double> rates_;

    void calc_rates_ ();
};

class Quadrature
{
private :
    int            nquad_;
    const double * times_;
    const double * weights_;
    // Constants
    static const double QUAD4  [8];
    static const double QUAD8  [16];
    static const double QUAD16 [32];
public :
    explicit Quadrature (int nquad = 4)
        : nquad_ (nquad)
    {
        switch (nquad_) {
        case 4 :
            times_ = Quadrature::QUAD4;
            break;
        case 8 :
            times_ = Quadrature::QUAD8;
            break;
        case 16 :
            times_ = Quadrature::QUAD16;
            break;
        default :
            std::cout << "Unimplemented quadrature number:" << nquad_
                      << std::endl;
            exit (1);
        }
        weights_ = times_ + nquad_;
    }
    int n () const
    {
        return nquad_;
    }
    double t (int q) const
    {
        dbg::assertion (DBG_ASSERTION (q >= 0 && q < nquad_));
        return times_[q];
    }
    double w (int q) const
    {
        dbg::assertion (DBG_ASSERTION (q >= 0 && q < nquad_));
        return weights_[q];
    }
};

class MutationFD : public Mutation
{
public :

    static dbg::dbg_source d_src;

    MutationFD (int maxN, double theta,
                const Quadrature & q,
                int n_allele,
                int maxK = 50);

    MutationFD (int maxN,
                const Quadrature & q,
                int n_allele,
                int maxK = 50);

    MutationFD (int maxN, double theta,
                const Quadrature & q,
                const DblMat & M = Mutation::SNP,
                int maxK = 50);

    MutationFD (int maxN,
                const Quadrature & q,
                const DblMat & M = Mutation::SNP,
                int maxK = 50);

    void reset( double theta );

    int n_allele () const
    {
        return na_;
    }

    double prob_mut (int from, int to, int n, int q) const
    {
        dbg::assertion (DBG_ASSERTION (time >= 0 && q < quad.n ()));
        dbg::assertion (DBG_ASSERTION (to   >= 0 && to   < na_));
        dbg::assertion (DBG_ASSERTION (from >= 0 && from < na_));
        dbg::assertion (DBG_ASSERTION (n > 0 & n < maxN_));
        return vecQt_[n][q][from][to];
    }

    const Quadrature & quad;

private :
    int na_;
    DblMat M_;
    VecDblMat Mpower_;
    std::vector<VecDblMat> vecQt_;
    void init_Mpower_ ();
};

#endif // MUTAT_HPP

// {{{ Log
/*
 *  $Log: mutat.hpp,v $
 *  Revision 1.8  2002/08/20 05:10:37  nali
 *  move some stuff to .cpp file.
 *
 *  Revision 1.7  2002/07/08 04:16:19  nali
 *  Updated per changes in mll (dbg.h -> dbg.hpp, use of libmll.a,
 *  etc.
 *
 *  Revision 1.6  2002/04/09 00:04:01  nali
 *
 *  Return to mutation rate = theta/(n + theta)
 *
 *  Revision 1.5  2002/03/28 22:22:02  nali
 *  Fixed a bug in constructor of MutationFD
 *
 *  Revision 1.4  2002/03/28 19:17:55  nali
 *
 *  Added classes Quadrature and MutationFD.
 *
 */
// }}}
