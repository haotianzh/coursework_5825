/**
 * @file   recomb.cpp
 * @author Michael Na Li
 * @date   Wed Mar 27 14:30:40 2002
 *
 * @brief  Implementation of recomb.hpp
 *
 * $Id: recomb.cpp,v 1.9 2002/09/23 09:26:40 nali Exp $
 */

#include "recomb.hpp"

dbg::dbg_source RecombRate::dbgsrc = "RecombRate";

void
RecombRate::update_rate (double rho, double h, int interval)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    rhos_ = rho;
    if (interval >= 0 && interval < rhos_.size ()) {
        rhos_[interval] *= h;
    }
    set_rate ();
}

void
RecombRate::update_rate (double rho, double h, std::vector<int> & intervals)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    std::sort (intervals.begin (), intervals.end ());
    for (int i = 0; i < rate_.size (); ++i) {
        if (std::binary_search (intervals.begin (), intervals.end (), i)) {
            rhos_[i] = rho * h;
        } else {
            rhos_[i] = rho;
        }
    }
    set_rate ();
}

void
RecombRate::update_rate (double rho, double h,
                         double hotleft, double hotright)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    double temprate;
    for (int i = 0; i < rate_.size (); ++i) {
        double leftpos  = genmap_[i];
        double rightpos = genmap_[i+1];
        // Compute rho*d in this interval
        temprate = rho * (rightpos - leftpos);
        if (hotright > leftpos && rightpos > hotleft) {
            // there is some overlap with the hot region
            if (hotleft <= leftpos && rightpos <= hotright) {
                // completely in the hot region
                temprate *= h;
            } else if (hotleft <= leftpos && rightpos > hotright) {
                // overlap in the left
                temprate += rho * (h - 1.0) * (hotright - leftpos);
            } else if (hotleft > leftpos && rightpos <= hotright) {
                // overlap in the right
                temprate += rho * (h - 1.0) * (rightpos - hotleft);
            } else {
                // completely includes the hot region
                temprate += rho * (h - 1.0) * (hotright - hotleft);
            }
        }
        // \bar{rho} the average recombination rate
        if (mapdist_[i] > 0.0) {
            rhos_[i] = temprate / mapdist_[i];
        } else {
            rhos_[i] = temprate;
        }
    }
    set_rate ();
}

void
RecombRate::update_rate (double rho_i, int i)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    assert (i >= 0 && i < rate_.size ());
    rhos_[i] = rho_i;
    set_rate (i);
}

void
RecombRate::update_rate (double rho)
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    rhos_ = rho;
    set_rate ();
}

// {{{ Log
/*
 *  $Log: recomb.cpp,v $
 *  Revision 1.9  2002/09/23 09:26:40  nali
 *  Deal with the cases where the boundary of the hot spot overlaps
 *  with a segregating site.
 *
 *  Revision 1.8  2002/09/20 09:20:03  nali
 *  Slight update.
 *
 *  Revision 1.7  2002/09/20 08:52:46  nali
 *  some dbg statements added
 *
 *  Revision 1.6  2002/09/14 00:11:43  nali
 *  Fixed the bug introduced with adjust_rate, don't do anything if
 *  rate == 0.0.
 *
 *  Also uses dbgsrc everywhere to better control dbg info.
 *
 *  Revision 1.5  2002/07/07 01:03:55  nali
 *  removed CompositeRecombRate class.
 *
 *  Revision 1.4  2002/04/23 20:08:20  nali
 *  test CompositeRecomRate works
 *
 *  Revision 1.3  2002/04/23 16:56:18  nali
 *
 *  1.  New class CompositeRecombRate inherited from RecombRate.
 *  2.  Move member functions mean_, logPprior, calc_sigma2 out
 *      as functions.  mean_i is a friend function of HapLikelihood.
 *
 *  Revision 1.2  2002/04/22 16:16:42  nali
 *  Unfinished update to recombination model
 *
 *  Revision 1.1  2002/03/28 19:16:16  nali
 *  Move some code to .cpp files
 *
 */
// }}}
