/*
 * $Id: hotspot.cpp,v 1.41 2003/02/05 22:35:35 nali Exp $
 */
#define __MAIN_PROGRAM__ "hotspot"

#include "hotopts.hpp"

#include "gsl++/gsl_random.hpp"
#include "stat/sfunc.hpp"
#include "dbg/dbg.hpp"
#include "mll/strutil.hpp"
#include "mll/nonnum.hpp"
#include "mll/simpleoption.hpp"

#include "boost/format.hpp"
#include "mll/timer.hpp"

#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <utility>

#include <cstdlib>

const int MAXNMITER = 4000;

typedef std::pair<double, double> hotspot_t;

int main (int argc, char **argv)
{
    // {{{ Parsing command line options

    // Format flag
    // input file format
    MLL::IntOption  format_flag ('f', "format", "number 1-3",
                                 "Input file format", 0);
    // Number of populations to use, default is 0, which means all
    MLL::IntOption maxpop ('n', "npop", "number",
                           "Number of Populations to Use", 0);
    MLL::IntOption  max_iter ('i', "iteration", "number",
                              "Maximum Number of Iterations", MAXNMITER);
    MLL::IntOption  n_order ('r', "order", "number",
                             "Number of random orders", 10);
    MLL::BoolOption save_seed ('v', "save-seed", "toggle",
                               "Save Seed? (default no)", false);
    MLL::DoubleOption hotleft ('l', "lower", "number",
                               "Lower bound of the hot spot", -1.0);

    MLL::DoubleOption hotright ('u', "upper", "number",
                               "Upper bound of the hot spot", -1.0);

    MLL::BoolOption adj ('a', "adjust", "toggle",
                         "Adjust rho * d? (default yes)", true);
    MLL::BoolOption avelike ('L', "avelike", "toggle",
                               "Average Likelihod? (default yes)", true);

    MLL::StringOption out_file_name ('o', "output-file", "filename",
                                     "Output file name", "");
    MLL::StringOption input_file_name ('\0', "input-file", "filename",
                                       "Input file name", "");

    MLL::SimpleGetOption sgetopt ("hotspot",
                                  "Estimate rho and h for fixed hotspots",
                                  &format_flag,
                                  &max_iter,
                                  &n_order,
                                  &hotleft,
                                  &hotright,
                                  &maxpop,
                                  &save_seed,
                                  &adj,
                                  &avelike,
                                  &out_file_name,
                                  // this is a positional option
                                  &input_file_name,
                                  0);
    if (sgetopt.parse (argc, argv) != 0) {
        return EXIT_FAILURE;
    }

    sgetopt.print_summary (std::cout);

    // }}}

    std::vector<hotspot_t> hotspots;
    if (hotleft < 0.0 && hotright < 0.0) {
        std::cout << "No hot spot specified, do a search between 0 and 1\n";
        for (int i = 0; i < 10; ++i) {
            hotspots.push_back (hotspot_t (0.1 * i, 0.1 * (i + 1)));
        }
    } else if (hotleft < 0.0 || hotright < 0.0) {
        std::cerr << "Both left and right limit of the hot spot "
                  << "should be given!\n";
        return EXIT_FAILURE;
    } else {
        std::cout << "Specified hot spot: (" << hotleft << ", " << hotright
                  << ")" << std::endl;
        hotspots.push_back (hotspot_t (hotleft, hotright));
    }

    // Readin random seed
    unsigned long s1 = get_seed ();
    GSL::RandomGenerator rng (s1);
    GSL::UniformRandomGenerator myrand (rng);

    if (double (hotleft) > double (hotright)) {
        std::swap (hotleft, hotright);
    }

    VecPHap samples;
    int popsize = read_samples (input_file_name.c_str (),
                                samples, format_flag, maxpop);

    double theta = watterson (popsize);
    std::cout << "Mutation rate (per site, Watterson's) = "
              << theta << std::endl;

    std::ostream *out = open_outfile (out_file_name.c_str ());

    // initial values for rho
    std::vector<double> rhoinit (2, 0);
    rhoinit[1] = 1.0;

    MLL::Timer timer; // Start timing
    std::cout << "Start computing ... " << std::endl;

    // For each population
    int counter = 0;

    HapLikelihood *pHR;
    RecombRate *pR;
    MutationSimple Qsimple (popsize, theta);

    // start points and steps for Simplex algorithm
    std::vector<double> simplex_start (2, 0.0);
    std::vector<double> simplex_step  (2, 1.0);

    COptSimplex smpx;

    dbg::enable (dbg::tracing, false);
    dbg::enable (dbg::tracing, HapOptRH_Region::dbgsrc, false);
    dbg::attach_ostream (dbg::all, std::cout);

    *out << std::setw (5)  << "pop"     << ' '
         << std::setw (12) << "rhobar"  << ' '
         << std::setw (12) << "maxLbar" << ' '
         << std::setw (10) << "left"    << ' '
         << std::setw (10) << "right"   << ' '
         << std::setw (12) << "hhat"    << ' '
         << std::setw (12) << "vloghhat" << ' '
         << std::setw (12) << "h.low" << ' '
         << std::setw (12) << "h.upp" << ' '
         << std::setw (12) << "rhat"    << ' '
         << std::setw (12) << "vlogrhat" << ' '
         << std::setw (12) << "maxLhot"
         << std::endl;

    boost::format fmtOutPut ("%5d %12.6g %12.6g %10.4g %10.4g %12.6g "
                             "%12.6g %12.6g %12.6g %12.6g %12.6g %12.6g\n");

    std::pair<double, double> confItvl_H (-1.0, -1.0);

    for (ci_VecPHap sptr = samples.begin(); sptr != samples.end(); ++sptr) {
        std::cout << "\nPopulation " << counter++ << std::endl;
        if ((*sptr)->get_nlocus () <= 2) {
            std::cerr << "This population has only two sites or less."
                      << "Skipped." << std::endl;
            continue;
        }

        pR  = new RecombRate ((*sptr)->map_pos (), 0.0);
        pHR = new SDLikelihood (**sptr, Qsimple, myrand,
                                n_order, adj, avelike);

        // maximize the likelihood for rho with no hot spot
        HapOptConstRho opt_rho (pHR, pR);

        // find rhobar (background recombination rate)
        double rhobar = exp (opt_rho.minimize (rhoinit));
        double maxLike = - opt_rho.minimum ();

        std::cout << "  rhobar = " << rhobar << std::endl;

        double local_h_mle (1.0);
        double local_r_mle (rhobar);
        double local_max (0.0);

        double varLogRhoBar = -1.0;
        double varLogLambdaBar = -1.0;


        for (std::vector<hotspot_t>::const_iterator i =
                hotspots.begin (); i != hotspots.end (); ++i) {
            // Print some log information
            std::cout << "\tInterval : (" << i->first << ", "
                      << i->second << ")" << std::endl;

            simplex_start[0] = log (rhobar);
            HapOptRH_Region opt_RnH (pHR, pR, i->first, i->second);
            smpx.optimize (opt_RnH, simplex_start, simplex_step,
                           1.e-7, int (max_iter) * 2);
            local_r_mle = exp (smpx.get_optima ()[0]);
            local_h_mle = exp (smpx.get_optima ()[1]);
            local_max = - smpx.get_value ();

            variance_rholambda (opt_RnH, smpx.get_optima (),
                                &varLogRhoBar, &varLogLambdaBar);

            confItvl_H = conf_interval (
                HapOptRH_RegionSolveH (pHR, pR, i->first, i->second,
                                       local_r_mle, local_max - LOGDIFF),
                local_h_mle, true);

            *out << fmtOutPut % counter % rhobar
                % maxLike
                % i->first
                % i->second
                % local_h_mle
                % varLogLambdaBar
                % confItvl_H.first
                % confItvl_H.second
                % local_r_mle
                % varLogRhoBar
                % local_max;
        }
        delete pHR;
        delete pR;
    }

    if (out != &std::cout) {
        delete out;
    }

    std::cout << "\n\n" << std::endl;
    // Clean up
    std::for_each (samples.begin(), samples.end(), MLL::free_object ());

    // Save random seeds (append)
    if (save_seed) {
        put_seed (rng.get ());
    }

    return EXIT_SUCCESS;
}


void
variance_rholambda( HapOptRH_Region & negLogL,
                    const std::vector<double> & logPar,
                    double *pLogRhoBarVar,
                    double *pLogLambdaBarVar )
{
    dbg::trace dtrace (dbg_hotspotter, DBG_HERE);
    // step size
    static const double h2 = 1.0e-5;
    std::vector<double> logPar2 (logPar);

    double fmin = negLogL (logPar);

    // marginal of lambda
    logPar2[1] -= h2;
    double f_minus_2h = negLogL (logPar2);
    logPar2[1] += 2.0 * h2;
    double f_plus_2h = negLogL (logPar2);
    double fd_minus_h = (fmin / h2) - (f_minus_2h / h2);
    double fd_plus_h  = (f_plus_2h / h2) - (fmin / h2);
    *pLogLambdaBarVar = 1.0 / (fd_plus_h / h2 - fd_minus_h / h2);

    // marginal of rhobar
    logPar2[1] = logPar[1];
    logPar2[0] -= h2;
    f_minus_2h = negLogL (logPar2);
    logPar2[0] += 2.0 * h2;
    f_plus_2h = negLogL (logPar2);
    fd_minus_h = (fmin / h2) - (f_minus_2h / h2);
    fd_plus_h  = (f_plus_2h / h2) - (fmin / h2);
    *pLogRhoBarVar = 1.0 / (fd_plus_h / h2 - fd_minus_h / h2);
}

// {{{ Log

//
// $Log: hotspot.cpp,v $
// Revision 1.41  2003/02/05 22:35:35  nali
// Use read_samples () to read in data
//
// Revision 1.40  2003/02/05 09:48:29  nali
// Nothing changed.
//
// Revision 1.39  2003/02/05 08:59:10  nali
// remove dbg
//
// Revision 1.38  2003/02/04 10:23:21  nali
// Clean up a bit.
//
// Revision 1.37  2003/01/22 11:11:52  nali
// Updated
//
// Revision 1.36  2002/11/27 11:03:30  nali
// Use _aux.cpp code.
//
// Revision 1.35  2002/11/06 05:46:05  nali
// Added define __MAIN_PROGRAM__
//
// Revision 1.34  2002/09/25 21:43:33  nali
// keep the options available for development.
//
// Revision 1.33  2002/09/25 21:42:38  nali
// Change the default setting of -a, to use correction.
//
// Revision 1.32  2002/09/19 22:42:55  nali
// Added dbg statements
//
// Revision 1.31  2002/09/14 00:11:42  nali
// Fixed the bug introduced with adjust_rate, don't do anything if
// rate == 0.0.
//
// Also uses dbgsrc everywhere to better control dbg info.
//
// Revision 1.30  2002/09/13 05:24:39  nali
// Added option to switch between aveL and aveLogL and to use correction.
// When no hot spot is specified, search for in between 0 and 1, at 0.1
// width.
//
// Revision 1.29  2002/09/11 08:58:09  nali
// Updated hotspot, to work on a given fixed hot spot
//
// Revision 1.28  2002/07/08 04:16:19  nali
// Updated per changes in mll (dbg.h -> dbg.hpp, use of libmll.a,
// etc.
//
// Revision 1.27  2002/05/07 07:58:23  nali
// Updated
//
// Revision 1.26  2002/04/24 07:13:34  nali
// Updated
//
// Revision 1.25  2002/04/23 17:00:55  nali
// Updated in response to changes in recomb.hpp and condlike.hpp
//
// Revision 1.24  2002/04/09 00:03:32  nali
// include dbg.h
//
// Revision 1.23  2002/04/08 21:15:16  nali
// Updated, wrt new HapLikelihood.
//
// Revision 1.22  2002/03/28 19:20:39  nali
//
// Updated with new HapLikelihood classes.  Use
// a HapLikelihood * to take advantage of the
// polymorphism.
//
// Revision 1.21  2002/02/23 08:10:46  nali
// Updated some names
//
// Revision 1.20  2002/02/22 21:07:31  nali
//
// Handle the case where random.seeds doesn't exist in current
// directory.
//
// Revision 1.19  2002/02/22 09:21:15  nali
// Updated HapLikelihood for multiple orders
//
// Revision 1.18  2002/02/22 01:24:03  nali
// Updated to fully use mll
//
// Revision 1.17  2002/01/23 09:27:47  nali
// Updated
//
// Revision 1.16  2001/12/19 01:38:15  nali
// Updated to be STL comformant
//
// Revision 1.15  2001/12/17 19:25:48  nali
//
// * Merge hotspot.hpp and hotregion.hpp into one class.
// * Rid of quadrature method.
//
// Revision 1.14  2001/11/29 17:35:49  nali
// Updated
//
// Revision 1.13  2001/11/20 00:18:26  nali
//
// Not to compute likelihood curve for rho with no hot spot.
//
// Revision 1.12  2001/11/19 08:12:50  nali
//
// Added forward algorithm to computer the 'posterior' probability of
// recombination at each interval.
//
// Revision 1.11  2001/10/31 22:39:18  nali
//
// Deal with the case where there is only one site.
//
// Revision 1.10  2001/10/17 07:04:02  nali
// Updated
//
// Revision 1.9  2001/10/11 08:16:52  nali
// updated
//
// Revision 1.8  2001/10/10 20:22:10  nali
// Updated
//
// Revision 1.7  2001/10/10 07:42:59  nali
// Updated
//
// Revision 1.6  2001/10/08 09:31:57  nali
// Add reparametrization of hot region
//
// Revision 1.5  2001/10/08 07:54:05  nali
// Cleanup junk codes
//
// Revision 1.4  2001/10/05 06:44:08  nali
// Use Watterson's estimator for per site mutation rate
//
// Revision 1.3  2001/10/03 07:14:07  nali
// Jointly find mle of rho and h for fixed i
//
// Revision 1.2  2001/10/03 05:26:25  nali
// Ues per base mutation rate
//
// Revision 1.1  2001/10/02 08:21:04  nali
// quadrature recomb model
//
// Revision 1.2  2001/10/01 20:14:10  nali
// minor update
//
// Revision 1.1  2001/09/30 06:33:35  nali
// Simple recombination model
//
//

// }}}
