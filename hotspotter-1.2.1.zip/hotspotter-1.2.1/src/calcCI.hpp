/**
 * @file   calcCI.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2002/11/05 18:40:07
 *
 * @brief
 *
 * $Id: calcCI.hpp,v 1.3 2003/02/04 10:23:22 nali Exp $
 */
#ifndef _CALCCI_HPP
#define _CALCCI_HPP 1

#include "hotspotter.hpp"
#include "gsl++/gsl_roots.hpp"
#include "stat/credint.hpp"
#include "dbg/dbg.hpp"
#include "boost/format.hpp"

#include <valarray>
#include <utility>

const double LOGDIFF = 1.92;

inline
std::pair<double, double>
cred_interval( HapLikelihood *plike, RecombRate *pR,
               std::valarray<double> & grid,
               double logrhomle,
               double sigma )
{
    dbg::trace dtrace (DBG_HERE);
    int ngrid = grid.size () - 1;
    double gridend = sigma * 4;
    double gridw = gridend * 2.0 / ngrid;
    double xmin = logrhomle - gridend;
    double xmax = logrhomle + gridend;
    double x = xmin;
    boost::format fmtTrace ("rho = %f, grids[%d] = %f\n");
    for (int i = 0; i < grid.size (); ++i) {
        pR->update_rate (exp (x));
        grid[i] = plike->logL (pR);
        dbg::out (dbg::tracing) << fmtTrace % exp (x) % i % grid[i];
        x += gridw;
    }
    MLL::CredibleInterval calcCI (xmin, xmax, grid, true, true);
    boost::tuple<double, double, double> ci = calcCI.calc_interval (0.9);
    return std::make_pair (exp (boost::get<1> (ci)),
                           exp (boost::get<2> (ci)));
}

template <typename LogLikelihoodFunction>
std::pair<double, double>
conf_interval( LogLikelihoodFunction eq,
               double x, bool trace )
{
    dbg::trace dtrace (DBG_HERE);
    dbg::enable (dbg::tracing, GSL::RootSolver::dbgsrc, false);
    double rlower = 0.0;
    double rupper = 100 * x;
    dbg::out (dbg::tracing, GSL::RootSolver::dbgsrc) <<
        boost::format ("rhohat = %f, eq(%f) = %f, eq(%f) = %f\n")
        % x % rlower % eq (rlower) % rupper % eq (rupper);
    GSL::RootSolver sbrent (GSL::RootSolver::brent);
    if (eq (rlower) < 0.0) {
        rlower = sbrent.solve (eq, rlower, x, trace);
    } else {
        rlower = -1;
    }
    if (eq (rupper) < 0.0) {
        rupper = sbrent.solve (eq, x, rupper, trace);
    } else {
        rupper = -1.0;
    }
    dbg::out (dbg::tracing, GSL::RootSolver::dbgsrc) <<
        boost::format ("Confidence Interval : (%f, %f)\n") % rlower % rupper;
    return std::make_pair (rlower, rupper);
}

template <typename NegativeLogLikelihood>
double
variance_constrho( NegativeLogLikelihood & neglogLikelihood,
                   double logRhoMLE )
{
    dbg::trace dtrace (dbg_hotspotter, DBG_HERE);
    // Simple-minded way of computing the second derivative
    static const double h2 = 1.0e-5;
    double fmin       = neglogLikelihood (logRhoMLE);
    double f_minus_2h = neglogLikelihood (logRhoMLE - h2);
    double f_plus_2h  = neglogLikelihood (logRhoMLE + h2);

    double fd_minus_h = (fmin / h2) - (f_minus_2h / h2);
    double fd_plus_h  = (f_plus_2h / h2) - (fmin / h2);
    double var2 = 1.0 / (fd_plus_h / h2 - fd_minus_h / h2);

    dbg::out (dbg::tracing, dbg_hotspotter)
        << "f(x-2h) = " << f_minus_2h
        << ", f(x) = " << fmin
        << ", f(x+2h) = " << f_plus_2h << "\n"
        << "f'(x-h) = " << fd_minus_h
        << ", f'(x+h) = " << fd_plus_h << "\n"
        << "1/f''(x) = " << var2 << std::endl;
    return var2;
}


#endif /* _CALCCI_HPP */
