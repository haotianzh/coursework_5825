/*
 * $Id: fullopt.cpp,v 1.60.2.3 2003/03/28 05:42:51 nali Exp $
 */
#define __MAIN_PROGRAM__ "fullopt"

#include "haplotype.hpp"
// Header file for timer
#include "popdefs.hpp"
#include "constrho.hpp"

#include "fullopt.hpp"
#include "hotspotter.hpp"

#include "gsl++/gsl_random.hpp"
#include "gsl++/gsl_roots.hpp"
#include "gsl++/gsl_min.hpp"
#include "stat/sfunc.hpp"
#include "stat/credint.hpp"
#include "mll/strutil.hpp"
#include "mll/simpleoption.hpp"
#include "mll/timer.hpp"

#include "boost/format.hpp"

#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <numeric>

#include <cstdlib>

// Upperbound of rho_i allowed (equivalent of Infinity)
const double MAX_RHO = 40000;
const double TRIMPERCENT = 0.1;
const int MAXNMITER = 2000;

// 2.3  allows 100-fold variation with 95% prior probability
// 1.15 allows 10-fold variation with 95% prior probability
const double SIGMA = 1.15;
// Number of grid points, when discreting the posterior to compute CI
#ifdef DBG_ENABLED
const int NGRID = 100;
#else
const int NGRID = 1000;
#endif
const double GRIDEND = SIGMA * TRUNC;
const double GRIDWIDTH = GRIDEND * 2.0 / NGRID;

int main (int argc, char **argv)
{
    // {{{ Parsing command line options

    // Flags
    MLL::IntOption  format_flag ('f', "format", "number 1-3",
                                 "Input file format", 0);
    MLL::IntOption  max_iter ('i', "iteration", "number",
                              "Maximum Number of Iterations", MAXNMITER);
    MLL::IntOption  n_order ('r', "order", "number",
                             "Number of random orders", 10);
    MLL::BoolOption save_seed ('v', "save-seed", "toggle",
                               "Save Seed? (default no)", false);
    MLL::DoubleOption theta ('t', "theta", "real",
                             "The specified value for theta", -1.0);
    MLL::BoolOption adj ('a', "adjust", "toggle",
                         "Adjust rho * d? (default yes)", true);
    MLL::BoolOption twostep ('w', "twostep", "toggle",
                             "Two-step optimization (default yes)", true);
    MLL::BoolOption avelike ('L', "avelike", "toggle",
                               "Average Likelihod? (default yes)", true);
    MLL::BoolOption outputgrid ('g', "grid", "toggle",
                                "Output grid ? (default no)", false);
    MLL::BoolOption quantiles ('q', "quantiles", "toggle",
                               "Comput quantiles? (default no)", false);
    MLL::StringOption out_file_name ('o', "output-file", "filename",
                                     "Output file name", "");
    MLL::StringOption input_file_name ('\0', "input-file", "filename",
                                       "Input file name", "");

    MLL::SimpleGetOption sgetopt ("fullopt",
                                  "Estimating variable recombination rate",
                                  &format_flag,
                                  &max_iter,
                                  &n_order,
                                  &save_seed,
                                  &outputgrid,
                                  &theta,
                                  &adj,
                                  &avelike,
                                  &twostep,
                                  &quantiles,
                                  &out_file_name,
                                  // this is a positional option
                                  &input_file_name,
                                  0);

    if (sgetopt.parse (argc, argv) != 0) {
        return EXIT_FAILURE;
    }

    sgetopt.print_summary (std::cout);
    // }}}

    std::ifstream input (input_file_name.c_str()) ;
    if (input.fail ()) {
        std::cerr << "Cannot open " << input_file_name << std::endl;
        return EXIT_FAILURE;
    }

    // Readin random seed
    unsigned long s1 = get_seed ();
    GSL::RandomGenerator rng (s1);
    GSL::UniformRandomGenerator myrand (rng);

    std::cout << "SIGMA = " << SIGMA << ", NGRID = " << NGRID << std::endl;

    int numpop  (0);
    int popsize (1000);              // Population size
    int nsite   (0);                 // Total number of sites
    std::string temp;                // Temporary variable
    if (format_flag == 1) {
        // use stdin as input, read in hudson format
        input >> temp;
        input >> popsize;
        input >> nsite;
        input >> temp >> temp >> temp;
        input >> numpop;
    } else if (format_flag == 2) {
        // read in number of populations
        input >> numpop >> popsize >> nsite;
    } else if (format_flag == 3) {
        // new Hudson's format
        input >> temp;
        input >> popsize;
        input >> numpop;
    }

    ClassHaplotype sample_data (input, format_flag, popsize, nsite);
    input.close();
    std::cout << "Finished reading data\n" << std::endl;

    if (sample_data.get_nlocus () == 0) {
        std::cerr << "Should at least have 2 or more sites." << std::endl;
        return EXIT_FAILURE;
    }

    popsize = sample_data.size ();
    if (theta < 0.0) {
        theta = watterson (popsize);
    }
    std::cout << "Mutation rate (per site, Watterson's) = "
              << theta << std::endl;

    MutationSimple Qsimple (popsize, theta);
    RecombRate *pR = new RecombRate (sample_data.map_pos (), 0.0);
    HapLikelihood *pHR = new SDLikelihood (sample_data, Qsimple, myrand,
                                           n_order, adj, avelike);
    std::ostream *out = open_outfile (out_file_name.c_str ());

    dbg::enable (dbg::info, true);
    dbg::enable_all (dbg::info, true);
    dbg::attach_ostream (dbg::all, std::cout);

    MLL::Timer timer; // Start timing

    // Find the MLE for rho with no hot spot
    HapOptConstRho optrho (pHR, pR);

    // Starting values for rho, on a log scale
    std::vector<double> rhoinit (2, 0.0);
    rhoinit[1] = 1.0;
    double logRhoBar = optrho.minimize (rhoinit);  // on log scale
    double cLLmax  = - optrho.minimum ();

    std::cout << "\nWith no hot spot, rho_hat = " << exp (logRhoBar)
              << "\tlogL = " << cLLmax << "\n" << std::endl;

    pR->update_rate (exp (logRhoBar));
    int nInterval = pR->size ();

    std::cout << "Use Numeric Recipe's Nelder-Mead Implementation."
              << std::endl;

    // initial values and steps for Nelder-Mead alorigthm
    std::vector<double> rinits ((twostep ? nInterval : nInterval + 1),
                                logRhoBar);
    std::vector<double> rsteps (rinits.size (), 1.0);

    COptSimplex opt;      // optimizer
    HapFullOptNR * fobj;

    if (twostep) {
        fobj = new HapRhoSmoothedTwoStep (pHR, pR, logRhoBar, SIGMA);
    } else {
        fobj = new HapRhoSmoothed (pHR, pR, SIGMA);
    }

    opt.optimize (*fobj, rinits, rsteps, 1.0e-07,
                  int (max_iter) * rinits.size ());

    rinits = opt.get_optima ();             // now the MLE's, on log scale
    cLLmax = - opt.get_value ();

    if (!twostep) {
        logRhoBar = rinits.back ();
    }

    std::cout << "\n\nMaximum Log Likelihood = " << cLLmax
              << ", rhobar = " << exp (logRhoBar) << std::endl;
    pR->update_rate (rinits.begin (), rinits.begin () + nInterval, true);

    std::vector<double> probs (19, 0.05);
    std::partial_sum (probs.begin (), probs.end (), probs.begin ());
    std::valarray<double> grids (NGRID + 1);

    boost::tuple<double, double, double> ci;
    std::vector<double> quants (probs);

    boost::format dblfmt ("%12.6g ");
    *out << boost::format ("%5s %12s %12s %12s")
        % "i" % "position" % "rhobar" % "rhohat";

    if (quantiles) {
        *out << boost::format (" %12s %12s") % "lower" % "upper";
        for (std::vector<double>::const_iterator i = probs.begin ();
                i != probs.end (); ++i) {
            *out << boost::format (" C%d ") % int (*i * 100);
        }
    }
    *out << std::endl;

    for (int i = 0; i < nInterval; ++i) {
        *out << boost::format ("%5d %12.6g %12.6g %12.6g")
            % i % sample_data.map_pos (i) % exp (logRhoBar)
            % exp (rinits[i]);
        // For each interval
        if (quantiles) {
            pR->update_rate (rinits.begin (), rinits.begin () + nInterval,
                             true);
            double x = logRhoBar - GRIDEND;
            for (int j = 0; j < grids.size (); ++j) {
                grids[j] = fobj->logprob (exp (x), i);
                if (outputgrid) {
                    std::cout << std::setw (5)  << i << " "
                        << std::setw (5)  << j << " "
                        << std::setw (12) << exp (x) << "  "
                        << std::setw (12) << grids[j] << std::endl;
                }
                x += GRIDWIDTH;
            }
            MLL::CredibleInterval cicalc (logRhoBar - GRIDEND,
                                          logRhoBar + GRIDEND,
                    grids, true, true);
            ci = cicalc.calc_interval (0.90);

            *out << boost::format (" %12.6g %12.6g ")
                % exp (boost::get<1> (ci)) % exp (boost::get<2> (ci));
            // Now we also want the posterior quantiles
            for (std::size_t i = 0; i != probs.size (); ++i) {
                quants[i] = cicalc.quantile (probs[i]);
                *out << dblfmt % exp (quants[i]);
            }
        }
        *out << std::endl;
    }
    delete fobj;

    // Last position
    *out << boost::format ("%5d %12.6g %12.6g %12.6g")
        % nInterval % sample_data.map_pos (nInterval) % exp (logRhoBar)
        % exp (rinits[nInterval-1]);
    if (quantiles) {
        *out << boost::format (" %12.6g %12.6g ")
            % exp (boost::get<1> (ci)) % exp (boost::get<2> (ci));
        for (std::size_t i = 0; i != probs.size (); ++i) {
            *out << dblfmt % exp (quants[i]);
        }
    }
    *out << std::endl;

    if (out != &std::cout) {
        delete out;
    }
    delete pHR;
    delete pR;

    // Save random seeds (append)
    if (save_seed) {
        put_seed (rng.get ());
    }
    return EXIT_SUCCESS;
}
