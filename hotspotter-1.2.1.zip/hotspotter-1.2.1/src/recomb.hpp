/**
 * @file   recomb.hpp
 * @author Michael Na Li
 * @date   Thu Mar 28 00:23:33 2002
 *
 * @brief  Recombination Model
 *
 * $Id: recomb.hpp,v 1.45 2002/11/06 05:49:54 nali Exp $
 */

#ifndef RECOMB_HPP
#define RECOMB_HPP

#include "tnt/tnt.hpp"
#include "tnt/vec.hpp"
#include "stat/distr.hpp"
#include "dbg/dbg.hpp"

#include <vector>
#include <valarray>
#include <stdexcept>

#include <cmath>

inline
double
rrate_m( double rate, int n )
{
    return 1.0 - exp (- rate / n);
}

inline
double
rrate_nm( double rate, int n )
{
    return rate / (rate + n);
}


class RecombRate
{
public:
    static dbg::dbg_source dbgsrc;

    typedef std::valarray<double> vec_t;

    explicit RecombRate (const std::vector<double> &, double rho = 0.0);

    ~RecombRate ()
    {}

    /**
     * Update rho_i with a set of invervals being hot
     */
    void update_rate (double, double, std::vector<int> &);
    /**
     * Update rho_i with one hot spot interval
     */
    void update_rate (double, double, int);
    /**
     * Update rho_i for a hot region
     */
    void update_rate (double, double, double, double);
    /**
     * Update rho in one interval, -1 is all interval
     */
    void update_rate (double, int);

    /**
     * Update rho for all intervals to a constant
     */
    void update_rate (double);

    template <typename VecToR>
    void update_rate (const VecToR &, bool = true);

    template <typename ForwardIteratr>
    void update_rate (ForwardIteratr b, ForwardIteratr e, bool = true);

    const vec_t & rhos    () const;
    const vec_t & rates   () const;
    const vec_t & mapdist () const;

    double rate( int ) const;
    double rate( double, int ) const;

    double mappos (int) const;
    int size () const;

private:
    vec_t rhos_;
    const std::vector<double> & genmap_;
    vec_t mapdist_;
    vec_t rate_;

    /* After updating rho_i, update recombination rate in interval
       rho_i * d_i */
    void set_rate ();
    void set_rate (int i);
};

// {{{ Inline Functions of RecombRate

inline
RecombRate::RecombRate (const std::vector<double> & genmap,
                        double rho)
    : rhos_  (rho, genmap.size () - 1),
      genmap_ (genmap),
      mapdist_ (rhos_.size ()),
      rate_  (rhos_.size ())
{
    for (std::size_t i = 0; i < mapdist_.size (); ++i) {
        mapdist_[i] = genmap_[i+1] - genmap_[i];
    }
    set_rate ();
}

inline
const RecombRate::vec_t &
RecombRate::mapdist () const
{
    return mapdist_;
}

inline double
RecombRate::mappos (int i) const
{
    if (i < 0 || i >= genmap_.size ()) {
        throw std::out_of_range ("RecombRate::mappos");
    }
    return genmap_[i];
}

inline
const RecombRate::vec_t &
RecombRate::rhos () const
{
    return rhos_;
}

inline
const RecombRate::vec_t &
RecombRate::rates () const
{
    return rate_;
}

inline
double
RecombRate::rate( int i ) const
{
    dbg::assertion (DBG_ASSERTION (i >= 0));
    dbg::assertion (DBG_ASSERTION (i < rate_.size ()));
    return rate_[i];
}

inline double
RecombRate::rate (double d, int i) const
{
    dbg::assertion (DBG_ASSERTION (i >= 0));
    dbg::assertion (DBG_ASSERTION (i < rate_.size ()));
    return d * rhos_[i];
}

inline int
RecombRate::size () const
{
    // Number of intervals = number of sites - 1
    return rate_.size ();
}

template <typename VecToR>
inline void
RecombRate::update_rate (const VecToR & rhos, bool logscale)
{
    assert (rhos.size () == rate_.size ());
    for (int i = 0; i < rate_.size (); ++i) {
        rhos_[i] = logscale ? exp (rhos[i]) : rhos[i];
    }
    set_rate ();
}

template <typename ForwardIteratr>
inline void
RecombRate::update_rate (ForwardIteratr b, ForwardIteratr e,
                         bool logscale)
{
    assert (std::distance (b, e) >= rhos_.size ());
    for (int i = 0; i < rhos_.size (); ++i, ++b) {
        rhos_[i] = logscale ? exp (*b) : *b;
    }
    set_rate ();
}

inline
void
RecombRate::set_rate ()
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    rate_ = rhos_ * mapdist_;
}

inline
void
RecombRate::set_rate (int i)
{
    rate_[i] = rhos_[i] * mapdist_[i];
}

// }}}

#endif // RECOMB_HPP

// {{{ Log
/*
 *  $Log: recomb.hpp,v $
 *  Revision 1.45  2002/11/06 05:49:54  nali
 *  added on dbg::trace
 *
 *  Revision 1.44  2002/09/14 00:11:43  nali
 *  Fixed the bug introduced with adjust_rate, don't do anything if
 *  rate == 0.0.
 *
 *  Also uses dbgsrc everywhere to better control dbg info.
 *
 *  Revision 1.43  2002/09/13 05:16:49  nali
 *
 *  recomb.hpp: removed adjust_rho_m() function.
 *
 *  Revision 1.42  2002/09/12 08:07:13  nali
 *  Correction?? Not done yet.  Switch or built it??
 *
 *  Revision 1.41  2002/09/02 08:20:11  nali
 *  enable adjustment again
 *
 *  Revision 1.40  2002/08/20 07:19:17  nali
 *  1. remove AdjustedRecombRate class.
 *  2. New functions rrate_m and rrate_nm to simplify rate () member function
 *     so that there both SD and FD can share the same RecombRate.
 *
 *  Revision 1.39  2002/07/25 20:50:49  nali
 *  Adde conditional compilation for AVERAGE_LOG
 *
 *  Revision 1.38  2002/07/16 06:52:22  nali
 *  REMOVED: old junk code (FDLikelihood).
 *
 *  FIXED: a bug when the rate is zero (two adjacent sites
 *  have zero distance, it happens with simulated data when
 *  the number of segregating sites is large compared with
 *  the total number of sites, 100 versus 5000), pow (rate * 0.2)
 *  is NaN.
 *
 *  Revision 1.37  2002/07/15 07:40:40  nali
 *  updated adjustment
 *
 *  Revision 1.36  2002/07/12 01:12:58  nali
 *  New adjustment
 *
 *  Revision 1.35  2002/07/08 04:16:19  nali
 *  Updated per changes in mll (dbg.h -> dbg.hpp, use of libmll.a,
 *  etc.
 *
 *  Revision 1.34  2002/07/07 01:03:55  nali
 *  removed CompositeRecombRate class.
 *
 *  Revision 1.33  2002/06/05 20:49:26  nali
 *  Now pacld runs.
 *
 *  Revision 1.32  2002/05/10 17:03:46  nali
 *  rename update_rate_log to update_rate, added a logscale parameter
 *
 *  Revision 1.31  2002/05/09 17:45:22  nali
 *  implementing gamma prior for recombination rates
 *
 *  Revision 1.30  2002/05/09 06:16:39  nali
 *  Updated
 *
 *  Revision 1.29  2002/05/07 07:58:24  nali
 *  Updated
 *
 *  Revision 1.28  2002/05/02 05:50:38  nali
 *  dbg related
 *
 *  Revision 1.27  2002/04/29 23:07:42  nali
 *  last revision of bias correction formula
 *
 *  Revision 1.26  2002/04/25 05:52:34  nali
 *  Updated
 *
 *  Revision 1.25  2002/04/24 20:42:05  nali
 *  revised
 *
 *  Revision 1.24  2002/04/24 07:13:34  nali
 *  Updated
 *
 *  Revision 1.23  2002/04/23 20:08:21  nali
 *  test CompositeRecomRate works
 *
 *  Revision 1.22  2002/04/23 16:56:18  nali
 *
 *  1.  New class CompositeRecombRate inherited from RecombRate.
 *  2.  Move member functions mean_, logPprior, calc_sigma2 out
 *      as functions.  mean_i is a friend function of HapLikelihood.
 *
 *  Revision 1.21  2002/04/22 16:16:42  nali
 *  Unfinished update to recombination model
 *
 *  Revision 1.20  2002/04/08 21:13:08  nali
 *  1.  Removed method prob_trans ().
 *  2.  Removed member useFD_, instead, pass it
 *  as an argument to rate ().
 *
 *  Revision 1.19  2002/03/28 19:18:28  nali
 *
 *  Added member useFD_.
 *
 */
// }}}
