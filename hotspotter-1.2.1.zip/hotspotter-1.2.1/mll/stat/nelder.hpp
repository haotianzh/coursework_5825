/**
 * @file   nelder.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   Tue Mar 19 10:48:19 2002
 *
 * @brief  A class for function minimization using the Nelder-Mead algorithm.
 *
 * Converted from minim.f90 by Alan Miller.
 *
 * $Id: nelder.hpp,v 1.12 2002/08/27 00:43:42 nali Exp $
 */

#ifndef NELDER_HPP
#define NELDER_HPP

#include "tnt/tnt.hpp"
#include "tnt/vec.hpp"
#include "tnt/cmat.hpp"
#include "tnt/lu.hpp"
#include "stat/sfunc.hpp"
#include "dbg/dbg.hpp"

#include <vector>
#include <iostream>
#include <iomanip>
#include <numeric>
#include <stdexcept>

#include <cmath>

namespace MLL
{

class NelderMead
{
public:

    typedef TNT::Matrix<double> matrix_type;
    typedef TNT::Vector<double> vector_type;
    typedef vector_type state_type;
    typedef std::vector<state_type> simplex_type;

    NelderMead (int nop,
                bool trace = true,
                bool quad = true,
                double stopcr = 1.0e-7,
                double simp = 1.0e-15,
                int maxeval = 0,
                int nloop   = 0)
        : nop_     (nop),
          nap_     (nop_),
          nap1_    (nop_ + 1),
          minima_  (nop_, 0.0),
          minval_  (0.0),
          covar_   (nop_, nop_, 0.0),
          var_     (nop_, 0.0),
          simplex_ (nop_ + 1, minima_),
          fvals_   (nop_ + 1),
          tovary_  (nop_, true),
          stopcr_  (stopcr),
          simp_    (simp),
          quad_    (quad),
          nloop_   (nloop   == 0 ?  2 * nop_ : nloop),
          maxeval_ (maxeval == 0 ? 20 * nop_ : maxeval),
          trace_  (trace),
          pbar_    (minima_),
          pstar_   (minima_),
          pstst_   (minima_)

    {

    }

    /**
     * @brief The main interface for function minimization.
     *
     * @param func             Template parameter, a function object.
     * @param start
     * @param step
     *
     * @return
     */
    template <typename functor_type>
    void minim (functor_type &, const state_type &, const state_type &);

    state_type get_min () const;

    double get_fmin () const;

    vector_type get_var () const;

    const matrix_type & get_cov () const;

    static dbg::dbg_source dbgsrc;

private:

    //* Number of parameters to maximize, including any to be held fixed
    int nop_;
    int nap_;
    int nap1_;   // nap_ + 1
    //* The final value of the minimization
    state_type minima_;
    //* The minimal function value
    double minval_;
    //* The inverse of the information matrix
    matrix_type covar_;
    vector_type var_;
    //* The simplex and the function values at the vertices, both should have
    //* length nap_ + 1.
    simplex_type simplex_;
    vector_type fvals_;

    std::vector<bool> tovary_;

    double stopcr_;
    double simp_;
    bool quad_;
    int nloop_;
    int maxeval_;
    bool trace_;

    state_type pbar_;
    state_type pstar_;
    state_type pstst_;

    template <typename functor_type>
    void real_minim_ (functor_type &);

    /* Test for convergence.
     * Return 1 if converged, 0 if not, -1 if maxeval exceeded ant not yet
     * converged. */
    template <typename functor_type>
    bool converge_test_ (functor_type &);

    template <typename functor_type>
    void quadfit_ (functor_type &);
};

dbg::dbg_source NelderMead::dbgsrc = "NelderMead";

template <typename functor_type>
void
NelderMead::real_minim_ (functor_type & func)
{
    dbg::trace trace (DBG_HERE);

    double hstar (0.0);
    double hstst (0.0);

    static const double a = 1.0;        // reflection coefficient
    static const double b = 0.5;        // constraction coefficient
    static const double c = 2.0;        // expansion coefficient

    // start of main cycle
    bool cont_iter (true);
    int loop (0);
    while (cont_iter) {
        // find the max and min values for current simplex
        int imax = 0;
        int imin = 0;
        double hmax = fvals_[imax];
        double hmin = fvals_[imin];
        for (int i = 1; i < nap1_; ++i) {
            if (fvals_[i] > hmax) {
                imax = i;
                hmax = fvals_[imax];
            } else if (fvals_[i] < hmin) {
                imin = i;
                hmin = fvals_[imin];
            }
        }

        // find the centroid of the vertices other than simplex[imax]
        pbar_ = 0.0;
        for (int i = 0; i < nap1_; ++i) {
            if (i != imax) {
                pbar_ += simplex_[i];
            }
        }
        pbar_ /= double (nap_);

        // reflect maximum through pbar_ to pstar_
        // hstar = function value at pstar_
        pstar_ = a * (pbar_ - simplex_[imax]) + pbar_;
        hstar = func (pstar_);

        // if hstar < hmin, reflect pbar_ (the centroid) through pstar_ (the
        // reflected maximum).
        // hstst = function value at pstst_
        if (hstar < hmin) {
            pstst_ = c * (pstar_ - pbar_) + pbar_;
            hstst = func (pstst_);
            if (hstst > hmin) {
                // replace maximum point by pstar_ and fvals[imax] by hstar_
                simplex_[imax] = pstar_;
                fvals_[imax]   = hstar;
            } else {
                // replace maximum point by pstst_ and fvals[imax] by hstst_
                simplex_[imax] = pstst_;
                fvals_[imax]   = hstst;
            }
        } else {
            // hstar >= hmin
            // test whether it is < fval at some point other than
            // simplex[imax].  If it is, replace simplex[imax] by pstar_
            // and fvals[imax] by hstar
            bool anylarger = false;
            for (int i = 1; i < nap1_ && ! anylarger; ++i) {
                if (hstar < fvals_[i] && i != imax) {
                    simplex_[imax] = pstar_;
                    fvals_[imax] = hstar;
                    anylarger = true;
                }
            }

            if (! anylarger) {
                // hstar > all function values except perhaps hmax
                // if hstar <= hmax, replace simplex[imax] by pstar and
                // hmax by hstar
                if (hstar <= hmax) {
                    simplex_[imax] = pstar_;
                    fvals_[imax] = hmax = hstar;
                }

                // contracted step to the point pstst
                // hstst = function value at pstst
                pstst_ = b * simplex_[imax] + (1.0 - b) * pbar_;
                hstst  = func (pstst_);

                // if hstst < hmax, replace simplex[imax] by pstst and hmax
                // by hstst
                if (hstst <= hmax) {
                    simplex_[imax] = pstst_;
                    fvals_[imax] = hstst;
                } else {
                    // shrink the simplex by replacing each point, other than
                    // the current minimum, by a point mid-way between its
                    // current position and the minimum
                    for (int i = 0; i < nap1_; ++i) {
                        if (i != imin) {
                            for (int j = 0; j < nop_; ++j) {
                                if (tovary_[j]) {
                                    simplex_[i][j] += simplex_[imin][j];
                                    simplex_[i][j] /= 2.0;
                                }
                            }
                            fvals_[i] = func (simplex_[i]);
                        }
                    }
                }
            }
        }

        if (loop == nloop_) {        // test for convergence
            loop = 0;
            // false if either converged or max no. of function evalution
            // exceeded
#ifdef DBG
            dbg::out (dbg::tracing, dbgsrc) << "\nTest for convergence.\n"
                                            << std::endl;
#endif // DBG
            cont_iter = converge_test_ (func);
        } else {
            ++loop;
        }
    }
}


template <typename functor_type>
bool
NelderMead::converge_test_ (functor_type & func)
{
    dbg::trace dbg_trace (DBG_HERE);

    static double savemn = 0.0;
    static int iflag = 0;
    bool moreiter (false);

    // calculate the mean and standard deviation of function values for the
    // current simplex
    double hmean = std::accumulate (fvals_.begin (),
                                    fvals_.begin () + nap1_, 0.0) / nap1_;
    double hstd  (0.0);
    for (int i = 0; i < nap1_; ++i) {
        hstd += MLL::pow<2u> (fvals_[i] - hmean);
    }
    hstd = std::sqrt (hstd / nap1_);

    if (hstd > stopcr_ && func.neval () <= maxeval_) {
        // not yet converged
        iflag = 0;
        moreiter = true;
    } else {
        moreiter = false;

        // Find the centroid of the current simplex and the function value
        minima_ = 0.0;
        for (simplex_type::const_iterator i = simplex_.begin ();
             i != simplex_.begin () + nap1_; ++i) {
            minima_ += *i;
        }
        minima_ /= nap1_;
        minval_ = func (minima_);

        if (func.neval () > maxeval_) {
            // the no of function evaluations allowed has been overrun
            if (trace_) {
                std::cout.setf (std::ios::scientific);
                std::cout << " No. of function evaluations > " << maxeval_
                          << "\n"
                          << " RMS of function values of last simplex = "
                          << std::setw (14) << std::setprecision (6) << hstd
                          << "\n Centroid of last simplex =\n"
                          << minima_
                          << "\n Function value at centroid = "
                          << std::setw (14) << std::setprecision (6)
                          << minval_ << std::endl;
                std::cout.setf (std::ios::scientific);
            }
        } else {
            // convergence criterion satisfied
            if (trace_) {
                std::cout << " Evidence of convergence\n"
                          << " Centroid of last simplex =\n"
                          << minima_ << "\n"
                          << " Function value at centroid = "
                          << minval_ << std::endl;
            }
            if (iflag == 0 || std::abs (savemn - hmean) > stopcr_) {
                // let's try the main cycle one more time to make sure
                // it has converged properly.
                moreiter = true;
                iflag = 1;
                savemn = hmean;
            }
        }
    }
    return moreiter;
}

template <typename functor_type>
void
NelderMead::quadfit_ (functor_type & func)
{
    dbg::trace dbg_trace (DBG_HERE);

    if (trace_) {
        std::cout << " Fitting quadrature surface about supposed minimum."
                  << std::endl;
    }
    // Expand the final simplex, if necessary, to overcome rounding errors
    double hmin = minval_;
    // Current number of function evaluations
    int nfunc = func.neval ();
    for (int i = 0; i < nap1_; ++i) {
        while (std::abs (fvals_[i] - minval_) < simp_) {
#ifdef DBG_ENABLED
            dbg::out (dbg::tracing, dbgsrc) << "Expanding simplex ... "
                                            << std::endl;
#endif // DBG_ENABLED
            for (int j = 0; j < nop_; ++j) {
                if (tovary_[j]) {
                    simplex_[i][j] += simplex_[i][j] - minima_[j];
                }
                pstst_[j] = simplex_[i][j];
            }
            fvals_[i] = func (pstst_);
            if (fvals_[i] < hmin) {
                hmin = fvals_[i];
            }
            if (func.neval () > maxeval_) {
                std::cout << " Maximum number of function evaluation exceeded."
                          << " Cannot expand the simplex" << std::endl;
                break;
            }
        }
    }

    // function values are calculated at an additional NAP points
    vector_type aval (nap_, 0.0);
    for (int i = 0; i < nap_; ++i) {
        pstar_ = (simplex_[i] + simplex_[i+1]) * 0.5;
        aval[i] = func (pstar_);
    }

    // The matrix of estimated second derivatives is calculated and its lower
    // triangle stored in the symmetric matrix bmat
    double a0 = fvals_[0];
    double hstst (0.0);
    matrix_type bmat (nap_, nap_, 0.0);
    for (int i = 0; i < nap_; ++i) {
        for (int j = 0; j < i; ++j) {
            pstst_ = (simplex_[i+1] + simplex_[j+1]) * 0.5;
            hstst = func (pstst_);
            bmat[j][i] = bmat [i][j] = 2.0 * (hstst + a0 - aval[i] - aval[j]);
        }
        bmat[i][i] = 2.0 * (fvals_[i+1] + a0 - 2.0 * aval[i]);
    }

    // The vector of estimated first derivatives is calculated and stored in
    // aval
    for (int i = 0; i < nap_; ++i) {
        aval[i] = 2.0 * aval[i] - 0.5 * (fvals_[i+1] + 3.0 * a0);
    }

    if (trace_) {
        std::cout << "\n Estimated first derivatives: \n\n"
                  << aval << '\n'
                  << " Estimated second derivatives: \n\n"
                  << bmat << std::endl;
    }

    // The matrix Q of Nelder & Mead is calculated and stored in simplex_
    pbar_ = simplex_[0];
    for (int i = 0; i < nap_; ++i) {
        simplex_[i] = simplex_[i+1] - pbar_;
    }

    // invert bmat
    int ifault = TNT::LU_inverse (bmat);
    if (ifault != 0) {
        std::cout << " bmat not +VE definite." << std::endl;
    }

    if (trace_) {
        std::cout << " \nThe inverse of bmat is:  " << bmat << std::endl;
    }

    // bmat * aval / 2 is calculated and stored in h
    vector_type h = TNT::matmult (bmat, aval);
    // find the position, pmin & value, ymin of the minimum of the quadrature
    double ymin = a0 - TNT::dot_prod (h, aval);
    for (int i = 0; i < nop_; ++i) {
        pstst_[i] = 0.0;
        for (int j = 0; j < nap_; ++j) {
            pstst_[i] += h[j] * simplex_[j][i];
        }
    }
    pbar_ -= pstst_;
    if (trace_) {
        std::cout << " Minimum of quadratic surface = " << ymin
                  << " at\n" << pbar_ << '\n'
                  << " If this differs by much from the minimum estimated\n "
                  << " from the minimization.  The minimum may be false or\n"
                  << " the information matrix may be inaccurate." << std::endl;
    }
    // Q * bmat * Q' / 2 is calculated and its lower triangle stored in VC
    for (int i = 0; i < nop_; ++i) {
        for (int j = 0; j < nap_; ++j) {
            h[j] = 0.0;
            for (int k = 0; k < nap_; ++k) {
                h[j] += 0.5 * bmat[j][k] * simplex_[k][i];
            }
        }
        for (int j = 0; j < nop_; ++j) {
            covar_[i][j] = 0.0;
            for (int k = 0; k < nap_; ++k) {
                covar_[i][j] += h[k] * simplex_[k][j];
            }
        }
        // copy the diagonal elements of covar_ into var_
        var_[i] = covar_[i][i];
    }

    if (trace_) {
        std::cout << "\n The Inverse of the information matrix: \n\n"
                  << covar_ << "\n\n"
                  << " If the function minimized was - LOG (LIKELIHOOD), \n"
                  << " this is the covariance matrix of the parameters.\n"
                  << " If the function was a sum of squares of residues,\n"
                  << " this matrix must be multiplied by twice the estimated\n"
                  << " residual variace to obtain the covariance matrix.\n"
                  << std::endl;
        std::cout << " Note: A further " << func.neval () - nfunc
                  << " function evaluations have been used.\n" << std::endl;
    }
}

template <typename functor_type>
void
NelderMead::minim (functor_type & func,
                   const state_type & start,
                   const state_type & step)
{
    dbg::trace dbg_trace (DBG_HERE);

    if (trace_ > 0) {
        std::cout << "\n Nelder-Mead direct search function minimizer\n"
                  << std::endl;
    }

    // Total number of parameters
    dbg::assertion (DBG_ASSERTION(nop_ == step.size ()));
    dbg::assertion (DBG_ASSERTION(start.size () <= step.size ()));

    // number of parameters to be varied, i.e, with step != 0.0
    nap_ = 0;
    for (int i = 0; i < nop_; ++i) {
        if (step[i] > 0.0 || step[i] < 0.0) {         // nonzero
            tovary_[i] = true;
            ++nap_;
        } else {
            tovary_[i] = false;
        }
    }

    if (trace_) {
        std::cout << " Total No. of parameters = " << nop_ << "\n"
                  << " No. of parameters to minimize =  " << nap_ << std::endl;
    }

    // If nap_ == 0, evaluate function at the starting point and return
    minima_ = start;
    if (nap_ == 0) {
        minval_ = func (minima_);
        return;
    }

    // Set up the initial simplex
    int irow = 1;
    simplex_[0] = minima_;
    for (int j = 0; j < nop_; ++j) {
        if (tovary_[j]) {               // nonzero
            simplex_[irow] = minima_;
            simplex_[irow++][j] = minima_[j] + step[j];
        }
    }

    nap1_ = nap_ + 1;
    // evaluate the function at the simplex points
    for (int i = 0; i < nap1_; ++i) {
        fvals_[i] = func (simplex_[i]);
    }

    real_minim_ (func);

    if (trace_) {
        std::cout.setf (std::ios::scientific);
        std::cout << " Minimal found after " << std::setw (5)
                  << func.neval () << " function evaluations.\n"
                  << " Minimal at \n" << minima_ << '\n'
                  << " Function value at minimum = "
                  << std::setw (14) << std::setprecision (6)
                  << minval_ << std::endl;
        std::cout.setf (std::ios::scientific);
    }

    if (quad_) {
        quadfit_ (func);
    }
}


inline
NelderMead::state_type
NelderMead::get_min () const
{
    return minima_;
}

inline
double
NelderMead::get_fmin () const
{
    return minval_;
}

inline
NelderMead::vector_type
NelderMead::get_var () const
{
    return var_;
}

const
NelderMead::matrix_type &
NelderMead::get_cov () const
{
    return covar_;
}

}  // namespace MLL

#endif // NELDER_HPP
