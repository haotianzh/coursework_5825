/**
 * @file   credint.cpp
 * @author Michael Na Li
 * @date   Thu Jul 25 15:54:30 2002
 *
 * @brief  Implementation of credint.hpp
 *
 * \$Id: credint.cpp,v 1.5 2002/09/14 03:04:17 nali Exp $
 */

#include "stat/credint.hpp"
#include <iostream>

namespace MLL
{

dbg::dbg_source
CredibleInterval::dbgsrc = "CredibleInterval";

boost::tuple<double, double, double>
CredibleInterval::calc_interval( double perc )
{
    dbg::trace trace (dbgsrc, DBG_HERE);
    std::size_t left  = modeindex_;
    std::size_t right = modeindex_;
    double totala = 0.0;
    if (perc < 0.0) {
        std::cerr << "Invalid argument " << perc << " < 0" << std::endl;
    }
    while (totala < perc) {
        if (left == 0 && right == fk_.size () - 1) {
            std::cerr << "Total area under the whole interval < "
                      << perc << std::endl;
            break;
        } else if (left == 0 || (right != fk_.size () - 1 &&
                                 fk_[left-1] < fk_[right+1])) {
            totala += area_[right];
            ++right;
        } else {
            totala += area_[left - 1];
            --left;
        }
#ifdef DBG_ENABLED
        dbg::out (dbg::tracing, dbgsrc) << "Area = " << totala
                                        << ", left = " << left
                                        << ", right = " << right
                                        << std::endl;
#endif // DBG_ENABLED
    }
    return boost::make_tuple (totala, a_ + w_ * left, a_ + w_ * right);
}

void
CredibleInterval::compute_areas_and_find_mode_( bool logscale,
                                                bool normalize )
{
    dbg::trace trace (dbgsrc, DBG_HERE);
    if (logscale) {
        if (normalize) {
            fk_ -= fk_.max ();
        }
        fk_ = fk_.apply (exp);
    } else if (normalize) {
        fk_ /= fk_.max ();
    }
    double fmin = fk_.min ();
    if (fmin < 0.0) {
        std::cerr << "Likelihoods should be greater than 0! "
                  << "min (f) = " << fmin << std::endl;
    }
    double total_area = 0;
    for (std::size_t i = 0; i < area_.size (); ++i) {
        if (fk_[i] > fk_[modeindex_]) {
            modeindex_ = i;
        }
        area_[i] = (fk_[i] + fk_[i+1]) * w_ / 2.0;
        total_area += area_[i];
    }
    
    std::cout << "Total area under curve is " << total_area << std::endl;

    if (normalize) {
#ifdef DBG_ENABLED
        dbg::out (dbg::info, dbgsrc) << "Normalize the areas." << std::endl;
#endif
        area_ /= total_area;
    }
}

double
CredibleInterval::quantile( double prob, bool upper )
{
    dbg::trace trace (dbgsrc, DBG_HERE);
    if (prob < 0 || prob > 1) {
        throw std::invalid_argument ("prob outside of [0, 1]");
    }
    if (upper) {
        prob = 1.0 - prob;
    }
    double accuarea = 0.0;
    double quant = a_;
    for (std::size_t i = 0; i < area_.size (); ++i) {
        if (accuarea >= prob) {
            quant += w_ * i;
            break;
        }
        accuarea += area_[i];
    }
    return quant;
}

}

/**
 * {{{ Log
 *
 * $Log: credint.cpp,v $
 * Revision 1.5  2002/09/14 03:04:17  nali
 * Added #ifdef DBG_ENABLED guard around dbg::out
 *
 * Revision 1.4  2002/09/14 00:11:57  nali
 * use dbgsrc
 *
 * Revision 1.3  2002/09/12 08:04:21  nali
 * Updated to compute quantiles, also use boost::tuple to return values
 *
 *
 */
