/**
 * @file   slice_iter.hpp
 * @author Michael Na Li
 * @date   Tue Apr 23 00:10:46 2002
 *
 * @brief  Slice iterators
 *
 *         (Stroustrup, C++ Programming Langugage)
 *
 * $Id: slice_iter.hpp,v 1.1 2002/05/13 17:36:41 nali Exp $
 */

#ifndef SLICE_UTIL_HPP
#define SLICE_UTIL_HPP

namespace MLL
{

#include <valarray>

template<typename T>
class slice_iter
{
public :
    slice_iter (std::valarray<T> *vv, slice ss)
        : v_(vv), s_(ss), c_(0)
    {}

    slice_iter end () const
    {
        slice_iter t = *this;
        t.c_ = s_.size ();            // index of last-plus-one element
        return t;
    }

    slice_iter & operator++ ()
    {
        c_++;
        return *this;
    }

    slice_iter operator++ (int)
    {
        slice_iter t = *this;
        c_++;
        return t;
    }

    T & operator[] (std::size_t i)    // C style subscript
    {
        return ref (i);
    }

    T & operator() (std::size_t i)    // Fortran style subscript
    {
        return ref (i);
    }

    T & operator* ()                 // current element
    {
        return ref (c_);
    }

    friend bool operator==<> (const slice_iter &, const slice_iter &);
    friend bool operator!=<> (const slice_iter &, const slice_iter &);
    friend bool operator< <> (const slice_iter &, const slice_iter &);

private :
    std::valarray<T> *v_;
    std::slice s_;
    std::size_t c_;             // index of current element

    T & ref (std::size_t i) const
    {
        return (*v)[s_.start() + i * s_.stride ()];
    }
};

inline
template<typename T>
bool operator== (const slice_iter<T> & p, const slice_iter<T> & q)
{
    return p.c_ == q.c_ && p.s_.stride () == q.s_.stride () &&
        p.s_.start () == q.s_.start ();
}

inline
template<typename T>
bool operator!= (const slice_iter<T> & p, const slice_iter<T> & q)
{
    return !(p == q);
}

inline
template<typename T>
bool operator< (const slice_iter<T> & p, const slice_iter<T> & q)
{
    return p.c_ < q.c_ && p.s_.stride () == q.s_.stride () &&
        p.s_.start () == q.s_.start ();
}

template<typename T>
class const_slice_iter
{
public :
    const_slice_iter (std::valarray<T> *vv, slice ss)
        : v_(vv), s_(ss), c_(0)
    {}

    const_slice_iter end () const
    {
        const_slice_iter t = *this;
        t.c_ = s_.size ();            // index of last-plus-one element
        return t;
    }

    const_slice_iter & operator++ ()
    {
        c_++;
        return *this;
    }

    const_slice_iter operator++ (int)
    {
        const_slice_iter t = *this;
        c_++;
        return t;
    }

    const T & operator[] (std::size_t i)    // C style subscript
    {
        return ref (i);
    }

    const T & operator() (std::size_t i)    // Fortran style subscript
    {
        return ref (i);
    }

    const T & operator* ()            // current element
    {
        return ref (c_);
    }

    friend bool operator==<> (const const_slice_iter &,
                              const const_slice_iter &);
    friend bool operator!=<> (const const_slice_iter &,
                              const const_slice_iter &);
    friend bool operator< <> (const const_slice_iter &,
                              const const_slice_iter &);

private :
    std::valarray<T> *v_;
    std::slice s_;
    std::size_t c_;             // index of current element

    const T & ref (std::size_t i) const
    {
        return (*v)[s_.start() + i * s_.stride ()];
    }
};

inline
template<typename T>
bool operator== (const const_slice_iter<T> & p, const const_slice_iter<T> & q)
{
    return p.c_ == q.c_ && p.s_.stride () == q.s_.stride () &&
        p.s_.start () == q.s_.start ();
}

inline
template<typename T>
bool operator!= (const const_slice_iter<T> & p, const const_slice_iter<T> & q)
{
    return !(p == q);
}

inline
template<typename T>
bool operator< (const const_slice_iter<T> & p, const const_slice_iter<T> & q)
{
    return p.c_ < q.c_ && p.s_.stride () == q.s_.stride () &&
        p.s_.start () == q.s_.start ();
}

}   // namespace MLL

#endif // SLICE_UTIL_HPP
