// $Id: objfunc.hpp,v 1.5 2002/08/27 00:43:42 nali Exp $

#ifndef OBJFUNC_HPP
#define OBJFUNC_HPP

#include <iostream>

namespace MLL
{

template <typename StateType>
class ObjectFunction
{
public:
    ObjectFunction (int ntrace = 0)
        : neval_ (0), ntrace_ (ntrace)
    {}

    virtual ~ObjectFunction ()
    {}

    virtual double operator () (const StateType & xval) = 0;

    int neval ()
    {
        return neval_;
    }

protected:
    void incr_neval ()
    {
        ++neval_;
    }

    void ptrace_ (double fx, const StateType & x) const
    {
        if (ntrace_ > 0 && neval_ % ntrace_ == 0) {
            std::cout.setf (std::ios::scientific);
            std::cout << std::setw (4) << neval_ << ' '
                      << std::setw (12) << std::setprecision (5) << fx
                      << " ";
            for (int i = 0; i < x.size (); ++i) {
                std::cout << std::setw (12) << std::setprecision (5) << x[i]
                          << " ";
            }
            std::cout << std::endl;
            std::cout.unsetf (std::ios::scientific);
        }
    }

private:
    int neval_;
    int ntrace_;
};

}  // namespace MLL

#endif // OBJFUNC_HPP
