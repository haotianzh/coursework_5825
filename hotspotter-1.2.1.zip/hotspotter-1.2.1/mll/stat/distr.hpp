/**
 * @file   distr.hpp
 * @author Michael Na Li
 * @date   Sun Jul  7 20:36:54 2002
 *
 * @brief  Special functions related to probability distributions
 *
 * \$Id: distr.hpp,v 1.12 2002/07/08 04:18:41 nali Exp $
 */

#ifndef DISTR_HPP
#define DISTR_HPP

namespace MLL
{

// {{{ Normal Distribution

double
pnorm( double x, bool upper = true);

double
pnorm( double x, double mu, double sigma, bool upper = true);


/* density of Normal (mu, sigma^2) distribution */
double
dnorm( double x, double mu = 0.0, double sigma = 1.0);

double
logdnorm( double x, double mu = 0.0, double sigma = 1.0);

// }}}

// {{{ Geometric Distribution

double
dgeom( int x, double prob);

double
logdgeom( int x, double prob);

// }}}

// {{{  Gamma distribution
/* Gamma (alpha, beta) distribution has density of the form
 *
 *                      x^{alpha-1} e^{-x/beta}
 * f(x|alpha, beta) = ---------------------------,  0 < x < Infinity
 *                    \Gamma (alpha) beta^alpha
 *
 * alpha > 0 and beta > 0.
 *
 * alpha is also called the shape parameter and beta the scale parameter.
 */
double
dgamma( double x, double shape, double scale);

double
logdgamma( double x, double shape, double scale);

double
mean_gamma( double shape, double scale);

double
var_gamma( double shape, double scale);

double
mgf_gamma( double t, double shape, double scale);

// }}}

} // namespace MLL

#endif // DISTR_HPP


