/*
 * Template class for Metropolis-Hastings MCMC
 *
 * MCMCModel is a user-defined class in which
 *
 * MCMCModel::operator () (ForwardIter, InputIter, OutputIter);
 *
 * proposes a new state in OutputIter based on last state from ForwardIter
 * and returns the M-H ratio (could be greater than 1.0).
 *
 * RandomNumberGenerator::operator () () generates a [0, 1) r.v.
 *
 * $Id: metro.hpp,v 1.1 2003/02/13 20:00:15 nali Exp $
 *
 * */

#ifndef METRO_MCMC_H
#define METRO_MCMC_H

template <class ProcessModel,
          class Uniform01RandomNumberGenerator =
                typename ProcessModel::rng_type>
class MetropolisHastingsSampler
{
public:

    typedef ProcessModel model_type;
    typedef typename model_type::state_type state_type;
    typedef Uniform01RandomNumberGenerator rng_type;

    MetropolisHastingsSampler (model_type & model,
                               const state_type & start,
                               rng_type & rand,
                               int thinning = 1,
                               int burnin   = 0)
        : model_ (model), rand_ (rand), curr_ (start), next_ (start),
          clogdens_ (model_.logtarget_d (curr_)), nlogdens_ (0.0),
          thinning_ (thinning), count_ (0), sum_alpha_ (0.0)
    {
#ifdef DEBUG_METRO
        std::cout << "Log density at starting value: " << clogdens_
                  << std::endl;
#endif
        state_type temp;
        std::cout << "Burn-in " << burnin << " iterations." << std::endl;
        for (int i = 0; i < burnin; ++i) {
            next (temp);
        }
        std::cout << "Burn-in finished." << std::endl;
        count_ = 0;
        sum_alpha_ = 0.0;
    }

    virtual ~MetropolisHastingsSampler () { }

    double next (state_type & newS)
    {
        for (int i = 0; i < thinning_; ++i) {
            // Generate a proposal
            model_.propose (curr_, next_);
            double alpha = pr_accept_ ();
#ifdef DEBUG_METRO
            std::cout << "alpha = " << alpha << std::endl;
#endif
            // assign alpha = 1.0 if alpha >= 1.0 is true.
            if ((alpha >= 1.0 && (alpha = 1.0)) || rand_ () < alpha) {
                // accept, save as current value
                curr_ = next_;
                clogdens_ = nlogdens_;
            }
            // reject, stay where it was
            sum_alpha_ += alpha;
            ++count_;
        }
        newS = curr_;
        return clogdens_;
    }

    double accept_rate ()
    {
        return sum_alpha_ / count_;
    }

private:
    model_type & model_;
    rng_type & rand_;

    state_type curr_;
    state_type next_;
    double clogdens_;
    double nlogdens_;
    int    thinning_;
    int    count_;
    double sum_alpha_;

    double pr_accept_ ()
    {
        nlogdens_ = model_.logtarget_d (next_);
        if (nlogdens_ > 0.0) return 0.0;
#ifdef DEBUG_METRO
        std::cout << "Log density at proposal = " << nlogdens_ << std::endl;
#endif
        double tonext = model_.proposal_d (curr_, next_);
        double revers = model_.proposal_d (next_, curr_);
        return exp (nlogdens_ - clogdens_) * (revers / tonext);
    }
};

#endif // METRO_MCMC_H
