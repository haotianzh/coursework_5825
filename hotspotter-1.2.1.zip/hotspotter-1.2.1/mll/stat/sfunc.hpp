/**
 * @file   sfunc.hpp
 * @author Michael Na Li
 * @date   Sat Feb 23 21:37:14 2002
 *
 * @brief  Some useful and simple functions, based on template and STL.
 *
 * $Id: sfunc.hpp,v 1.16 2003/02/13 20:03:49 nali Exp $
 */

#ifndef SIMPLE_FUNCTIONS_HPP
#define SIMPLE_FUNCTIONS_HPP

#include "dbg/dbg.hpp"
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <iostream>

#include <gsl/gsl_math.h>

namespace MLL
{
/**
 * The maximum in absolute values of two numbers.
 *
 * @param a The first number.
 * @param b The second number.
 *
 * @return \f$\max (|a|, |b|)\f$
 */
template <typename T>
inline
T absmax (T a, T b)
{
    return std::abs (a) > std::abs (b) ? a : b;
}

/**
 * The minimum in absolute values of two numbers.
 *
 * @param a The first number.
 * @param b The second number.
 *
 * @return \f$\min (|a|, |b|)\f$
 */
template <typename T>
inline
T absmin (T a, T b)
{
    return std::abs (a) < std::abs (b) ? a : b;
}

/**
 * The sign of a number.
 *
 * @param a A number.
 *
 * @return An integer, \f[
 *             \sign (x) = \begin{array}{cc}
 *                1, &  x > 0, \\
 *                0, &  x = 0, \\
 *                -1, &  x < 0.
 *             \end{array}
 *         \f]
 */
template <typename T>
inline
int
sign (T a)
{
    return a > 0 ? 1 : (a < 0 ? -1 : 0);
}

/**
 *
 *
 * @param x
 *
 * @return
 */
template <unsigned int N>
inline
double
pow (double x)
{
    return pow <N % 2u> (x) * pow <N / 2u> (x * x);
}

template <>
inline
double
pow <1u> (double x)
{
    return x;
}

template <>
inline
double
pow <0u> (double)
{
    return 1.0;
}

/**
 * Generator a sequence with given start point, stop point and step.
 *
 *
 * @param begin
 * @param from
 * @param to
 * @param by
 *
 */
template <typename OutputIterator, typename T>
inline
void
arange (OutputIterator begin, T from, T to, T by)
{
    for (T c = from; c <= to; c += by) {
        *begin++ = c;
    }
}

template <typename OutputIterator, typename T>
inline
void
arange_n (OutputIterator begin, OutputIterator end, T from, T by)
{
    // Note: SGI STL and G++ STL provides std::iota in <numeric>
    for (; begin != end; from += by) {
        *begin++ = from;
    }
}

template <typename OutputIterator, typename T>
inline
void
arange_n (OutputIterator begin, std::size_t n, T from, T by)
{
    for (std::size_t i = 0; i < n; ++i, from += by) {
        *begin++ = from;
    }
}


/**
 * Sample \c n items randomly with replacement from a sequence.
 *
 * @param begin    Random access iterator, beginning of the source sequence
 * @param end      Random access iterator, end of the source sequence
 * @param obegin   Output iterator, beginning of the output sequence
 * @param n        Integer, the number of items to sample
 * @param rand     A random number generator, \c rand (\f$N\f$) should return a
 *                 random number  between 0 and \f$N - 1\f$.
 */
template <typename RandomAccessIterator,
          typename OutputIterator,
          typename size_type,
          typename RandomNumberGenerator>
void
sample_replace (RandomAccessIterator begin,
                RandomAccessIterator end,
                OutputIterator obegin,
                size_type n,
                RandomAccessIterator rand)
{
    std::size_t nsize = std::distance (begin, end);
    // with replacement
    for (size_type i = 0; i < n; ++i) {
        *obegin++ = *(begin + rand (nsize));
    }
}

/**
 * Sample \c n items randomly with replacement from a sequence.
 *
 * The this algorith doesn't retain the order the itmes in the source sequence.
 * The length of the source sequence should be greater than or equal to n.
 *
 * @param begin    Random access iterator, beginning of the source sequence
 * @param end      Random access iterator, end of the source sequence
 * @param obegin   Output iterator, beginning of the output sequence
 * @param n        Integer, the number of items to sample
 * @param rand     A random number generator, rand (N) should return a random
 *                 integer between 0 and N - 1.
 *
 * @see sample_replace
 * @see stable_sample_replace
 */
template <typename RandomAccessIterator,
          typename OutputIterator,
          typename size_type,
          typename RandomNumberGenerator>
void
sample_without_replace (RandomAccessIterator begin,
                        RandomAccessIterator end,
                        OutputIterator obegin,
                        size_type n,
                        RandomAccessIterator rand)
{
    std::size_t nsize = std::distance (begin, end);
    // without replacement
    if (n > nsize) {
        // FIXME exception
        std::cout << "Cannot sample more than " << nsize << " items"
                  << std::endl;
    }
    for (size_type i = 0; i < n && nsize > 0; ++i) {
        std::size_t j = rand (nsize--);
        *obegin++ = *(begin + j);
        *(begin + j) = *(--end);
    }
}


template <typename RandomAccessIterator,
          typename OutputIterator,
          typename size_type,
          typename RandomNumberGenerator>
void
stable_sample_without_replace (RandomAccessIterator begin,
                               RandomAccessIterator end,
                               OutputIterator obegin,
                               size_type n,
                               RandomAccessIterator rand)
{
    std::size_t nsize = std::distance (begin, end);
    std::vector<int> index (nsize);
    std::vector<int> oindex (n);
    arange (index.begin (), n, 0, 1);
    sample_without_replace (index.begin (), index.end (), oindex.begin (),
                            n, rand);
    std::sort (oindex.begin (), oindex.end ());
    for (std::vector<int>::const_iterator i = oindex.begin ();
         i != oindex.end (); ++i) {
        *obegin++ = *(begin + *i);
    }
}

template <typename InputIterator, typename Tp>
inline
Tp
polevl (InputIterator first, InputIterator last, Tp x)
{
    Tp ans (*first);
    for (++first; first != last; ++first) {
        ans = ans * x + *first;
    }
    return ans;
}

template <typename InputIterator, typename Tp>
inline
Tp
p1evl (InputIterator first, InputIterator last, Tp x)
{
    Tp ans (x + *first);
    for (++first; first != last; ++first) {
        ans = ans * x + *first;
    }
    return ans;
}

/**
 * Add two numbers on a log scale to avoid under- or (over-) flow
 *
 * @param x1
 * @param x2
 *
 * @return log (exp (x1) + exp (x2))
 */
inline
double add_log (double x1, double x2)
{
    double yy = 0.5 * (x1 + x2);
    return log (cosh (x1 - yy)) + yy + M_LN2;
}

/**
 * Test the convergence of a sequence X_0, X_1.
 */
inline
bool test_delta( double x0, double x1, double epsrel, double epsabs )
{
    return fabs (x0 - x1) < epsabs + epsrel * fabs (x1);
}

} // namespace MLL

#endif // SIMPLE_FUNCTIONS_HPP
