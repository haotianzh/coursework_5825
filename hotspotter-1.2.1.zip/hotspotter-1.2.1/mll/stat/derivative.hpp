/**
 * @file   diff.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2002/10/14 17:42:03
 *
 * @brief
 *
 * $Id: derivative.hpp,v 1.2 2002/11/27 09:33:08 nali Exp $
 */
#ifndef _DERIVATIVE_HPP
#define _DERIVATIVE_HPP 1

#include "dbg/dbg.hpp"

#include <gsl/gsl_math.h>
#include <cmath>
#include <cstdlib>

namespace MLL
{

/**
 * The functor class Derivative defines the derivative of the
 * function.
 */
template <typename functor_type>
class Derivative
{
public :
    static dbg::dbg_source d_src;
    enum diff_method { central, forward, backward };

    explicit
    Derivative( functor_type & func, diff_method method = central)
        : F_ (func), m_ (method)
    {
        dbg::trace dtrace (d_src, DBG_HERE);
    }

    ~Derivative( )
    {
        dbg::trace dtrace (d_src, DBG_HERE);
    }

    double operator ()( double x );
    double get_err () const;
private :

    functor_type & F_;
    double err_;
    diff_method m_;

    double diff_backward( double x );
    double diff_forward( double x );
    double diff_central( double x );
};

// {{{ Implementation

template <typename functor_type>
dbg::dbg_source Derivative<functor_type>::d_src = "Derivative";

template <typename functor_type>
inline double
Derivative<functor_type>::operator ()( double x )
{
    switch (m_) {
    case central :
        return diff_central (x);
    case backward :
        return diff_backward (x);
    case forward :
        return diff_forward (x);
    default :
        // Shouldn't get here
        dbg::sentinel (DBG_HERE);
        return 0.0;
    }
}

template <typename functor_type>
inline double
Derivative<functor_type>::get_err () const
{
    return err_;
}

template <typename functor_type>
double
Derivative<functor_type>::diff_backward( double x )
{
    dbg::trace dtrace (d_src, DBG_HERE);
    /* Construct a divided difference table with a fairly large step
       size to get a very rough estimate of f''.  Use this to estimate
       the step size which will minimize the error in calculating f'. */
    double h = GSL_SQRT_DBL_EPSILON;
    double a[3], d[3];

    /* Algorithm based on description on pg. 204 of Conte and de Boor
       (CdB) - coefficients of Newton form of polynomial of degree 2. */

    for (int i = 0; i < 3; ++i) {
      a[i] = x + (i - 2.0) * h;
      d[i] = F_ (a[i]);
    }

    for (int k = 1; k < 4; ++k) {
        for (int i = 0; i < 3 - k; ++i) {
            d[i] = (d[i + 1] - d[i]) / (a[i + k] - a[i]);
        }
    }

    /* Adapt procedure described on pg. 282 of CdB to find best value of
       step size. */

    double a2 = std::abs (d[0] + d[1] + d[2]);

    if (a2 < 100.0 * GSL_SQRT_DBL_EPSILON) {
        a2 = 100.0 * GSL_SQRT_DBL_EPSILON;
    }

    h = sqrt (GSL_SQRT_DBL_EPSILON / (2.0 * a2));

    if (h > 100.0 * GSL_SQRT_DBL_EPSILON) {
        h = 100.0 * GSL_SQRT_DBL_EPSILON;
    }

    double res = (F_ (x) - F_ (x - h)) / h;
    err_ = std::abs (10.0 * a2 * h);

    return res;
}

template <typename functor_type>
double
Derivative<functor_type>::diff_forward( double x )
{
    dbg::trace dtrace (d_src, DBG_HERE);
    /* Construct a divided difference table with a fairly large step
       size to get a very rough estimate of f''.  Use this to estimate
       the step size which will minimize the error in calculating f'. */
    double h = GSL_SQRT_DBL_EPSILON;
    double a[3];
    double d[3];

    /* Algorithm based on description on pg. 204 of Conte and de Boor
       (CdB) - coefficients of Newton form of polynomial of degree 2. */

    for (int i = 0; i < 3; ++i) {
        a[i] = x + i * h;
        d[i] = F_ (a[i]);
    }

    for (int k = 1; k < 4; ++k) {
        for (int i = 0; i < 3 - k; i++) {
            d[i] = (d[i + 1] - d[i]) / (a[i + k] - a[i]);
        }
    }

    /* Adapt procedure described on pg. 282 of CdB to find best value of
       step size. */

    double a2 = std::abs (d[0] + d[1] + d[2]);
    if (a2 < 100.0 * GSL_SQRT_DBL_EPSILON) {
        a2 = 100.0 * GSL_SQRT_DBL_EPSILON;
    }

    h = sqrt (GSL_SQRT_DBL_EPSILON / (2.0 * a2));

    if (h > 100.0 * GSL_SQRT_DBL_EPSILON) {
        h = 100.0 * GSL_SQRT_DBL_EPSILON;
    }

    double res = (F_ (x + h) - F_ (x)) / h;
    err_ = std::abs (10.0 * a2 * h);

    return res;
}

template <typename functor_type>
double
Derivative<functor_type>::diff_central( double x )
{
    dbg::trace dtrace (d_src, DBG_HERE);

    /* Construct a divided difference table with a fairly large step
       size to get a very rough estimate of f'''.  Use this to estimate
       the step size which will minimize the error in calculating f'. */
    double h = GSL_SQRT_DBL_EPSILON;
    double a[4];
    double d[4];

    /* Algorithm based on description on pg. 204 of Conte and de Boor
       (CdB) - coefficients of Newton form of polynomial of degree 3. */

    for (int i = 0; i < 4; ++i) {
        a[i] = x + (i - 2.0) * h;
        d[i] = F_ (a[i]);
    }

    for (int k = 1; k < 5; k++) {
        for (int i = 0; i < 4 - k; i++) {
            d[i] = (d[i + 1] - d[i]) / (a[i + k] - a[i]);
        }
    }

    /* Adapt procedure described on pg. 282 of CdB to find best
       value of step size. */

    double a3 = std::abs (d[0] + d[1] + d[2] + d[3]);

    if (a3 < 100.0 * GSL_SQRT_DBL_EPSILON) {
        a3 = 100.0 * GSL_SQRT_DBL_EPSILON;
    }

    h = pow (GSL_SQRT_DBL_EPSILON / (2.0 * a3), 1.0 / 3.0);

    if (h > 100.0 * GSL_SQRT_DBL_EPSILON) {
        h = 100.0 * GSL_SQRT_DBL_EPSILON;
    }

    double res = (F_ (x + h) - F_ (x - h)) / (2.0 * h);
    err_ = std::abs (100.0 * a3 * h * h);

    return res;
}

// }}}

}  // namespace MLL

#endif // _DERIVATIVE_HPP

