/**
 * @file   credint.hpp
 * @author Michael Na Li
 * @date   Wed Jun 26 20:59:05 2002
 *
 * @brief Compute credible interval by discreting the posterior
 *        distribution.
 *
 * $Id: credint.hpp,v 1.10 2003/02/13 20:00:01 nali Exp $
 */

#ifndef CREDINT_HPP
#define CREDINT_HPP

#include "dbg/dbg.hpp"
#include "boost/tuple/tuple.hpp"

#include <valarray>
#include <map>
#include <stdexcept>
#include <cstdlib>

namespace MLL
{

/**
 * @class CredibleInterval
 *
 * @brief A class form computing high density credible interval
 *
 */
class CredibleInterval
{
public :

    static dbg::dbg_source dbgsrc;

    /**
     * Initialize by providing a function object, an interval and a number of
     * grid points to evaluate.
     *
     * @param f             A univariate functor
     * @param a             double, one end of the interval
     * @param b             double, the other end of the interval
     * @param n             int, the number of grid points
     * @param logscale      wether the return value of f is on log scale
     */
    template <typename F_>
    CredibleInterval (F_ f,
                      double a,
                      double b,
                      int n,
                      bool logscale,
                      bool normalize)
        : fk_ (n + 1), area_ (n),
          a_ (std::min (a, b)), 
#ifdef __INTEL_COMPILER
          w_ (fabs (b - a) / n),
#else
          w_ (std::abs (b - a) / n),
#endif
          modeindex_ (n)
    {
        dbg::trace trace (dbgsrc, DBG_HERE);
        double tempa = a_;
        fk_[0] = f (tempa);
        for (std::size_t i = 1; i < fk_.size (); ++i) {
            tempa += w_;
            fk_[i] = f(tempa);
        }
        compute_areas_and_find_mode_ (logscale, normalize);
    }

    /**
     * Initialize by providing an array of function values evaluted at a fixed
     * grid from a and b.
     *
     * @param a    double, one end of the interval
     * @param b    double, The other end of the interval
     * @param fk   std::valarray<double>, function values
     */
    CredibleInterval (double a,
                      double b,
                      const std::valarray<double> & fk,
                      bool logscale,
                      bool normalize)
        : fk_ (fk), area_ (fk_.size () - 1), a_ (std::min (a, b)),
#ifdef __INTEL_COMPILER
          w_ (fabs (b - a) / (fk_.size () - 1)),
#else
          w_ (std::abs (b - a) / (fk_.size () - 1)),
#endif
          modeindex_ (area_.size ())
    {
        dbg::trace trace (dbgsrc, DBG_HERE);
        compute_areas_and_find_mode_ (logscale, normalize);
    }

    /**
     * Computing CI for given percentage, based on stored grid function values.
     *
     * @param perc  Percentage
     *
     * @return The actual aread and the credible interval
     */
    boost::tuple<double, double, double> calc_interval( double perc );

    double quantile (double prob, bool upper_tail = false);

private :

    void compute_areas_and_find_mode_ (bool logscale, bool normalize);

    std::valarray<double> fk_;
    std::valarray<double> area_;
    double a_;
    double w_;

    std::size_t modeindex_;
};


} // namespace MLL

#endif // CREDINT_HPP
