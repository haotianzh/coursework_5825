/**
 * @file   matrix.hpp
 * @author Michael Na Li
 * @date   Mon Apr 22 23:56:26 2002
 *
 * @brief  std::valarray based Matrix class
 *
 *         (Stroustrup, C++ Programming Language)
 * $Id: matrix.hpp,v 1.1 2002/05/13 17:36:41 nali Exp $
 */

#ifndef MLL_MATRIX_HPP
#define MLL_MATRIX_HPP

#include <valarray>
#include "slice_iter.hpp"

namespace MLL
{

template<typename T>
class Matrix
{
public :
    typedef T value_type;

    // note no default constructor
    Matrix (std::size_t nr, std::size_t nc);
    Matrix (const Matrix<T> &);
    Matrix & operator= (const Matrix<T> &);
    ~Matrix ();

    std::size_t size () const;
    std::size_t nrow () const;
    std::size_t ncol () const;

    slice_iter<T> row (std::size_t i);
    const_slice_iter<T> row (std::size_t i) const;

    slice_iter<T> col (std::size_t i);
    const_slice_iter<T> col (std::size_t i) const;

    // Fortran style subscripts
    T & operator() (std::size_t x, std::size_t y);
    const T & operator() (std::size_t x, std::size_t y) const;

    slice_iter<T> operator() (std::size_t i);
    const_slice_iter<T> operator() (std::size_t i) const;

    slice_iter<T> operator[] (std::size_t i);
    const_slice_iter<T> operator[] (std::size_t i) const;

    std::valarray<T> & array ();

private :
    std::valarray<T> *v_;
    std::size_t nrow_;
    std::size_t ncol_;
};

template<typename T>
inline
Matrix<T>::Matrix (std::size_t nr, std::size_t nc)
    : nrow_ (nr), ncol_ (nc)
{
    v_ = new std::valarray<T> (nrow_, ncol_);
}

template<typename T>
inline
Matrix<T>::Matrix (const Matrix<T> & m)
    : nrow_ (m.nrow ()), ncol_ (m.ncol)
{
    v_ = new std::valarray<T> (m.array ());
}

template<typename T>
inline
Matrix<T>::operator= (const Matrix<T> & m)
{
    *v_ = m.array ();
}

template<typename T>
inline
Matrix<T>::~Matrix ()
{
    delete v_;
}

template<typename T>
inline
std::size_t
Matrix<T>::size ()
{
    return nrow_ * ncol_;
}

template<typename T>
inline
std::size_t
Matrix<T>::nrow ()
{
    return nrow_;
}

template<typename T>
inline
std::size_t
Matrix<T>::ncol ()
{
    return ncol_;
}

template<typename T>
inline
slice_iter<T>
Matrix<T>::row (std::size_t i)
{
    return slice_iter<T> (v_, slice (i, nrow_, ncol_));
}


template<typename T>
inline
const_slice_iter<T>
Matrix<T>::row (std::size_t i) const
{
    return const_slice_iter<T> (v_, slice (i, nrow_, ncol_));
}

template<typename T>
inline
slice_iter<T>
Matrix<T>::col (std::size_t i)
{
    return slice_iter<T> (v_, slice (i * ncol_, ncol_, 1));
}

template<typename T>
inline
const_slice_iter<T>
Matrix<T>::col (std::size_t i) const
{
    return const_slice_iter<T> (v_, slice (i * ncol_, ncol_, 1));
}


template<typename T>
inline
std::valarray<T> &
Matrix<T>::array ()
{
    return *v_;
}

} // namespace MLL

#endif // MLL_MATRIX_HPP
