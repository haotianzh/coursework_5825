/**
 * @file vector.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   Fri, 26 Apr 2002 00:46:37 -0700
 *
 * @brief  A valarray base vector class
 * 
 *
 * $Id: vector.hpp,v 1.1 2002/05/13 17:36:41 nali Exp $
 **/

#ifndef MLL_VECTOR_HPP
#define MLL_VECTOR_HPP

#include <valarray>

namespace MLL
{

template<typename T>
class Vector
{
public :
    typedef T value_type;

    Vector ();
    explicit Vector (std::size_t n);
    Vector (std::size_t n, const T & val);
    Vector (std::size_t n, const T * array);
    Vector (const Vector<T> &);
    Vector & operator= (const Vector<T> &);
    ~Vector ();

    std::size_t size () const;
    void resize (std::size_t n);
    
private :
    std::valarray<T> *v_;       
};

inline
template<typename T>
Vector::Vector (std::size_t n)
{
    v_ = new std::valarray<T> (n);
}

inline
template<typename T>
Vector::Vector (std::size_t n, const T & val)
{
    v_ = new std::valarray<T> (val, n);
}

inline
template<typename T>
Vector::Vector (std::size_t n, const T * array)
{
    v_ = new std::valarray<T> (array, n);
}

inline
template<typename T>
Vector::Vector (const Vector<T> & vec)
{
    v_ = new std::valarray<T> (vec.v_);
}

inline
template<typename T>
Vector & operator= (const Vector<T> & vec)
{
    if (v_) {
        delete v_;
    }
    v_ = new std::valarray<T> (vec.v_);
}

inline
template<typename T>
Vector::~Vector ()
{
    if (v_) {
        delete v_;
    }
}

inline
std::size_t
Vector::size () const
{
    return v_->size ();
}

// Fortran style subscripts
T & operator () (std::size_t i)
{
    return (*v_)[i];
}

}

#endif // MLL_VECTOR_HPP
