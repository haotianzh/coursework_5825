/**
 * @file   distr.cpp
 * @author Michael Na Li
 * @date   Sun Jul  7 20:37:43 2002
 *
 * @brief  Implementation of distr.hpp
 *
 * \$Id: distr.cpp,v 1.1 2002/07/08 04:23:33 nali Exp $
 */

#include "stat/distr.hpp"

#include "stat/sfunc.hpp"
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf.h>

#include <stdexcept>
#include <cmath>

namespace MLL
{

double
pnorm( double x, bool upper)
{
    double result (0.0);
    x /= M_SQRT2;
    if (upper) {
        // upper tail
        if (x > 0.0) {
            result = gsl_sf_erfc (x);
        } else {
            result = 0.5 + gsl_sf_erf (-x);
        }
    } else {
        // lower tail
        if (x > 0.0) {
            result = 1.0 + gsl_sf_erf (x);
        } else {
            result = gsl_sf_erfc (-x);
        }
    }
    return 0.5 * result;
}

double
pnorm( double x, double mu, double sigma, bool upper)
{
    double result (0.5);
    if (sigma > 0) {
        result = pnorm ((x - mu) / sigma, upper);
    } else if (x < mu) {
        // When sigma <= 0.0, treat it as if sigma == 0, that is a point mass
        // at mu
        result = upper ? 0.0 : 1.0;
    } else if (x > mu) {
        result = upper ? 1.0 : 0.0;
    }
    return result;
}

double
dnorm( double x, double mu, double sigma)
{
    double result (1.0);
    if (sigma > 0.0) {
        x = (x - mu) / sigma;
        result = exp (- pow<2u> (x) / 2.0) / (M_SQRT2 * M_SQRTPI);
    } else if (! (x > mu || x < mu)) {
        // Point mass at mu, if x != mu
        result = 0.0;
    }
    return result;
}

double
logdnorm( double x, double mu, double sigma)
{
    x = (x - mu) / sigma;
    return - MLL::pow<2u> (x) * 0.5 - log (M_SQRT2) - log (M_SQRTPI) -
        log (sigma);
}

double
dgeom( int x, double prob)
{
    return prob * gsl_pow_int (1.0 - prob, x - 1);
}

double
logdgeom( int x, double prob)
{
    return log (prob) + (x - 1) * log (1.0 - prob);
}

double
dgamma( double x, double shape, double scale)
{
    double density = 0.0;
    if (x < 0.0) {
        density = 0.0;
    } else if (x > 0.0) {
        x /= scale;
        density = gsl_sf_exp ((shape - 1.0) * gsl_sf_log (x) -
                gsl_sf_lngamma (shape) - x) / scale;
    } else {
        if (shape < 1.0) {
            throw std::invalid_argument ("x == 0 and shape < 1.0");
        } else if (shape > 1.0) {
            density = 0.0;
        } else {
            density = 1.0 / scale;
        }
    }
    return density;
}

double
logdgamma( double x, double shape, double scale)
{
    double logdensity = 0.0;
    if (x < 0.0) {
        logdensity = - GSL_NEGINF;
    } else if (x > 0.0) {
        x /= scale;
        logdensity = (shape - 1.0) * gsl_sf_log (x) -
                gsl_sf_lngamma (shape) - x - gsl_sf_log (scale);
    } else {
        if (shape < 1.0) {
            throw std::invalid_argument ("x == 0 and shape < 1.0");
        } else if (shape > 1.0) {
            logdensity = GSL_NEGINF;
        } else {
            logdensity = - gsl_sf_log (scale);
        }
    }
    return logdensity;
}

double
mean_gamma( double shape, double scale)
{
    return shape * scale;
}

double
var_gamma ( double shape, double scale)
{
    return shape * pow<2u> (scale);
}

double
mgf_gamma( double t, double shape, double scale)
{
    if (t < 1.0 / scale) {
        throw std::invalid_argument ("t >= 1.0 / scale");
    }
    return gsl_sf_exp (- shape * gsl_sf_log (1.0 - scale * t));
}

}

// {{{ Log
/*
 * $Log: distr.cpp,v $
 * Revision 1.1  2002/07/08 04:23:33  nali
 * New cpp files.
 *
 */
// }}}
