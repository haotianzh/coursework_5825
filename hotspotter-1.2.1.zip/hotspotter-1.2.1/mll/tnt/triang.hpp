/*
 *
 * Template Numerical Toolkit (TNT): Linear Algebra Module
 *
 * Mathematical and Computational Sciences Division
 * National Institute of Technology,
 * Gaithersburg, MD USA
 *
 *
 * This software was developed at the National Institute of Standards and
 * Technology (NIST) by employees of the Federal Government in the course
 * of their official duties. Pursuant to title 17 Section 105 of the
 * United States Code, this software is not subject to copyright protection
 * and is in the public domain.  The Template Numerical Toolkit (TNT) is
 * an experimental system.  NIST assumes no responsibility whatsoever for
 * its use by other parties, and makes no guarantees, expressed or implied,
 * about its quality, reliability, or any other characteristic.
 *
 * BETA VERSION INCOMPLETE AND SUBJECT TO CHANGE
 * see http://math.nist.gov/tnt for latest updates.
 *
 */

// Triangular Matrices (Views and Adpators)

#ifndef TRIANG_HPP
#define TRIANG_HPP

// default to use lower-triangular portions of arrays
// for symmetric matrices.

namespace TNT
{

template <typename MaTRiX>
class LowerTriangularView
{
protected:
    const MaTRiX  & A_;
    const typename MaTRiX::element_type zero_;
public:
    typedef typename MaTRiX::const_reference const_reference;
    typedef typename MaTRiX::element_type element_type;
    typedef typename MaTRiX::element_type value_type;
    typedef element_type T;

    Subscript dim (Subscript d) const {  return A_.dim(d); }
    Subscript lbound () const { return A_.lbound(); }
    Subscript nrows () const { return A_.nrows(); }
    Subscript ncols () const { return A_.ncols(); }

    // constructors
    LowerTriangularView (const MaTRiX & A) : A_(A),  zero_(0) {}

    const_reference get (Subscript i, Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert(lbound () <= i);
        assert(i <= A_.nrows() + lbound() - 1);
        assert(lbound () <= j);
        assert(j <= A_.ncols() + lbound() - 1);
#endif
        if (i < j) {
            return zero_;
        } else {
            return A_(i,j);
        }
    }

    const_reference operator() (Subscript i, Subscript j) const
    {
        return get (i, j);
    }

#ifdef TNT_USE_REGIONS
    typedef const_Region2D <LowerTriangularView<MaTRiX> > const_Region;

    const_Region operator() (const Index1D & I, const Index1D & J) const
    {
        return const_Region (*this, I, J);
    }

    const_Region operator() (Subscript i1, Subscript i2,
                             Subscript j1, Subscript j2) const
    {
        return const_Region (*this, i1, i2, j1, j2);
    }
#endif // TNT_USE_REGIONS
};

template <typename MaTRiX>
class UnitLowerTriangularView
{
protected:
    const MaTRiX  & A_;
    const typename MaTRiX::element_type zero;
    const typename MaTRiX::element_type one;

public:
    typedef typename MaTRiX::const_reference const_reference;
    typedef typename MaTRiX::element_type element_type;
    typedef typename MaTRiX::element_type value_type;
    typedef element_type T;

    Subscript lbound() const { return 1; }
    Subscript dim (Subscript d) const {  return A_.dim(d); }
    Subscript nrows() const { return A_.nrows(); }
    Subscript ncols() const { return A_.ncols(); }

    // constructors
    UnitLowerTriangularView (const MaTRiX & A) : A_(A), zero(0), one(1) {}

    const_reference get (Subscript i, Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert(lbound () <= i);
        assert(i <= A_.nrows() + lbound() - 1);
        assert(lbound () <= j);
        assert(j <= A_.ncols() + lbound() - 1);
#endif
        if (i > j) {
            return A_(i,j);
        } else if (i == j) {
            return one;
        } else {
            return zero;
        }
    }

    const_reference operator() (Subscript i, Subscript j) const
    {
        return get (i, j);
    }

#ifdef TNT_USE_REGIONS
    // These are the "index-aware" features
    typedef const_Region2D <UnitLowerTriangularView<MaTRiX> > const_Region;

    const_Region operator() (const Index1D & I, const Index1D & J) const
    {
        return const_Region (*this, I, J);
    }

    const_Region operator() (Subscript i1, Subscript i2,
                             Subscript j1, Subscript j2) const
    {
        return const_Region (*this, i1, i2, j1, j2);
    }
#endif  // TNT_USE_REGIONS
};

// ******************* Upper Triangular Section **************************

template <typename MaTRiX>
class UpperTriangularView
{
protected:
    const MaTRiX  & A_;
    const typename MaTRiX::element_type zero_;

public:
    typedef typename MaTRiX::const_reference const_reference;
    typedef typename MaTRiX::element_type element_type;
    typedef typename MaTRiX::element_type value_type;
    typedef element_type T;

    Subscript dim (Subscript d) const {  return A_.dim(d); }
    Subscript lbound() const { return A_.lbound(); }
    Subscript nrows() const { return A_.nrows(); }
    Subscript ncols() const { return A_.ncols(); }
    // constructors

    UpperTriangularView (const MaTRiX &A) : A_(A),  zero_(0) {}

    const_reference get (Subscript i, Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (lbound() <= i);
        assert (i <= A_.nrows() + lbound() - 1);
        assert (lbound() <= j);
        assert (j <= A_.ncols() + lbound() - 1);
#endif
        if (i > j) {
            return zero_;
        } else {
            return A_(i,j);
        }
    }

    const_reference operator() (Subscript i, Subscript j) const
    {
        return get (i, j);
    }

#ifdef TNT_USE_REGIONS
    typedef const_Region2D <UpperTriangularView<MaTRiX> > const_Region;

    const_Region operator() (const Index1D & I, const Index1D & J) const
    {
        return const_Region (*this, I, J);
    }

    const_Region operator() (Subscript i1, Subscript i2,
                             Subscript j1, Subscript j2) const
    {
        return const_Region (*this, i1, i2, j1, j2);
    }
#endif // TNT_USE_REGIONS
};


template <typename MaTRiX>
class UnitUpperTriangularView
{
protected:
    const MaTRiX  &A_;
    const typename MaTRiX::element_type zero;
    const typename MaTRiX::element_type one;

public:
    typedef typename MaTRiX::const_reference const_reference;
    typedef typename MaTRiX::element_type element_type;
    typedef typename MaTRiX::element_type value_type;
    typedef element_type T;

    Subscript lbound() const { return 1; }
    Subscript dim (Subscript d) const {  return A_.dim (d); }
    Subscript nrows() const { return A_.nrows(); }
    Subscript ncols() const { return A_.ncols(); }

    // constructors
    UnitUpperTriangularView (const MaTRiX & A) : A_(A), zero(0), one(1) {}

    const_reference get (Subscript i, Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (lbound() <= i);
        assert (i <= A_.nrows() + lbound() - 1);
        assert (lbound() <= j);
        assert (j <= A_.ncols() + lbound() - 1);
#endif
        if (i < j) {
            return A_(i,j);
        } else if (i == j) {
            return one;
        } else {
            return zero;
        }
    }

    const_reference operator() (Subscript i, Subscript j) const
    {
        return get (i, j);
    }


#ifdef TNT_USE_REGIONS

    typedef const_Region2D <UnitUpperTriangularView<MaTRiX> > const_Region;

    const_Region operator()(const Index1D & I, const Index1D & J) const
    {
        return const_Region (*this, I, J);
    }

    const_Region operator() (Subscript i1, Subscript i2,
                             Subscript j1, Subscript j2) const
    {
        return const_Region (*this, i1, i2, j1, j2);
    }
#endif  // TNT_USE_REGIONS
};

// helper functions

template <typename MaTRiX>
LowerTriangularView <MaTRiX>
Lower_triangular_view (const MaTRiX & A)
{
    return LowerTriangularView<MaTRiX> (A);
}

template <typename MaTRiX>
UnitLowerTriangularView <MaTRiX>
Unit_lower_triangular_view (const MaTRiX & A)
{
    return UnitLowerTriangularView<MaTRiX> (A);
}

template <typename MaTRiX>
UpperTriangularView <MaTRiX>
Upper_triangular_view (const MaTRiX & A)
{
    return UpperTriangularView<MaTRiX> (A);
}

template <typename MaTRiX>
UnitUpperTriangularView<MaTRiX>
Unit_upper_triangular_view (const MaTRiX &A)
{
    return UnitUpperTriangularView<MaTRiX> (A);
}

// IO

template <class MaTRiX>
std::ostream &
operator<< (std::ostream & s, const LowerTriangularView<MaTRiX> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    s << M << " " << N << endl;
    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            s << A(i,j) << " ";
        }
        s << endl;
    }
    return s;
}


template <class MaTRiX>
std::ostream &
operator<< (std::ostream & s, const UnitLowerTriangularView<MaTRiX> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    s << M << " " << N << endl;
    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            s << A(i,j) << " ";
        }
        s << endl;
    }
    return s;
}

template <class MaTRiX>
std::ostream &
operator<< (std::ostream & s, const UpperTriangularView<MaTRiX> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    s << M << " " << N << endl;
    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            s << A(i,j) << " ";
        }
        s << endl;
    }
    return s;
}

template <class MaTRiX>
std::ostream &
operator<< (std::ostream & s, const UnitUpperTriangularView<MaTRiX> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    s << M << " " << N << endl;
    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            s << A(i,j) << " ";
        }
        s << endl;
    }
    return s;
}

// matrix multiplication

template <class MaTRiX, class VecToR>
VecToR matmult (const LowerTriangularView<MaTRiX> & A, VecToR & x)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    assert (N == x.dim());

    typename MaTRiX::element_type sum = 0.0;
    VecToR result (M);

    Subscript start = A.lbound();
    Subscript Mend = M + A.lbound() -1 ;

    for (Subscript i = start; i <= Mend; ++i) {
        sum = 0.0;
        for (Subscript j = start; j <= i; ++j) {
            sum = sum + A(i,j) * x(j);
        }
        result(i) = sum;
    }
    return result;
}


template <class MaTRiX, class VecToR>
VecToR matmult (const UnitLowerTriangularView<MaTRiX> & A, VecToR & x)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    assert (N == x.dim());

    typename MaTRiX::element_type sum = 0.0;
    VecToR result (M);

    Subscript start = A.lbound();
    Subscript Mend = M + A.lbound() -1 ;

    for (Subscript i = start; i <= Mend; ++i) {
        sum = 0.0;
        for (Subscript j = start; j < i; ++j) {
            sum = sum + A(i,j) * x(j);
        }
        result(i) = sum;
    }
    return result;
}

template <class MaTRiX, class VecToR>
VecToR matmult (const UpperTriangularView<MaTRiX> & A, VecToR & x)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    assert (N == x.dim());

    typename MaTRiX::element_type sum = 0.0;
    VecToR result(M);

    Subscript start = A.lbound();
    Subscript Mend = M + A.lbound() -1 ;

    for (Subscript i = start; i <= Mend; ++i) {
        sum = 0.0;
        for (Subscript j = i; j <= N; ++j) {
            sum = sum + A(i,j) * x(j);
        }
        result(i) = sum;
    }
    return result;
}

template <class MaTRiX, class VecToR>
VecToR matmult (const UnitUpperTriangularView<MaTRiX> & A, VecToR & x)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    assert (N == x.dim());

    typename MaTRiX::element_type sum = 0.0;
    VecToR result(M);

    Subscript start = A.lbound();
    Subscript Mend = M + A.lbound() -1 ;

    for (Subscript i = start; i <= Mend; ++i) {
        sum = 0.0;
        for (Subscript j = i + 1; j <= N; ++j) {
            sum = sum + A(i,j) * x(j);
        }
        result(i) = sum;
    }
    return result;
}

} // namespace TNT

#endif //TRIANG_HPP

