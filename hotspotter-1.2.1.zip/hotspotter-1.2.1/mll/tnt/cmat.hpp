/*
 *
 * Template Numerical Toolkit (TNT): Linear Algebra Module
 *
 * Mathematical and Computational Sciences Division
 * National Institute of Technology,
 * Gaithersburg, MD USA
 *
 *
 * This software was developed at the National Institute of Standards and
 * Technology (NIST) by employees of the Federal Government in the course
 * of their official duties. Pursuant to title 17 Section 105 of the
 * United States Code, this software is not subject to copyright protection
 * and is in the public domain.  The Template Numerical Toolkit (TNT) is
 * an experimental system.  NIST assumes no responsibility whatsoever for
 * its use by other parties, and makes no guarantees, expressed or implied,
 * about its quality, reliability, or any other characteristic.
 *
 * BETA VERSION INCOMPLETE AND SUBJECT TO CHANGE
 * see http://math.nist.gov/tnt for latest updates.
 *
 */

/*
 * This file has been modified by Michael Na Li (Biostatistics,
 * University of Washington), to add some more overloaded operators.
 * Including matrix by scalar +, -, *, /. Also '*' between two matrices
 * is redefined as element by element. For matrix multiplication use
 * matmult() instead. '+=', '-=', '*=' and '/=' are defined for
 * both matrices and scalars (to the right).
 *
 * $Id: cmat.hpp,v 1.3 2002/02/20 18:42:06 nali Exp $
 */

// C compatible matrix: row-oriented, 0-based [i][j] and 1-based (i,j) indexing
//

#ifndef CMAT_HPP
#define CMAT_HPP

#include "tnt/subscript.hpp"
#include "tnt/vec.hpp"

#include <boost/operators.hpp>

#include <cstdlib>
#include <cassert>
#include <iostream>
#include <sstream>
#ifdef TNT_USE_REGIONS
#include "tnt/region2d.hpp"
#endif

namespace TNT
{

template <typename T>
class Matrix
    : boost::addable<Matrix<T> >,             // Matrix<T> + Matrix<T>
      boost::subtractable<Matrix<T> >,        // Matrix<T> - Matrix<T>
      boost::multipliable<Matrix<T> >,        // Matrix<T> * Matrix<T>
      boost::dividable<Matrix<T> >,           // Matrix<T> / Matrix<T>
      boost::addable2<Matrix<T>, T>,          // Matrix<T> + T, T + Matrix<T>
      boost::subtractable2<Matrix<T>, T>,     // Matrix<T> - T
      boost::multipliable2<Matrix<T>, T>,     // Matrix<T> * T, T * Matrix<T>
      boost::dividable2<Matrix<T>, T>,        // Matrix<T> / T
      boost::equality_comparable<Matrix<T> >  // Matrix<T> != Matrix<T>
{
public:

    typedef Matrix<T>          self_type;
    typedef T                  value_type;
    typedef value_type         element_type;
    typedef value_type*        pointer;
    typedef pointer            iterator;
    typedef value_type&        reference;
    typedef const value_type*  const_iterator;
    typedef const value_type&  const_reference;

    Subscript lbound () const { return TNT_BASE_OFFSET; }

protected:

    Subscript m_;
    Subscript n_;
    Subscript mn_;      // total size
    T* v_;
    T** row_;
    T* vm1_ ;           // these point to the same data, but are 1-based
    T** rowm1_;

    // internal helper function to create the array
    // of row pointers
    void initialize (Subscript M, Subscript N)
    {
        mn_ = M * N;
        m_ = M;
        n_ = N;

        v_     = new T  [mn_];
        row_   = new T* [M];
        rowm1_ = new T* [M];

        assert (v_     != 0);
        assert (row_   != 0);
        assert (rowm1_ != 0);

        T* p = v_;
        vm1_ = v_ - 1;
        for (Subscript i = 0; i < M; ++i) {
            row_[i] = p;
            rowm1_[i] = p-1;
            p += N ;
        }
        --rowm1_;     // compensate for 1-based offset
    }

    void copy (const T* v)
    {
        Subscript N = m_ * n_;
        Subscript i;

#ifdef TNT_UNROLL_LOOPS
        Subscript Nmod4 = N & 3;
        Subscript N4 = N - Nmod4;

        for (i = 0; i < N4; i += 4) {
            v_[i] = v[i];
            v_[i+1] = v[i+1];
            v_[i+2] = v[i+2];
            v_[i+3] = v[i+3];
        }

        for (i = N4; i < N; ++i) {
            v_[i] = v[i];
        }
#else
        for (i = 0; i < N; ++i) {
            v_[i] = v[i];
        }
#endif
    }

    void set (const T& val)
    {
        Subscript N = m_ * n_;
        Subscript i;

#ifdef TNT_UNROLL_LOOPS
        Subscript Nmod4 = N & 3;
        Subscript N4 = N - Nmod4;

        for (i = 0; i < N4; i += 4) {
            v_[i] = val;
            v_[i+1] = val;
            v_[i+2] = val;
            v_[i+3] = val;
        }
        for (i = N4; i < N; ++i) {
            v_[i] = val;
        }
#else
        for (i = 0; i < N; ++i) {
            v_[i] = val;
        }
#endif
    }

    void destroy ()
    {
        /* do nothing, if no memory has been previously allocated */
        if (v_ != 0) {
            /* if we are here, then matrix was previously allocated */
            if (v_ != 0) delete [] (v_);
            if (row_ != 0) delete [] (row_);

            /* return rowm1_ back to original value */
            if (rowm1_ != 0) {
                ++rowm1_;
                if (rowm1_ != 0) {
                    delete [] (rowm1_);
                }
            }
        }
        m_ = n_ = mn_ = 0;
    }

public:

    // constructors

    Matrix() : m_(0), n_(0), mn_(0), v_(0), row_(0), vm1_(0), rowm1_(0) {}

    Matrix (const self_type &A)
    {
        initialize (A.m_, A.n_);
        copy (A.v_);
    }

    Matrix (Subscript M, Subscript N, const value_type & value = T())
    {
        initialize (M, N);
        set (value);
    }

    Matrix (Subscript M, Subscript N, const T* v)
    {
        initialize (M,N);
        copy (v);
    }

    Matrix (Subscript M, Subscript N, const std::string & s)
    {
        initialize (M, N);
        std::istringstream ins (s);
        for (Subscript i = 0; i < M; ++i) {
            for (Subscript j = 0; j < N; ++j) {
                ins >> row_[i][j];
            }
        }
    }

    template<typename ForwardIterator>
    Matrix (Subscript nrow, ForwardIterator first, ForwardIterator last)
    {
        Subscript total = 0;
        std::distance (first, last, total);
        Subscript ncol = total / nrow;
        initialize (nrow, ncol);
        for (int i = 0; i < mn_; ++first, ++i) {
            v_[i] = *first;
        }
    }

    // destructor
    ~Matrix()
    {
        destroy ();
    }

    operator    T** ()       { return row_; }
    operator    T** () const { return row_; }
    iterator begin () { return v_;}
    iterator end ()   { return v_ + mn_; }
    const iterator begin () const { return v_;}
    const iterator end () const  { return v_ + mn_; }
    pointer data () { return v_; }

    Subscript  size () const { return mn_;  }
    Subscript nrows () const { return m_;   }
    Subscript ncols () const { return n_;   }

    // reallocating
    //
    self_type & resize (Subscript M, Subscript N)
    {
        if (nrows () != M || ncols () != N) {
            destroy ();
            initialize (M, N);
        }
        return *this;
    }

    // assignments
    self_type & operator= (const self_type &A)
    {
        if (v_ != A.v_) {
            if (m_ != A.m_ || n_ != A.n_)  {    // need re-alloc
                destroy ();
                initialize (A.m_, A.n_);
                copy (A.v_);
            } else {
                copy(A.v_);
            }
        }
        return *this;
    }

    self_type & operator= (const element_type & scalar)
    {
        set (scalar);
        return *this;
    }

    Subscript dim (Subscript d) const
    {
#ifdef TNT_BOUNDS_CHECK
       assert (d == 1 || d == 2);
#endif
       return d == 1 ? m_ : (d == 2 ? n_ : 0);
    }

    pointer operator[] (Subscript i)
    {
#ifdef TNT_BOUNDS_CHECK
        assert (0 <= i);
        assert (i < m_) ;
#endif
        return row_[i];
    }

    const pointer operator[] (Subscript i) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (0 <= i);
        assert (i < m_) ;
#endif
        return row_[i];
    }

    reference operator() (Subscript i)
    {
#ifdef TNT_BOUNDS_CHECK
        assert (1 <= i);
        assert (i <= mn_) ;
#endif
        return vm1_[i];
    }

    const_reference operator() (Subscript i) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (1 <= i);
        assert (i <= mn_) ;
#endif
        return vm1_[i];
    }

     reference operator() (Subscript i, Subscript j)
    {
#ifdef TNT_BOUNDS_CHECK
        assert (1 <= i);
        assert (i <= m_) ;
        assert (1 <= j);
        assert (j <= n_);
#endif
        return rowm1_[i][j];
    }

    const_reference operator() (Subscript i, Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (1 <= i);
        assert (i <= m_) ;
        assert (1 <= j);
        assert (j <= n_);
#endif
        return rowm1_[i][j];
    }

#ifdef TNT_USE_REGIONS
    typedef Region2D<self_type > Region;

    Region operator() (const Index1D & I, const Index1D & J)
    {
        return Region (*this, I, J);
    }

    typedef const_Region2D<self_type > const_Region;
    const_Region operator() (const Index1D & I, const Index1D & J) const
    {
        return const_Region (*this, I, J);
    }
#endif
    // Operators

    self_type & operator+= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 0; i < m_; ++i) {
            for (Subscript j = 0; j < n_; ++j) {
                row_[i][j] += B[i][j];
            }
        }
        return *this;
    }

    self_type & operator-= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 0; i < m_; ++i) {
            for (Subscript j = 0; j < n_; ++j) {
                row_[i][j] -= B[i][j];
            }
        }
        return *this;
    }

    self_type & operator*= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 0; i < m_; ++i) {
            for (Subscript j = 0; j < n_; ++j) {
                row_[i][j] *= B[i][j];
            }
        }
        return *this;
    }

    self_type & operator/= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 0; i < m_; ++i) {
            for (Subscript j = 0; j < n_; ++j) {
                row_[i][j] /= B[i][j];
            }
        }
        return *this;
    }

    self_type & operator+= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i += scalar;
        }
        return *this;
    }

    self_type & operator-= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i -= scalar;
        }
        return *this;
    }

    self_type & operator*= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i *= scalar;
        }
        return *this;
    }

    self_type & operator/= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i /= scalar;
        }
        return *this;
    }

    bool operator== (const self_type & B) const
    {
        bool equal = true;
        if (m_ != B.nrows () || n_ != B.ncols ()) {
            equal = false;
        } else {
            const_iterator bi = B.begin ();
            for (Subscript i = 0; i < m_ && equal; ++i, ++bi) {
                if (v_[i] != *bi) {
                    equal = false;
                }
            }
        }
        return equal;
    }
};

/* ***************************  I/O  ********************************/

template <typename T>
std::ostream & operator<< (std::ostream & s, const Matrix<T> & A)
{
    Subscript M = A.nrows ();
    Subscript N = A.ncols ();

    s << M << " " << N << "\n";
    for (Subscript i = 0; i < M; ++i) {
        for (Subscript j = 0; j < N; ++j) {
            s << A[i][j] << " ";
        }
        s << std::endl;
    }
    return s;
}

template <typename T>
std::istream & operator>> (std::istream & s, Matrix<T> & A)
{
    Subscript M;
    Subscript N;
    s >> M >> N;
    if (A.nrows() != M || A.ncols() != N) {
        A.resize (M, N);
    }
    for (Subscript i = 0; i < M; ++i) {
        for (Subscript j = 0; j < N; ++j) {
            s >> A[i][j];
        }
    }
    return s;
}

// *******************[ basic matrix algorithms ]***************************

template <typename T>
inline
Matrix<T>
transpose (const Matrix<T> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    Matrix<T> S (N, M);

    for (Subscript i = 0; i < M; ++i) {
        for (Subscript j = 0; j < N; ++j) {
            S[j][i] = A[i][j];
        }
    }
    return S;
}

template <typename T>
inline
Matrix<T>
matmult (const Matrix<T> & A, const Matrix<T> & B)
{
    Matrix<T> tmp;
    matmult (tmp, A, B);
    return tmp;
}

template <typename T>
inline
void
matmult (Matrix<T> & C, const Matrix<T> & A, const Matrix<T> & B)
{
    assert (A.ncols() == B.nrows());
    Subscript M = A.nrows();
    Subscript N = A.ncols();
    Subscript K = B.ncols();

    C.resize (M, K);
    T sum;
    for (Subscript i = 0; i < M; ++i) {
        for (Subscript k = 0; k < K; ++k) {
            sum = 0;
            for (Subscript j = 0; j < N; ++j) {
                sum += A[i][j] * B[j][k];
            }
            C[i][k] = sum;
        }
    }
}

template <typename T>
void
matmult (Vector<T> & c, const Matrix<T> & A, const Vector<T> & x)
{
#ifdef TNT_BOUNDS_CHECK
    assert (A.ncols () == x.size ());
#endif

    Subscript M = A.nrows ();
    Subscript N = A.ncols ();

    c.resize (M);
    T sum;
    for (Subscript i = 0; i < M; ++i) {
        sum = 0;
        for (Subscript j = 0; j < N; ++j) {
            sum += A[i][j] * x[j];
        }
        c[i] = sum;
    }
}

template <typename T>
inline
Vector<T>
matmult (const Matrix<T> & A, Vector<T> & x)
{
    Vector<T> tmp;
    matmult (tmp, A, x);
    return tmp;
}


// Extract the diagonal element of the matrix
template <typename T>
inline
Vector<T>
diag (const Matrix<T> & A)
{
    Vector<T> tmp (std::min (A.nrows (), A.ncols ()));
    for (Subscript i = 0; i < tmp.size (); ++i) {
        tmp[i] = A[i][i];
    }
    return tmp;
}

template <typename T>
inline
void
fill_row_offset0 (Matrix<T> & A, Subscript row, const T & x)
{
#ifdef TNT_CHECK_BOUNDS
    assert (row < A.nrows () && row >= 0);
#endif
    for (Subscript i = 0; i < A.ncols (); ++i) {
        A[row][i] = x;
    }
}

template <typename T>
inline
void
fill_row_offset1 (Matrix<T> & A, Subscript row, const T & x)
{
#ifdef TNT_CHECK_BOUNDS
    assert (row <= A.nrows () && row > 0);
#endif
    for (Subscript i = 1; i <= A.ncols (); ++i) {
        A(row, i) = x;
    }
}

template <typename T>
inline
void
fill_row_offset0 (Matrix<T> & A, Subscript row, const Vector<T> & x)
{
#ifdef TNT_CHECK_BOUNDS
    assert (row < A.nrows () && row >= 0);
    assert (x.size () == A.ncols ());
#endif
    for (Subscript i = 0; i < A.ncols (); ++i) {
        A[row][i] = x[i];
    }
}

template <typename T>
inline
void
fill_row_offset1 (Matrix<T> & A, Subscript row, const Vector<T> &  x)
{
#ifdef TNT_CHECK_BOUNDS
    assert (row <= A.nrows () && row > 0);
    assert (x.size () == A.ncols ());
#endif
    for (Subscript i = 1; i <= A.ncols (); ++i) {
        A(row, i) = x(i);
    }
}

} // namespace TNT

#endif // CMAT_HPP
