/*
*
* Template Numerical Toolkit (TNT): Linear Algebra Module
*
* Mathematical and Computational Sciences Division
* National Institute of Technology,
* Gaithersburg, MD USA
*
*
* This software was developed at the National Institute of Standards and
* Technology (NIST) by employees of the Federal Government in the course
* of their official duties. Pursuant to title 17 Section 105 of the
* United States Code, this software is not subject to copyright protection
* and is in the public domain.  The Template Numerical Toolkit (TNT) is
* an experimental system.  NIST assumes no responsibility whatsoever for
* its use by other parties, and makes no guarantees, expressed or implied,
* about its quality, reliability, or any other characteristic.
*
* BETA VERSION INCOMPLETE AND SUBJECT TO CHANGE
* see http://math.nist.gov/tnt for latest updates.
*
*/

// Matrix Transpose Views

#ifndef TRANSV_HPP
#define TRANSV_HPP

#include <iostream>
#include <cassert>
#include "tnt/vec.hpp"

namespace TNT
{

template <typename Array2D>
class Transpose_View
{
protected:
    const Array2D & A_;

public:
    typedef typename Array2D::element_type T;
    typedef         T   value_type;
    typedef         T   element_type;
    typedef         T*  pointer;
    typedef         T*  iterator;
    typedef         T&  reference;
    typedef const   T*  const_iterator;
    typedef const   T&  const_reference;


    const Array2D & array()  const { return A_; }
    Subscript nrows() const { return A_.ncols();}
    Subscript ncols() const { return A_.nrows();}
    Subscript lbound() const { return A_.lbound(); }
    Subscript dim (Subscript i) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (A_.lbound() <= i);
        assert (i<= A_.lbound()+1);
#endif
        if (i == A_.lbound()) {
            return nrows();
        } else {
            return ncols();
        }
    }

    // Copy constructor
    Transpose_View (const Transpose_View<Array2D> & A) : A_(A.A_) {};
    // Constructor
    Transpose_View (const Array2D & A) : A_(A) {};


    const typename Array2D::element_type & operator() (Subscript i,
                                                       Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (lbound() <= i);
        assert (i <= A_.ncols() + lbound() - 1);
        assert (lbound()<=j);
        assert (j <= A_.nrows() + lbound() - 1);
#endif
        return A_ (j,i);
    }
};

template <typename MaTRiX>
Transpose_View<MaTRiX> Transpose_view (const MaTRiX & A)
{
    return Transpose_View<MaTRiX>(A);
}

template <typename MaTRiX, typename T>
Vector<T>
matmult (const Transpose_View<MaTRiX> & A, const Vector<T> & B)
{
    Subscript  M = A.nrows();
    Subscript  N = A.ncols();

    assert (B.dim() == N);

    Vector<T> x (N);

    T tmp = 0;
    for (Subscript i = 1; i <= M; ++i) {
        tmp = 0;
        for (Subscript j = 1; j <= N; j++) {
            tmp += A(i,j) * B(j);
        }
        x (i) = tmp;
    }
    return x;
}

template <typename MaTRiX>
std::ostream &
operator<< (std::ostream & s, const Transpose_View<MaTRiX> &A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    Subscript start = A.lbound();
    Subscript Mend = M + A.lbound() - 1;
    Subscript Nend = N + A.lbound() - 1;

    s << M << "  " << N << endl;
    for (Subscript i = start; i <= Mend; ++i) {
        for (Subscript j = start; j <= Nend; ++j) {
            s << A(i,j) << " ";
        }
        s << endl;
    }
    return s;
}

} // namespace TNT

#endif // TRANSV_HPP
