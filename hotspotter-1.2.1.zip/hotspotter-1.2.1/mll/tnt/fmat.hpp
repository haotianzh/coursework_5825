/*
*
* Template Numerical Toolkit (TNT): Linear Algebra Module
*
* Mathematical and Computational Sciences Division
* National Institute of Technology,
* Gaithersburg, MD USA
*
*
* This software was developed at the National Institute of Standards and
* Technology (NIST) by employees of the Federal Government in the course
* of their official duties. Pursuant to title 17 Section 105 of the
* United States Code, this software is not subject to copyright protection
* and is in the public domain.  The Template Numerical Toolkit (TNT) is
* an experimental system.  NIST assumes no responsibility whatsoever for
* its use by other parties, and makes no guarantees, expressed or implied,
* about its quality, reliability, or any other characteristic.
*
* BETA VERSION INCOMPLETE AND SUBJECT TO CHANGE
* see http://math.nist.gov/tnt for latest updates.
*
*/

// Fortran-compatible matrix: column oriented, 1-based (i,j) indexing

#ifndef FMAT_HPP
#define FMAT_HPP

#include "tnt/subscript.hpp"
#include "tnt/vec.hpp"
#ifdef TNT_USE_REGIONS
#include "tnt/region2d.hpp"
#endif

#include <boost/operators.hpp>

#include <cstdlib>
#include <cassert>
#include <iostream>
#include <sstream>

// simple 1-based, column oriented Matrix class

namespace TNT
{

template <typename T>
class Fortran_Matrix
    : boost::addable<Fortran_Matrix<T> >,        // Matrix<T> + Matrix<T>
      boost::subtractable<Fortran_Matrix<T> >,   // Matrix<T> - Matrix<T>
      boost::multipliable<Fortran_Matrix<T> >,   // Matrix<T> * Matrix<T>
      boost::dividable<Fortran_Matrix<T> >,      // Matrix<T> / Matrix<T>
      boost::addable2<Fortran_Matrix<T>, T>,     // Matrix<T> + T, T + Matrix<T>
      boost::subtractable2<Fortran_Matrix<T>, T>,// Matrix<T> - T
      boost::multipliable2<Fortran_Matrix<T>, T>,// Matrix<T> * T, T * Matrix<T>
      boost::dividable2<Fortran_Matrix<T>, T>,        // Matrix<T> / T
      boost::equality_comparable<Fortran_Matrix<T> >  // Matrix<T> != Matrix<T>
{
public:
    typedef Fortran_Matrix<T>  self_type;
    typedef T                  value_type;
    typedef value_type         element_type;
    typedef value_type*        pointer;
    typedef pointer            iterator;
    typedef value_type&        reference;
    typedef const pointer      const_iterator;
    typedef const value_type&  const_reference;

    Subscript lbound() const { return TNT_BASE_OFFSET; }
 
protected:
    T* v_;                  // these are adjusted to simulate 1-offset
    Subscript m_;
    Subscript n_;
    T** col_;               // these are adjusted to simulate 1-offset

    // internal helper function to create the array of row pointers
    void initialize (Subscript M, Subscript N)
    {
        // adjust col_[] pointers so that they are 1-offset:
        //   col_[j][i] is really col_[j-1][i-1];
        //
        // v_[] is the internal contiguous array, it is still 0-offset
        //
        v_ = new T [M*N];
        col_ = new T*[N];

        assert (v_  != NULL);
        assert (col_ != NULL);

        m_ = M;
        n_ = N;
        T* p = v_ - 1;              
        for (Subscript i = 0; i < N; ++i) {
            col_[i] = p;
            p += M ;
        }
        --col_; 
    }
   
    void copy (const T* v)
    {
        Subscript N = m_ * n_;
#ifdef TNT_UNROLL_LOOPS
        Subscript Nmod4 = N & 3;
        Subscript N4 = N - Nmod4;

        for (Subscript i = 0; i < N4; i += 4)
        {
            v_[i] = v[i];
            v_[i+1] = v[i+1];
            v_[i+2] = v[i+2];
            v_[i+3] = v[i+3];
        }

        for (Subscript i = N4; i < N; ++i) {
            v_[i] = v[i];
        }
#else
        for (Subscript i = 0; i < N; ++i) {
            v_[i] = v[i];
        }
#endif      
    }

    void set (const element_type & val)
    {
        Subscript N = m_ * n_;
#ifdef TNT_UNROLL_LOOPS
        Subscript Nmod4 = N & 3;
        Subscript N4 = N - Nmod4;

        for (Subscript i = 0; i < N4; i += 4)
        {
            v_[i] = val;
            v_[i+1] = val;
            v_[i+2] = val;
            v_[i+3] = val; 
        }

        for (Subscript i = N4; i < N; ++i) {
            v_[i] = val;
        }
#else
        for (Subscript i = 0; i < N; ++i) {
            v_[i] = val;
        }
#endif      
    }

    void destroy ()
    {     
        /* do nothing, if no memory has been previously allocated */
        if (v_ != 0) {
            /* if we are here, then matrix was previously allocated */
            delete [] (v_);     
            ++col_;                // changed back to 0-offset
            delete [] (col_);
        }
    }

public:

    iterator begin () { return v_; }
    const_iterator begin () const { return v_;}

    iterator end () { return v_ + m_*n_; }
    const_iterator end () const { return v_ + m_*n_; }

    pointer data () { return v_; }

    // constructors
    Fortran_Matrix() : v_(0), m_(0), n_(0), col_(0)  {};

    Fortran_Matrix (const Fortran_Matrix<T> &A)
    {
        initialize (A.m_, A.n_);
        copy (A.v_);
    }

    Fortran_Matrix (Subscript M, Subscript N, const T& value = T())
    {
        initialize (M,N);
        set (value);
    }

    Fortran_Matrix (Subscript M, Subscript N, const pointer v)
    {
        initialize (M,N);
        copy (v);
    }

    Fortran_Matrix (Subscript M, Subscript N, const std::string & s)
    {
        initialize (M, N);
        std::istringstream ins(s);
        for (Subscript i = 1; i <= M; ++i) {
            for (Subscript j = 1; j <= N; ++j) {
                ins >> (*this)(i,j);
            }
        }
    }

    // destructor
    ~Fortran_Matrix ()
    {
        destroy ();
    }

    // assignments
    //
    self_type & operator= (const self_type & A)
    {
        if (v_ != A.v_) {
            if (m_ == A.m_ && n_ == A.n_) { // no need to re-alloc
                copy (A.v_);
            } else {
                destroy ();
                initialize (A.m_, A.n_);
                copy (A.v_);
            }
        }
        return *this;
    }
        
    self_type & operator= (const element_type & scalar)
    { 
        set (scalar); 
        return *this;
    }


    Subscript dim (Subscript d) const 
    {
#ifdef TNT_BOUNDS_CHECK
       assert (d >= 1);
       assert (d <= 2);
#endif
       return (d == 1) ? m_ : ((d == 2) ? n_ : 0); 
    }

    Subscript nrows() const { return m_; }
    Subscript ncols() const { return n_; }

    self_type & resize (Subscript M, Subscript N)
    {
        if (nrows() != M || ncols() != N) {
            destroy ();
            initialize (M, N);
        }
        return *this;
    }

    // 1-based element access
    //
    reference operator() (Subscript i, Subscript j)
    { 
#ifdef TNT_BOUNDS_CHECK
        assert (1 <= i);
        assert (i <= m_);
        assert (1 <= j);
        assert (j <= n_);
#endif
        return col_[j][i]; 
    }

    const_reference operator () (Subscript i, Subscript j) const
    {
#ifdef TNT_BOUNDS_CHECK
        assert (1 <= i);
        assert (i <= m_);
        assert (1 <= j);
        assert (j <= n_);
#endif
        return col_[j][i]; 
    }


#ifdef TNT_USE_REGIONS
    typedef Region2D<self_type> Region;
    Region operator() (const Index1D & I, const Index1D & J)
    {
        return Region (*this, I,J);
    }

    typedef const_Region2D<self_type> const_Region;
    const_Region operator() (const Index1D & I, const Index1D & J) const
    {
        return const_Region (*this, I,J);
    }
#endif

    self_type & operator+= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 1; i <= m_; ++i) {
            for (Subscript j = 1; j <= n_; ++j) {
                (*this)(i, j) += B (i, j);
            }
        }
        return *this;
    }

    self_type & operator-= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 1; i <= m_; ++i) {
            for (Subscript j = 1; j <= n_; ++j) {
                (*this)(i, j) -= B (i, j);
            }
        }
        return *this;
    }

    self_type & operator*= (const self_type & B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 1; i <= m_; ++i) {
            for (Subscript j = 1; j <= n_; ++j) {
                (*this)(i, j) *= B (i, j);
            }
        }
        return *this;
    }

    self_type & operator/= (const self_type &B)
    {
        assert (m_ == B.nrows());
        assert (n_ == B.ncols());
        for (Subscript i = 1; i <= m_; ++i) {
            for (Subscript j = 1; j <= n_; ++j) {
                (*this)(i, j) /= B (i, j);
            }
        }
        return *this;
    }

    self_type & operator+= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i += scalar;
        }
        return *this;
    }

    self_type & operator-= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i -= scalar;
        }
        return *this;
    }

    self_type & operator*= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i *= scalar;
        }
        return *this;
    }

    self_type & operator/= (const value_type & scalar)
    {
        for (iterator i = this->begin (); i != this->end (); ++i) {
            *i /= scalar;
        }
        return *this;
    }

    bool operator== (const self_type & B) const
    {
        bool equal = true;
        if (m_ != B.nrows () || n_ != B.ncols ()) {
            equal = false;
        } else {
            const_iterator bi   = B.begin ();
            const_iterator self = this->begin ();
            for (; self != this->end () && equal; ++bi, ++self) {
                if (*self != *bi) {
                    equal = false;
                }
            }
        }
        return equal;
    }

};


/* ***************************  I/O  ********************************/

template <typename T>
std::ostream & 
operator<< (std::ostream & s, const Fortran_Matrix<T> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    s << M << " " << N << "\n";

    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            s << A(i,j) << " ";
        }
        s << std::endl;
    }
    return s;
}

template <class T>
std::istream & 
operator>> (std::istream & s, Fortran_Matrix<T> & A)
{
    Subscript M, N;
    s >> M >> N;

    if ( M != A.nrows() || N != A.num_cols()) {
        A.resize(M,N);
    }

    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            s >>  A(i,j);
        }
    }
    return s;
}

template <typename T>
Fortran_Matrix<T> 
transpose (const Fortran_Matrix<T> & A)
{
    Subscript M = A.nrows();
    Subscript N = A.ncols();

    Fortran_Matrix<T> S (N,M);

    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript j = 1; j <= N; ++j) {
            S(j,i) = A(i,j);
        }
    }
    return S;
}

template <typename T>
inline 
Fortran_Matrix<T> 
matmult (const Fortran_Matrix<T> & A, const Fortran_Matrix<T> & B)
{
    Fortran_Matrix<T> tmp;
    matmult (tmp, A, B);
    return tmp;
}

template <typename T>
inline
void 
matmult (Fortran_Matrix<T> & C, 
         const Fortran_Matrix<T> & A, const Fortran_Matrix<T> & B)
{
    assert(A.ncols() == B.nrows());

    Subscript M = A.nrows();
    Subscript N = A.ncols();
    Subscript K = B.ncols();

    C.resize(M,K);         // adjust shape of C, if necessary

    T sum; 

    const T* row_i;
    const T* col_k;

    for (Subscript i = 1; i <= M; ++i) {
        for (Subscript k = 1; k <= K; ++k) {
            row_i = &A(i,1);
            col_k = &B(1,k);
            sum = 0;
            for (Subscript j = 1; j <= N; ++j) {
                sum +=  *row_i * *col_k;
                row_i += M;
                col_k ++;
            }
            C(i,k) = sum; 
        }
    }
}

template <typename T>
inline
Vector<T> 
matmult (const Fortran_Matrix<T> & A, const Vector<T> & x)
{
    Vector<T> tmp;
    matmult (tmp, A, x);
    return tmp;
}

template <typename T>
inline
void
matmult (Vector<T> & C, const Fortran_Matrix<T> & A, const Vector<T> & x)
{
#ifdef TNT_BOUNDS_CHECK
    assert (A.ncols () == x.dim());
#endif

    Subscript M = A.nrows();
    Subscript N = A.ncols();
    C.resize (M);
    T sum;
    for (Subscript i = 1; i <= M; ++i) {
        sum = 0;
        for (Subscript j = 1; j <= N; ++j) {
            sum += A(i,j) * x(j);
        }
        C(i) = sum; 
    }
}

}  // namespace TNT

#endif // FMAT_HPP
