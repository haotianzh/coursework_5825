
#ifndef NONNUMERIC_HPP
#define NONNUMERIC_HPP

namespace MLL
{

struct free_object
{
    template <typename T>
    void operator () (const T* obj) const
    {
        delete obj;
    }
};

/**
 * A relaxed version of std::transform. Allows the functor has arbitrary side
 * effects except side effects that invalidate the input or output iterator or
 * sequences.
 *
 * Klaus and Langer, CUJ 2001
 */

/*
 Effects: Applies trans to the result of dereferencing every iterator in the
          range [first, last) starting from first and  proceeding to last -
          1 and assigns through every iterator i in the range [result, result
          + (last - first)) the return value of trans(*(first + (i - result)).
 Requires: trans shall not have any side effects that invalidate any iterator
          in the range [first, last) and [result, result + (last - first)).
 Returns: result + (last - first)
 Complexity: Exactly last - first applications of trans and exactly last -
          first assignments.
 Notes:   result may be equal to first.
*/

template <class InputIterator, class OutputIterator, class Transformator>
OutputIterator
relaxed_transform (InputIterator first, InputIterator last,
                   OutputIterator result, Transformator trans)
{
    for ( ; first != last; ++first, ++result) {
        *result = trans (*first);
    }
    return result;
}

} // namespace MLL

#endif // NONNUMERIC_HPP
