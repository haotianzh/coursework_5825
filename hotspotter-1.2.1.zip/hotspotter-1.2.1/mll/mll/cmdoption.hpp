/**
 * @file   cmdoption.hpp
 * @author Michael Na Li
 * @date   Thu Jan  9 14:34:28 2003
 *
 * @brief  A simple command line option parser library for C++.
 */
/*
 * @defgroup CmdOptionParser A command line option parser class.
 * @{
 */
/**
 * @page CmdOptionPareserUsage Usage of the Command Parser library.
 *
 * -  Declare your option one by one, the syntax is
 *
 *    @code
 *    OptionType varname (char_name, keyword, value_hint, description,
 *                        default_value);
 *    @endcode
 *
 *    where 'char_name' is used as short option and 'keyword' is corresponding
 *    long option.  'value_hint' gives some hint of what additional argument
 *    is required for this option.  'description' gives the help message.
 *    'default_value' is the default value.
 *
 *    Implemented option types are MLL::BoolOption, MLL::IntOption,
 *    MLL::DoubleOption, MLL::StringOption.
 *
 *    If 'char_name' is '\0' then this option is assumed to be a positional
 *    option and is required.  All non-positional options are assumed to be
 *    optional.
 *
 * -  Declare the parser class MLL::CmdOptionParser:
 *
 *    @code
 *    CmdOptionParser opt_parser (program_name,
 *                                program_version,
 *                                program_copyright,
 *                                program_author,
 *                                program_description,
 *                                program_bug_address,
 *                                arg1, arg2, ..., argn, 0);
 *    @endcode
 *
 * -  Parse the command line:
 *
 *    @code
 *    opt_parser.parse (argc, argv);
 *    @endcode
 *
 *    returns 0 if successful, 1 if not.
 *
 * -  Use the options.  Corresponding type casting operators are definded for
 *    them so in most case you can use them as simple int, bool, double or
 *    std::string type.  In particular, @p operator<< and @p = are defined for
 *    each option type and MLL::StringOption::c_str () member function is
 *    defined.
 *
 *    Whenever in doubt, use explicit cast to get the value of options.
 *
 * @bug
 *
 * -  Only short option is implemented.
 *
 * -  Only minimal error checking.
 *
 * @todo
 *
 * -  Bug fixes.
 *
 * -  Option list types.
 *
 * \$Id: cmdoption.hpp,v 1.5 2003/03/07 09:27:16 nali Exp $
 *
 */
#ifndef CMDOPTION_HPP
#define CMDOPTION_HPP

#include "mll/config.hpp"
#include "mll/strutil.hpp"
#include "dbg/dbg.hpp"
#include <boost/format.hpp>

#include <map>
#include <string>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <cstdarg>

#ifdef NO_GETOPT_H
#include "mll/getopt.h"
#else
#include <getopt.h>
#endif

namespace MLL
{

/**
 * @class Option
 *
 * @brief The abstract base classes for all types of command line options.
 *
 */
class Option
{
public :

    /**
     * Constructor for class Option.
     *
     * @param key              The integer key provided by the current option
     *                         to the option parser.  If key has a value
     *                         that is a printable ASCII character (i.0e.,
     *                         `isascii (key)' is true), it _also_
     *                         specifies a short option `-CHAR', where CHAR
     *                         is the ASCII character with the code key.
     *
     * @param name             The long name for this option, corresponding
     *                         to the long option `--NAME'; this field may
     *                         be zero if this option _only_ has a short name.
     *                         If the keyword is zero and key is not an
     *                         ASCII character, then this option is a required
     *                         positional argument.
     *
     * @param value            If non-zero, this is the name of an argument
     *                         associated with this option, which must be
     *                         provided (e.g., with the `--NAME=VALUE' or
     *                         `-CHAR VALUE' syntaxes). Or if this is a
     *                         positional argument, then it of couse must have
     *                         a value.
     *
     * @param doc              A documentation string for this option, for
     *                         printing in help messages.
     */
    Option( int key,
            const char *name,
            const char *value,
            const char *doc,
            int has_arg = 1)
        : value_ (value),
          doc_ (doc),
          set_in_cmdline_ (false)
    {
        opt_.name = name;
        opt_.has_arg = has_arg;
        opt_.flag = 0;
        opt_.val  = key;
    }

    /**
     * Destructor.  Does nothing.
     */
    virtual ~Option( )
    {}

    /**
     * Return the integer key for this option.
     *
     *
     * @return integer key.
     */
    int get_key( ) const
    {
        return opt_.val;
    }

    /**
     * Return the name (long option) for this option.  0 if no long option.
     *
     *
     * @return option name (long option)
     */
    const char *get_name( ) const
    {
        return opt_.name;
    }

    const char *get_value( ) const
    {
        return value_;
    }

    const char *get_doc( ) const
    {
        return doc_;
    }

    /**
     * Whether this option is given in the command line.
     *
     *
     * @return true if this option is set in the command line.
     */
    bool is_set( ) const
    {
        return set_in_cmdline_;
    }

    /**
     * An option is optional (as supposed to obligatory positional argument)
     * if it has non null name (long option) or its key is a printable
     * character (short option).
     *
     *
     * @return true if optional option.
     */
    bool is_option( ) const
    {
        return opt_.name != 0 || isascii (opt_.val);
    }

    /**
     * An option has a short version if its key is printable (isascii).
     *
     *
     * @return true if this option has a short option.
     */
    bool has_short( ) const
    {
        return isascii (opt_.val);
    }

    bool has_arg( ) const
    {
        return opt_.has_arg;
    }

    virtual void print_summary( ) = 0;

    virtual void setval( const char * ) = 0;

    void print_doc( ) const
    {
        std::string key_str;
        if (is_option ()) {
            if (isascii (opt_.val)) {
                key_str += boost::io::str (boost::format ("-%c") %
                                           char (opt_.val));
            } else {
                key_str += "  ";
            }
            if (opt_.name && has_short ()) {
                key_str += boost::io::str (boost::format (", --%s") %
                                           opt_.name);
            } else {
                key_str += boost::io::str (boost::format ("  --%s") %
                                           opt_.name);
            }
            if (has_arg ()) {
                if (opt_.name) {
                    key_str += "=";
                }
                key_str += MLL::upper (value_);
            }
        } else {
            key_str += MLL::upper (value_);
        }
        std::cout << boost::format ("  %s%|30t|%s\n") % key_str % doc_;
    }

    void copy_to_option( option & opt )
    {
        opt.name = opt_.name;
        opt.has_arg = opt_.has_arg;
        opt.flag = opt_.flag;
        opt.val = opt_.val;
    }

protected :

    void set_true( )
    {
        set_in_cmdline_ = true;
    }

private :
    const char *value_;
    const char *doc_;

    option opt_;

    bool set_in_cmdline_;
};

class BoolOption : public Option
{
public :
    BoolOption( int key,
                const char *name,
                const char *value,
                const char *doc,
                bool default_value )
        : Option (key, name, value, doc, 0),
          val_ (default_value)
    {}

    virtual void setval( const char * )
    {
        val_ = !val_;
        set_true ();
    }

    virtual void print_summary( )
    {
        std::cout << boost::format (" %35s: ") % get_doc ()
                  << (val_ ? "Yes" : "No") << std::endl;
    }

    operator bool( ) const
    {
        return val_;
    }

    BoolOption & operator=( bool val )
    {
        val_ = val;
        return *this;
    }

private :
    bool val_;
};

std::ostream &
operator<<( std::ostream & os, const BoolOption & opt);

class IntOption : public Option
{
public :
    IntOption( int key,
               const char *name,
               const char *value,
               const char *doc,
               int default_value)
        : Option (key, name, value, doc),
          val_ (default_value)
    {}

    virtual void setval( const char *optarg )
    {
        val_ = atoi (optarg);
        set_true ();
    }

    virtual void print_summary( )
    {
        std::cout << boost::format (" %35s: %d\n")
            % get_doc () % val_;
    }

    operator int( ) const
    {
        return val_;
    }

    IntOption & operator=( int val )
    {
        val_ = val;
        return *this;
    }

private :
    int val_;
};

std::ostream &
operator<<( std::ostream & os, const IntOption & opt);

class DoubleOption : public Option
{
public :
    DoubleOption (int key,
                  const char *name,
                  const char *value,
                  const char *doc,
                  double default_value)
        : Option (key, name, value, doc),
          val_ (default_value)
    {}

    virtual void setval( const char *optarg )
    {
        val_ = atof (optarg);
        set_true ();
    }

    virtual void print_summary( )
    {
        std::cout << boost::format (" %35s: %f\n")
            % get_doc () % val_;
    }

    operator double( ) const
    {
        return val_;
    }

    DoubleOption & operator=( double val )
    {
        val_ = val;
        return *this;
    }

private :
    double val_;
};

std::ostream &
operator<<( std::ostream & os, const DoubleOption & opt);

class StringOption : public Option
{
public :
    StringOption( int key,
                  const char *name,
                  const char *value,
                  const char *doc,
                  const std::string & default_value)
        : Option (key, name, value, doc),
          val_ (default_value)
    {}

    virtual void setval( const char *optarg )
    {
        val_ = optarg;
        set_true ();
    }

    virtual void print_summary( )
    {
        std::cout << boost::format (" %35s: %s\n")
            % get_doc () % val_;
    }

    operator std::string( ) const
    {
        return val_;
    }

    StringOption & operator=( const std::string & val )
    {
        val_ = val;
        return *this;
    }

    const char * c_str( ) const
    {
        return val_.c_str ();
    }

private :
    std::string val_;
};

std::ostream &
operator<<( std::ostream & os, const StringOption & opt);

/**
 * Command line parser class.
 *
 */
class CmdOptionParser
{
public:

    static dbg::dbg_source dbgsrc;

    enum ArgumentType {
        noarg = 0, required, optional
    };

    typedef Option * option_ptr_t;

    /**
     * Constructor of CmdOption parser.
     *
     * @param program        A string with program name, that will
     *                       be printed out for the '--version' option.
     * @param version        A string with program version, that will
     *                       be printed out for the '--version' option.
     * @param copyright      A string about copyright information.  If not
     *                       null, will be printed out with the '--version'
     *                       option in a paragraph started with
     *                       'Copyright (C)'.
     * @param author         A string (usually including the author name and
     *                       email address). If non null, will be printed out
     *                       with the '--version' option in a paragraph
     *                       started with 'Written by'.
     * @param before_desc    A string describing about this program; it
     *                       will be printed @e before the options.
     * @param after_desc     A string describing about this program; it
     *                       will be printed @e following the options.
     * @param bug_address    A string (usually the maintainer's email address)
     *                       that will be print out at the end of output for
     *                       the '--help' option, embedded in a sentence that
     *                       says `Report bugs to ADDRESS.'. If not present,
     *                       default is the same as the 'author' parameter.
     * @param option_ptr_t   An pointer to an 'Option' object.
     * @param ...            More option_ptr_t objects, ended with 0.
     */
    CmdOptionParser( const char *program,
                     const char *version,
                     const char *copyright,
                     const char *author,
                     const char *before_desc,
                     const char *after_desc,
                     const char *bug_address,
                     option_ptr_t opt1, ...);

    /**
     * Destructor.  Release memory in **pplong_options
     */
    ~CmdOptionParser( );

    /**
     * Parse command line arguments.
     *
     * @param argc
     * @param argv
     *
     * @return
     */
    int parse( int argc, char **argv );

    /**
     * Print to stdout when '--version' option is given.
     */
    void print_version( ) const;

    /**
     * Print to stdout when for the '--help' option.
     */
    void print_help( ) const;

    /**
     * Print option summary.
     */
    void print_summary( ) const;

    /**
     * Print an error message (referring to '--help' option) when wrong
     * options are given.
     */
    void print_errmsg( ) const;

    void print_cmdline( ) const;

    const std::vector<std::string> & unused( ) const
    {
        return unused_;
    }

private :
    const char *program_;
    const char *version_;
    const char *copyright_;
    const char *author_;
    const char *before_description_;
    const char *after_description_;
    const char *bug_address_;

    BoolOption *help_flag_;
    BoolOption *version_flag_;

    //* Save the command line as a string.
    std::string cmdline_;

    //* Required positional command line arguments.  Hence not options.
    std::vector<option_ptr_t> cmdargs_;

    //* Optional Options.
    std::vector<option_ptr_t> optargs_;

    //* A string vector of those unused arguments
    std::vector<std::string> unused_;

    option* plong_options_;
    std::string short_options_;

    void make_options_( );
};

} // namespace MLL

#endif // CMDOPTION_HPP

/** @} */
