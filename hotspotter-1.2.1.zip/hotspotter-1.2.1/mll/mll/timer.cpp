/**
 * @file   timer.cpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/19 06:38:20
 *
 * @brief
 *
 * \$Id: timer.cpp,v 1.1 2003/02/19 10:39:54 nali Exp $
 */

#include "timer.hpp"

namespace MLL
{

const char* datetime_format = "%a, %d %b %Y %H:%M:%S %Z";
const int MAXDATETIMESTRLEN = 256;
const int MAXHOSTNAMELEN = 256;
const int SEC_PER_HOUR = 3600;
const int SEC_PER_MINUTE = 60;

Timer::Timer (std::ostream *os)
    : os_ (os)
{
#ifdef _WINDOWS_
    QueryPerformanceCounter (&StartCounter);
    GetLocalTime (&StartTime);
#else
    time (&start_time_);
    times (&start_);
#endif
    char hostname [MAXHOSTNAMELEN];
    gethostname (hostname, MAXHOSTNAMELEN);
    host_name_ = hostname;
    *os_ << "Timer started ...\n" << std::endl;
}

Timer::~Timer ()
{
    int hr, min, sec;
#ifdef _WINDOWS_
    LARGE_INTEGER EndCounter;
    QueryPerformanceCounter (&EndCounter);
    LARGE_INTEGER TicksPerSecond;
    LARGE_INTEGER time;
    LARGE_INTEGER elapsed_time;
    char datestr [MAXDATESTRINGLEN];
    char timestr [MAXTIMESTRINGLEN];
    /* get the high resolution counter's accuracy */
    QueryPerformanceFrequency (&TicksPerSecond);

    /* convert the tick number into the number of seconds */
    /* since the system was started... */
    time.QuadPart = (EndCounter.QuadPart - StartCounter.QuadPart ) /
        TicksPerSecond.QuadPart;
    elapsed_time.QuadPart = time.QuadPart;

    /* The reminder gives sub-second measurements */
    hr  = (int) time.QuadPart / SEC_PER_HOUR;
    time.QuadPart -= hr * SEC_PER_HOUR;
    min = (int) time.QuadPart / SEC_PER_MINUTE;
    time.QuadPart -= min * SEC_PER_MINUTE;
    sec = (int) time.QuadPart;

    GetDateFormat (LOCALE_SYSTEM_DEFAULT, 0,
                   &StartTime, "ddd',' MMM dd yyyy", datestr,
                   MAXDATESTRINGLEN);
    GetTimeFormat (LOCALE_SYSTEM_DEFAULT, 0,
                   &StartTime, "hh':'mm':'ss tt", timestr,
                   MAXTIMESTRINGLEN);
#else
    time_t end_time;
    struct tms ends;
    time (&end_time);
    times (&ends);
    double elapsed_time = difftime (end_time, start_time_);
    double elapsed = elapsed_time;
    double systime, usrtime;
    /* the elapsed time in hour, min and seconds */
    hr  = (int) elapsed / SEC_PER_HOUR;
    elapsed -= hr * SEC_PER_HOUR;
    min = (int) elapsed / SEC_PER_MINUTE;
    elapsed -= min * SEC_PER_MINUTE;
    sec = (int) elapsed;


    /* system time and user time */
    systime = (double) (ends.tms_stime - start_.tms_stime) / TICKS_PER_SEC;
    usrtime = (double) (ends.tms_utime - start_.tms_utime) / TICKS_PER_SEC;
#endif // _WINDOWS_

    *os_ << "Host             : " << host_name_ << std::endl;
#ifdef _WINDOWS_
    *os_ << "Timer Started at : " << datestr << " " timestr << "\n"
         << "  Elapsed Time   : " << std::setw (12)
         << elapsed_time.QuadPart << std::endl;
#else
    *os_ << "Timer Started at : " << ctime (&start_time_) << "\n"
         << "  system time:  " << std::setw (10) << systime
         << " sec\n"
         << "    user time:  " << std::setw (10) << usrtime
         << " sec\n"
         << " elapsed time:  " << std::setw (10) << elapsed
         << " sec\n";
#endif
    *os_ << "\nThat is " << hr << " hr " << min << " min "
         << sec << " sec\n" << std::endl;
}

std::string
Timer::time_stamp( )
{
    time_t now;
    time (&now);
    char time_str[MAXDATETIMESTRLEN];
    strftime (time_str, MAXDATETIMESTRLEN, datetime_format, localtime (&now));
    return time_str;
}

} // namespace MLL

/* {{{ Log */
/*
 * $Log
 */
/* }}} */
