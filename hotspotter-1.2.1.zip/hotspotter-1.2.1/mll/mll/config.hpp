/**
 * @file   config.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/28 20:10:23
 *
 * @brief
 *
 * $Id: config.hpp,v 1.1 2003/03/07 09:27:43 nali Exp $
 */
#ifndef _CONFIG_HPP
#define _CONFIG_HPP 1

#ifdef WIN32
#define NO_GETOPT_H 1
#endif

#endif /* _CONFIG_HPP */

