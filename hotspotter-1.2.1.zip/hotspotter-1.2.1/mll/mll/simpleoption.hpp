/**
 * @file   simpleoption.hpp
 * @author Michael Na Li
 * @date   Wed Jul  3 00:39:33 2002
 *
 * @brief  A simple command line option parser library for C++.
 *
 * The class is implemented in just one header file.  To use it, include
 * this file in your source code, then:
 *
 * -  Declare your option one by one, the syntax is
 *
 *    @code
 *    OptionType varname (char_name, keyword, value_hint, description,
 *                        default_value);
 *    @endcode
 *
 *    where 'char_name' is used as short option and 'keyword' is corresponding
 *    long option.  'value_hint' gives some hint of what additional argument
 *    is required for this option.  'description' gives the help message.
 *    'default_value' is the default value.
 *
 *    Implemented option types are MLL::BoolOption, MLL::IntOption,
 *    MLL::DoubleOption, MLL::StringOption.
 *
 *    If 'char_name' is '\0' then this option is assumed to be a positional
 *    option and is required.  All non-positional options are assumed to be
 *    optional.
 *
 * -  Declare the parser class MLL::SimpleGetOption:
 *
 *    @code
 *    SimpleGetOption opt_parser (program_name, program_description,
 *                                number_of_args, arg1, arg2, ...);
 *    @endcode
 *
 *    or
 *
 *    @code
 *    SimpleGetOption opt_parser (program_name, program_description,
 *                                arg1, arg2, ..., argn, 0);
 *    @endcode
 *
 * -  Parse the command line:
 *
 *    @code
 *    opt_parser.parse (argc, argv);
 *    @endcode
 *
 *    returns 0 if successful, 1 if not.
 *
 * -  Use the options.  Corresponding type casting operators are definded for
 *    them so in most case you can use them as simple int, bool, double or
 *    std::string type.  In particular, @p operator<< and @p = are defined for
 *    each option type and MLL::StringOption::c_str () member function is
 *    defined.
 *
 *    Whenever in doubt, use explicit cast to get the value of options.
 *
 * @bug
 *
 * -  Only short option is implemented.
 *
 * -  Only minimal error checking.
 *
 * @todo
 *
 * -  Bug fixes.
 *
 * -  Remove dependence upon getopt (?).
 *
 * -  Option list types.
 *
 * -  More versatile option specification (see CmdLine).
 *
 * \$Id: simpleoption.hpp,v 1.7 2003/03/07 09:27:16 nali Exp $
 *
 */
#ifndef SIMPLEOPTION_HPP
#define SIMPLEOPTION_HPP

#include "mll/config.hpp"
#include "mll/strutil.hpp"

#include <map>
#include <string>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <cstdarg>

#ifdef NO_GETOPT_H
#include "mll/getopt.h"
#else
#include <getopt.h>
#endif

namespace MLL
{

/**
 * @class Option
 *
 * @brief The abstract base classes for all types of command line options.
 *
 */
class Option
{
public :

    /**
     * Constructor for class Option.
     *
     * @param optchar          Short option ('-c' style).
     * @param keyword          Long option ('--keyword' style).
     * @param value            If the option takes an argument, the hint at
     *                         possible values of the argument.
     * @param description      A description of the option.
     * @param want_value       Whether this option requires an argument.
     */
    Option( char optchar,
            const std::string & keyword,
            const std::string & value,
            const std::string & description,
            bool want_value)
        : optchar_ (optchar),
          keyword_ (keyword),
          value_ (value),
          description_ (description),
          want_value_ (want_value),
          set_in_cmdline_ (false)
    {}

    virtual ~Option( )
    {}

    char get_optchar( ) const
    {
        return optchar_;
    }

    const std::string & get_keyword( ) const
    {
        return keyword_;
    }

    const std::string & get_value( ) const
    {
        return value_;
    }

    const std::string & get_description( ) const
    {
        return description_;
    }

    bool want_value( ) const
    {
        return want_value_;
    }

    bool set( ) const
    {
        return set_in_cmdline_;
    }

    virtual void setval(const char *) = 0;

    virtual void print_summary( std::ostream &) = 0;

protected :

    void set_true( )
    {
        set_in_cmdline_ = true;
    }

private :
    char optchar_;
    std::string keyword_;
    std::string value_;
    std::string description_;
    bool want_value_;
    bool set_in_cmdline_;
};

class BoolOption : public Option
{
public :
    BoolOption( char optchar,
                const std::string & keyword,
                const std::string & value,
                const std::string & description,
                bool default_value)
        : Option (optchar, keyword, value, description, false),
          val_ (default_value)
    {}

    virtual void setval( const char *)
    {
        val_ = !val_;
        set_true ();
    }

    virtual void print_summary( std::ostream & os)
    {
        os << "  " << std::setw (30) << this->get_description ()
           << " " << (val_ ? "Yes" : "No") << std::endl;
    }

    operator bool( ) const
    {
        return val_;
    }

    BoolOption & operator=( bool val)
    {
        val_ = val;
        return *this;
    }

private :
    bool val_;
};

std::ostream &
operator<<( std::ostream & os, const BoolOption & opt);

class IntOption : public Option
{
public :
    IntOption( char optchar,
               const std::string & keyword,
               const std::string & value,
               const std::string & description,
               int default_value)
        : Option (optchar, keyword, value, description, true),
          val_ (default_value)
    {}

    virtual void setval( const char *optarg)
    {
        val_ = atoi (optarg);
        set_true ();
    }

    virtual void print_summary( std::ostream & os)
    {
        os << "  " << std::setw (30) << this->get_description ()
           << " " << val_ << std::endl;
    }

    operator int( ) const
    {
        return val_;
    }

    IntOption & operator=( int val)
    {
        val_ = val;
        return *this;
    }

private :
    int val_;
};

std::ostream &
operator<<( std::ostream & os, const IntOption & opt);

class DoubleOption : public Option
{
public :
    DoubleOption (char optchar,
                  const std::string & keyword,
                  const std::string & value,
                  const std::string & description,
                  double default_value)
        : Option (optchar, keyword, value, description, true),
          val_ (default_value)
    {}

    virtual void setval( const char *optarg)
    {
        val_ = atof (optarg);
        set_true ();
    }

    virtual void print_summary( std::ostream & os)
    {
        os << "  " << std::setw (30) << this->get_description ()
           << " " << val_ << std::endl;
    }

    operator double( ) const
    {
        return val_;
    }

    DoubleOption & operator=( double val)
    {
        val_ = val;
        return *this;
    }

private :
    double val_;
};

std::ostream &
operator<<( std::ostream & os, const DoubleOption & opt);

class StringOption : public Option
{
public :
    StringOption( char optchar,
                  const std::string & keyword,
                  const std::string & value,
                  const std::string & description,
                  const std::string & default_value)
        : Option (optchar, keyword, value, description, true),
          val_ (default_value)
    {}

    virtual void setval( const char *optarg)
    {
        val_ = optarg;
        set_true ();
    }

    virtual void print_summary( std::ostream & os)
    {
        os << "  " << std::setw (30) << this->get_description ()
           << " " << val_ << std::endl;
    }

    operator std::string( ) const
    {
        return val_;
    }

    StringOption & operator=( const std::string & val)
    {
        val_ = val;
        return *this;
    }

    const char * c_str( ) const
    {
        return val_.c_str ();
    }

private :
    std::string val_;
};

std::ostream &
operator<<( std::ostream & os, const StringOption & opt);


class SimpleGetOption
{
public:

    enum ArgumentType {
        noarg = 0, required, optional
    };

    typedef Option * option_ptr_t;
    typedef std::vector<option_ptr_t>::const_iterator opt_vec_citer_t;
    typedef std::map<char, option_ptr_t>::const_iterator opt_charmap_citer_t;

    SimpleGetOption( const std::string & program_name,
                     const std::string & program_description)
        : name_ (program_name),
          description_ (program_description),
          nreq_ (),
          nargs_ (0),
          optstr_ ("h"),
          positional_ (0)
    {}

    SimpleGetOption( const std::string & program_name,
                     const std::string & program_description,
                     int nargs, ...);

    SimpleGetOption( const std::string & program_name,
                     const std::string & program_description,
                     option_ptr_t opt1, ...);

    ~SimpleGetOption( )
    {}

    void push_back( option_ptr_t opt);

    int parse_short( int argc, char **argv);

    int parse( int argc, char **argv)
    {
        cmdline_ = MLL::concat (argv, argv + argc);
        return parse_short (argc, argv);
    }

    void print_usage( ) const;

    void print_summary( std::ostream & os) const;

private :
    std::string name_;
    std::string description_;
    std::string cmdline_;

    // number of required options
    int nreq_;

    // this should be changed when we don't want to use getopt ()
    int nargs_;
    std::string optstr_;

    std::vector<Option *> positional_;

    std::map<char, Option *> shortform_;
    std::map<std::string, char> long2short_;
    std::map<char, std::string> short2long_;
};

} // namespace MLL

#endif // SIMPLEOPTION_HPP
