/**
 * $Id: timer.hpp,v 1.5 2003/02/19 10:39:54 nali Exp $
 * Adopted from boost/timer class. To avoid some problem with
 * boost/cstdint.hpp and simplify things.
 */
#ifndef TIMER_HPP
#define TIMER_HPP

#include <iostream>
#include <iomanip>
#include <string>

#ifdef _WINDOWS_
#include <Windows.h>
#include <Winsock2.h>
const int MAXDATESTRINGLEN = 32;
const int MAXTIMESTRINGLEN = 64;
#else
#include <unistd.h>
#include <sys/times.h>
const double TICKS_PER_SEC = (sysconf (_SC_CLK_TCK));
#endif

#include <ctime>

namespace MLL
{

/**
 *  A timer object measures elapsed time.
 */
class Timer
{
public:

    Timer (std::ostream * = &std::cout);
    ~Timer ();

    static std::string time_stamp( );

private:
#ifndef _WINDOWS_
    time_t start_time_;
    struct tms start_;
#else
    LARGE_INTEGER StartCounter;
    LARGE_INTEGER EndCounter;
    SYSTEMTIME StartTime;
#endif
    std::string host_name_;
    std::ostream *os_;
};  // timer

}

#endif // TIMER_HPP

// {{{ Log
//
// $Log: timer.hpp,v $
// Revision 1.5  2003/02/19 10:39:54  nali
// Split to a cpp file.
//
// Revision 1.4  2003/02/13 19:58:24  nali
// added time_stamp() static method
//
// Revision 1.3  2003/02/04 10:26:26  nali
// Updated to working condition
//
// Revision 1.2  2002/09/14 00:11:57  nali
// use dbgsrc
//
// Revision 1.1  2002/07/26 22:31:49  nali
// added timer class with the hope to be win32 compatible.
//
//
// }}}
