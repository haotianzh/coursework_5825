/**
 * @file   format.hpp
 * @author Michael Na Li
 * @date   Thu May  9 22:37:25 2002
 *
 * @brief  Convinient classes to format integers and real numbers.
 * The idea follows from "The C++ Programming Language".
 *
 * \$Id: format.hpp,v 1.4 2002/09/11 07:52:08 nali Exp $
 */
#ifndef FORMAT_HPP
#define FORMAT_HPP

#include <iostream>
#include <sstream>

namespace MLL
{

struct bound_format;
struct bound_format_integer;

/**
 * @class format
 *
 * @brief A wrapper for the format flags defined by the standard libary and
 * functions to manipulate them.
 *
 * The format can be applied to both double's and int's. When applied to
 * integers, the precision and showpoint flags have no effect.
 *
 * Usage:
 * @example testformat.cpp
 *
 */
class format
{
private :
    friend std::ostream & operator << (std::ostream &, const bound_format &);

    friend std::ostream & operator << (std::ostream &,
                                       const bound_format_integer &);

    char fch;    // fill char
    int prc;     // precision
    int wdt;     // width

    std::ios::fmtflags fmt;
    std::ios::fmtflags adj;
    std::ios::fmtflags base;

    bool showpos;
    bool showbase;
    bool uppercase;
    bool showpoint;
public :
    explicit format (int p = 6)           // default precesion is 6
        : prc (p)
    {
        fmt = std::ios::fixed;       // fixed format
        adj = std::ios::right;       // right adjust
        base = std::ios::dec;        // decimal
        wdt = 0;                          // as wide as necesary
        fch = ' ';
        showpos = false;
        showbase = false;
        showpoint = false;
        uppercase = false;
    }

    format (const format & f)
        : fch (f.fch), prc (f.prc), wdt (f.wdt),
          fmt (f.fmt),
          adj (f.adj),
          base (f.base),
          showpos (f.showpos),
          showbase (f.showbase),
          uppercase (f.uppercase),
          showpoint (f.showpoint)
    {}

    bound_format operator ()( double d ) const;
    bound_format_integer operator ()( int i ) const;

    // floatfield
    format & scientific( ) { fmt = std::ios::scientific; return *this; }
    format & fixed( ) { fmt = std::ios::fixed; return *this; }

    // adjustfield
    format & left( ) { adj = std::ios::left; return *this; }
    format & right( ) { adj = std::ios::right; return *this; }
    format & internal( ) { adj = std::ios::internal; return *this; }

    // basefield
    format & dec( ) { base = std::ios::dec; return *this; }
    format & oct( ) { base = std::ios::oct; return *this; }

    format & precision( int p ) { prc = p; return *this; }
    format & width( int w ) { wdt = w; return *this; }
    format & fill( char fc ) { fch = fc; return *this; }

    format & set_showpos( bool p = true ) { showpos = p; return *this; }
    format & set_showpoint( bool p = true ) { showpoint = p; return *this; }
    format & set_showbase( bool b = true ) { showbase = b; return *this; }
    format & set_uppercase( bool u = true ) { uppercase = u; return *this; }
};

/**
 * A helper class that binds a format to a real number.
 */
struct bound_format
{
    const format & f;
    double val;
    bound_format( const format & ff, double v )
        : f (ff), val (v)
    {}
};

/**
 * A helper class that binds a format to an integer.
 */
struct bound_format_integer
{
    const format & f;
    int val;
    bound_format_integer( const format & ff, int v )
        : f (ff), val (v)
    {}
};

inline
bound_format
format::operator ()( double d ) const
{
    return bound_format (*this, d);
}

inline
bound_format_integer
format::operator ()( int i ) const
{
    return bound_format_integer (*this, i);
}

std::ostream &
operator <<( std::ostream & os, const bound_format & bf )
{
    std::ostringstream s;
    s.precision (bf.f.prc);
    s.width (bf.f.wdt);
    s.fill (bf.f.fch);
    s.setf (bf.f.fmt);
    s.setf (bf.f.adj);
    s.setf (bf.f.base);

    if (bf.f.showpos) {
        s.setf (std::ios::showpos);
    }
    if (bf.f.showpoint) {
        s.setf (std::ios::showpoint);
    }
    if (bf.f.showbase) {
        s.setf (std::ios::showbase);
    }
    if (bf.f.uppercase) {
        s.setf (std::ios::uppercase);
    }
    s << bf.val;                                     // composite string in s
    return os << s.str ();                           // output s to os
}

std::ostream &
operator <<( std::ostream & os, const bound_format_integer & bf )
{
    std::ostringstream s;
    s.width (bf.f.wdt);
    s.fill (bf.f.fch);
    s.setf (bf.f.adj);
    s.setf (bf.f.base);

    if (bf.f.showpos) {
        s.setf (std::ios::showpos);
    }
    if (bf.f.showbase) {
        s.setf (std::ios::showbase);
    }
    if (bf.f.uppercase) {
        s.setf (std::ios::uppercase);
    }
    s << bf.val;                                     // composite string in s
    return os << s.str ();                           // output s to os
}

}  // namespace MLL

#endif // FORMAT_HPP
