/**
 * @file   checkedio.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/11 18:05:47
 *
 * @brief
 *
 * $Id: checkedio.hpp,v 1.2 2003/03/11 08:26:17 nali Exp $
 */
#ifndef _CHECKEDIO_HPP
#define _CHECKEDIO_HPP 1

#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>

namespace MLL
{



inline
void
assure ( std::ifstream & input_stream,
         const std::string & file_name )
{
    std::string errmsg ("Cannot open input file: ");
    if (!input_stream.good ()) {
        throw std::runtime_error (errmsg + file_name + "\n");
    }
}

inline
void
assure ( std::ofstream & output_stream,
         const std::string & file_name )
{
    std::string errmsg ("Cannot open output file: ");
    if (!output_stream.good ()) {
        throw std::runtime_error (errmsg + file_name + "\n");
    }
}

} // namespace MLL

#endif /* _CHECKEDIO_HPP */

