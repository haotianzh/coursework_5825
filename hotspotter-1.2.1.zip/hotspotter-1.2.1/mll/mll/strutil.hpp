/*
 * Some functions to handle strings, from varied sources.
 *
 * $Id: strutil.hpp,v 1.7 2003/02/13 19:59:47 nali Exp $
 */

#ifndef STRING_UTIL_H
#define STRING_UTIL_H

#include "dbg/dbg.hpp"
#include <string>
#include <string.h>
#include <sstream>
#include <algorithm>
#include <functional>
#include <cstdlib>
#include <vector>

namespace MLL
{

extern dbg::dbg_source strutil_dbg;

template <typename T>
inline
std::string
tostr (const T & t)
{
    std::ostringstream res;
    res << t;
    return res.str ();
}

template <typename T>
inline
T
fromstr (const std::string & s)
{
    std::istringstream ss (s);
    T t;
    ss >>  t;
    return t;
}

template <>
inline
double
fromstr <double> (const std::string & s)
{
    return std::atof (s.c_str ());
}

template <>
inline
int
fromstr <int> (const std::string & s)
{
    return std::atoi (s.c_str ());
}

template <>
inline
long
fromstr <long> (const std::string & s)
{
    return std::atol (s.c_str ());
}

template <typename T>
inline
T
fromstr (const char * s)
{
    std::istringstream ss (s);
    T t;
    ss >>  t;
    return t;
}

template <>
inline
double
fromstr <double> (const char * s)
{
    return std::atof (s);
}

template <>
inline
int
fromstr <int> (const char *s)
{
    return std::atoi (s);
}

template <>
inline
long
fromstr <long> (const char *s)
{
    return std::atol (s);
}

template <typename ForwardIterator>
inline
std::string
concat( ForwardIterator begin, ForwardIterator end,
        const std::string & sep = " ")
{
    std::ostringstream res;
    for (; begin != end; ++begin) {
        res << *begin << sep;
    }
    return res.str ();
}

inline
bool
space (char c)
{
    return isspace(c);
}

inline
bool
not_space (char c)
{
    return !isspace(c);
}

inline
std::vector<std::string>
split (const std::string & str)
{
    typedef std::string::const_iterator iter_type;
    std::vector<std::string> ret;
    iter_type i = str.begin ();
    while (i != str.end ()) {

        // ignore leading blanks
        i = std::find_if (i, str.end(), not_space);

        // find end of next word
        iter_type j = std::find_if (i, str.end(), space);

        // copy the characters in [i,j)
        if (i != str.end())
            ret.push_back (std::string (i, j));
        i = j;
    }
    return ret;
}

inline
std::string
trim (const std::string & s)
{
    if (s.size () == 0) {
        return s;
    }
    int b = s.find_first_not_of (" \t");
    int e = s.find_last_not_of (" \t");
    if (b == -1) {                          // no non-space
        return "";
    } else {
        return std::string (s, b, e - b + 1);
    }
}

/*  The next two functions are from
 *  Chapter 7: The C++ Standard Library
 *  Compaq C++ Using Compaq C++ for Tru64 UNIX
 */
template <class charT, class traits, class Allocator>
inline
std::basic_string<charT, traits, Allocator>
upper (const std::basic_string<charT,traits, Allocator>& str) {
    std::basic_string<charT, traits, Allocator> newstr(str);
    for (size_t index = 0; index < str.length(); index++) {
        if (islower(str[index])) {
            newstr[index] = toupper(str[index]);
        }
    }
    return newstr;
}

inline
std::string
upper (const char* str)
{
    std::string newstr (str);
    for (size_t index = 0; index < newstr.length(); index++) {
        if (islower(newstr[index])) {
            newstr[index] = toupper(newstr[index]);
        }
    }
    return newstr;
}

template <class charT, class traits, class Allocator>
inline
std::basic_string<charT, traits, Allocator>
lower (const std::basic_string<charT,traits, Allocator>& str) {
    std::basic_string<charT, traits, Allocator> newstr(str);
    for (size_t index = 0; index < str.length(); index++) {
        if (isupper(str[index])) {
            newstr[index] = tolower(str[index]);
        }
    }
    return newstr;
}

inline
std::string
lower (const char* str)
{
    std::string newstr (str);
    for (size_t index = 0; index < newstr.length(); index++) {
        if (isupper(newstr[index])) {
            newstr[index] = tolower(newstr[index]);
        }
    }
    return newstr;
}

// Simple case-insensitive string comparisions
struct char_less_case
{
    bool operator () (char c1, char c2)
    {
        return tolower (static_cast<unsigned char> (c1))
            <  tolower (static_cast<unsigned char> (c2));
    }
};

struct char_cmp_case
{
    typedef char first_argument_type;
    typedef char second_argument_type;

    bool operator () (const char & c1, const char & c2) const
    {
        int lc1 = tolower (static_cast<unsigned char> (c1));
        int lc2 = tolower (static_cast<unsigned char> (c2));
        return lc1 == lc2;
    }
};

class string_cmp_case
{
public :
    int operator () (const std::string & s1, const std::string & s2)
    {
        if (s1.size () < s2.size ()) {
            return string_cmp_case_impl (s1, s2);
        } else {
            return - string_cmp_case_impl (s2, s1);
        }
    }
private :
    bool string_cmp_case_impl (const std::string & s1, const std::string & s2)
    {
        typedef std::pair<std::string::const_iterator,
                          std::string::const_iterator> PSCI;
        char_cmp_case charcmpi;
        PSCI p = std::mismatch (s1.begin (), s1.end (), s2.begin (),
                                std::not2 (charcmpi));
        if (p.first == s1.end ()) {
            if (p.second == s2.end ()) {
                return true;
            } else {
                return false;
            }
        }
        return charcmpi (*p.first, *p.second);
    }
};

struct string_less_case
{
    bool operator () (const std::string & s1, const std::string & s2)
    {
        return std::lexicographical_compare (s1.begin (), s1.end (),
                                             s2.begin (), s2.end (),
                                             char_less_case ());
    }
};

inline
int
istringcmp (const std::string & s1, const std::string & s2)
{
    // the function strcasecmp/strcmpi/stricmp is defined in <cstring>
    return strcasecmp (s1.c_str (), s2.c_str ());
}

std::string
line_break( const std::string & str, std::size_t line_width = 78 );

} // namespace MLL

#endif //  STRING_UTIL_H
