/**
 * @file   simpleoption.cpp
 * @author Michael Na Li
 * @date   Sun Jul  7 20:29:18 2002
 *
 * @brief  Implementation of simpleoption.hpp
 *
 * \$Id: simpleoption.cpp,v 1.2 2002/07/16 21:57:51 nali Exp $
 */

#include "mll/simpleoption.hpp"

std::ostream &
MLL::operator<<( std::ostream & os, const BoolOption & opt)
{
    return os << (bool (opt) ? "yes" : "no");
}

std::ostream &
MLL::operator<<( std::ostream & os, const IntOption & opt)
{
    return os << opt.get_description () << "\t\t"
              << int (opt) << std::endl;
}


std::ostream &
MLL::operator<<( std::ostream & os, const DoubleOption & opt)
{
    return os << double (opt);
}

std::ostream &
MLL::operator<<( std::ostream & os, const StringOption & opt)
{
    return os << std::string (opt);
}


MLL::SimpleGetOption::SimpleGetOption( const std::string & program_name,
                                       const std::string & program_description,
                                       int nargs, ...)
    : name_ (program_name),
      description_ (program_description),
      nreq_ (0),
      nargs_ (0),
      optstr_ ("h"),
      positional_ (0)
{
    va_list argptr;
    va_start (argptr, nargs);

    option_ptr_t opt;
    for (; nargs; --nargs) {
        opt = va_arg (argptr, option_ptr_t);
        this->push_back (opt);
    }
    va_end (argptr);
}

MLL::SimpleGetOption::SimpleGetOption( const std::string & program_name,
                                       const std::string & program_description,
                                       option_ptr_t opt1, ...)
    : name_ (program_name),
      description_ (program_description),
      nreq_ (0),
      nargs_ (0),
      optstr_ ("h"),
      positional_ (0)
{
    va_list argptr;
    va_start (argptr, opt1);
    for (option_ptr_t opt = opt1; opt;
         opt = va_arg (argptr, option_ptr_t)) {
        this->push_back (opt);
    }
    va_end (argptr);
}

void
MLL::SimpleGetOption::push_back( option_ptr_t opt)
{
    char optchar = opt->get_optchar ();
    if (optchar == '\0') {
        // Positional option
        ++nreq_;
        positional_.push_back (opt);
    } else {
        // Name option
        ++nargs_;
        optstr_ += optchar;
        if (opt->want_value ()) {
            optstr_ += ':';
        }
        shortform_[optchar] = opt;
        short2long_[optchar] = opt->get_keyword ();
        long2short_[opt->get_keyword ()] = optchar;
    }
}

int
MLL::SimpleGetOption::parse_short( int argc, char **argv)
{
    // Global variables
    ::opterr = 0;
    ::optarg = 0;

    if (argc < nreq_) {
        // not enough arguments given
        print_usage ();
        return 1;
    }

#ifdef DEBUG_SIMPLEOPTION
    std::cout << "Option string = " << optstr_ << std::endl;
#endif // DEBUG_SIMPLEOPTION

    int c;
    while ((c = getopt (argc, argv, optstr_.c_str ())) != -1) {
        if (c == 'h') {
            print_usage ();
            return 1;
        } else if (shortform_.find (char (c)) == shortform_.end ()) {
            // invalid argument
            if (isprint (optopt)) {
                std::cerr << "Unknown option '-" << char (::optopt)
                          << "'." << std::endl;
            } else {
                std::cerr << "Unknown option character '\\x" << ::optopt
                          << "'." << std::endl;
            }
            return 1;
        } else {
            shortform_[char (c)]->setval (::optarg);
        }
    }

    // deal with positional options
    if (argc - ::optind < int (positional_.size ())) {
        std::cerr << "Expecting " << positional_.size ()
                  << "positional options.\n"
                  << "Got only " << argc - optind << std::endl;
        print_usage ();
        return 1;
    } else {
        for (std::size_t i = 0; i < positional_.size (); ++i, ++::optind) {
            positional_[i]->setval (argv[::optind]);
        }
    }

    if (::optind < argc) {
        std::cerr << "Additional arguments left unused." << std::endl;
    }

    return 0;
}

void
MLL::SimpleGetOption::print_usage( ) const
{
    std::cout << "\nUsage: " << name_ << " [options] ";
    for (opt_vec_citer_t i = positional_.begin ();
         i < positional_.end (); ++i) {
        std::cout << " " << (*i)->get_keyword ();
    }
    std::cout << "\n";
    std::cout << description_ << "\n" << std::endl;
    std::cout << "Options : \n";
    // switches
    for (opt_charmap_citer_t i = shortform_.begin ();
         i != shortform_.end (); ++i) {
        std::cout << "  -" << i->first << ","
                  << " --" << i->second->get_keyword () << "\t\t"
                  << i->second->get_description ()
                  << std::endl;
    }
    std::cout << "  -h, --help\t\tPrint this message\n" << std::endl;
    // positional
    for (opt_vec_citer_t i = positional_.begin ();
         i != positional_.end (); ++i) {
        std::cout << (*i)->get_keyword () << "\t\t"
                  << (*i)->get_description ()
                  << std::endl;
    }
}

void
MLL::SimpleGetOption::print_summary( std::ostream & os) const
{
    os << "Command Line: " << cmdline_ << std::endl;
    os << "\nOption Summary:\n" << std::endl;
    os.setf (std::ios::left);
//     os.setf (std::ios::boolalpha);
    // switches
    for (opt_charmap_citer_t i = shortform_.begin ();
         i != shortform_.end (); ++i) {
        i->second->print_summary (os);
    }
    // positional
    for (opt_vec_citer_t i = positional_.begin ();
         i != positional_.end (); ++i) {
        (*i)->print_summary (os);
    }
    os << std::endl;
//     os.unsetf (std::ios::boolalpha);
    os.unsetf (std::ios::left);
}

// {{{ Log
/*
 * $Log: simpleoption.cpp,v $
 * Revision 1.2  2002/07/16 21:57:51  nali
 *
 * fixed boolalpha
 *
 * Revision 1.1  2002/07/08 04:23:34  nali
 * New cpp files.
 *
 */
// }}}
