/**
 * @file   cmdoption.cpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/01/11 18:53:56
 *
 * @brief
 *
 * \$Id: cmdoption.cpp,v 1.4 2003/02/21 20:04:08 nali Exp $
 */

#include "mll/cmdoption.hpp"
#include "mll/timer.hpp"

#include <iostream>

#include <cstring>
#include <errno.h>

namespace MLL
{

const int HELP_KEY = 9999;
const int VER_KEY = 8888;

dbg::dbg_source CmdOptionParser::dbgsrc = "CmdOptionParser";

CmdOptionParser::CmdOptionParser( const char *program,
                                  const char *version,
                                  const char *copyright,
                                  const char *author,
                                  const char *before,
                                  const char *after,
                                  const char *bug_address,
                                  option_ptr_t opt1, ...)
    : program_ (program),
      version_ (version),
      copyright_ (copyright),
      author_ (author),
      before_description_ (before),
      after_description_(after),
      bug_address_ (bug_address ? bug_address : author),
      help_flag_    (new BoolOption (HELP_KEY, "help", 0,
                                     "print this help, then exit",
                                     false)),
      version_flag_ (new BoolOption (VER_KEY, "version", 0,
                                     "print version number, then exit",
                                     false)),
      plong_options_ (0),
      short_options_ ("")
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    dbg::out (dbg::tracing, dbgsrc) << "The are " << (opt1 ? "no" : "some")
                                    << " options" << std::endl;
    va_list argptr;
    va_start (argptr, opt1);
    for (option_ptr_t opt = opt1; opt; opt = va_arg (argptr, option_ptr_t)) {
        if (opt->is_option ()) {
            optargs_.push_back (opt);
        } else {
            // This is a required positional arguments.
            cmdargs_.push_back (opt);
        }
    }
    va_end (argptr);

    optargs_.push_back (help_flag_);
    optargs_.push_back (version_flag_);

    make_options_ ();

    dbg::out (dbg::tracing, dbgsrc) << "Short option string is "
                                    << short_options_ << std::endl;
    dbg::out (dbg::tracing, dbgsrc) << "There are " << optargs_.size ()
                                    << " options and " << cmdargs_.size ()
                                    << " obligatory command line arguments"
                                    << std::endl;
#ifdef DBG_ENABLED
    for (std::size_t i = 0; i < optargs_.size (); ++i) {
        dbg::out (dbg::tracing, dbgsrc) << "Option name: "
                                        << plong_options_[i].name
                                        << "\tval "
                                        << plong_options_[i].val
                                        << std::endl;
    }
#endif

}

CmdOptionParser::~CmdOptionParser( )
{
    delete plong_options_;
    delete help_flag_;
    delete version_flag_;
}

void
CmdOptionParser::print_errmsg( ) const
{
    std::cout << program_ << ": missing or wrong arguments.\n"
              << "Try `" << program_
              << " --help' for more information."
              << std::endl;
}

void
CmdOptionParser::print_version( ) const
{
    std::cout << program_ << " " << version_;
    if (copyright_) {
        std::cout << "\n\nCopyright (C) " << copyright_;
    }
    if (author_) {
        std::cout << "\n\nWritten by " << author_;
    }
    std::cout << std::endl;
}

void
CmdOptionParser::print_help( ) const
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);

    if (before_description_) {
        std::cout << MLL::line_break (before_description_) << std::endl;
    }

    std::cout << boost::format ("\nUsage: %s [OPTION]...")
        % program_;
    for (std::vector<option_ptr_t>::const_iterator i = cmdargs_.begin ();
         i != cmdargs_.end (); ++i) {
        std::cout << boost::format (" %s")
            % MLL::upper ((*i)->get_value ());
    }
    std::cout << "\n" << std::endl;

    for (std::vector<option_ptr_t>::const_iterator i = optargs_.begin ();
         i != optargs_.end (); ++i) {
        (*i)->print_doc ();
    }

    std::cout << "\n";

    if (after_description_) {
        std::cout << after_description_ << std::endl;
    }

    if (bug_address_) {
        std::cout << "Report bugs to <" << bug_address_
                  << "> " << std::endl;
    }
}

void
CmdOptionParser::print_summary( ) const
{
    std::cout << "\nCommand: " << cmdline_ << "\n" << std::endl;
    std::cout << "Time Stamp: "
              << MLL::Timer::time_stamp () << "\n--" << std::endl;
    for (std::vector<option_ptr_t>::const_iterator i = optargs_.begin ();
         i != optargs_.end () - 2; ++i) {
        (*i)->print_summary ();
    }
    for (std::vector<option_ptr_t>::const_iterator i = cmdargs_.begin ();
         i != cmdargs_.end (); ++i) {
        (*i)->print_summary ();
    }
    std::cout << std::endl;
    std::cout << "--\n";
    print_version ();
}

void
CmdOptionParser::make_options_( )
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);
    plong_options_ = new option [optargs_.size () + 1];

    std::size_t i = 0;

    for (std::vector<option_ptr_t>::iterator iter = optargs_.begin ();
         iter != optargs_.end (); ++iter, ++i) {
        dbg::out (dbg::tracing, dbgsrc) << "name = " << (*iter)->get_name ()
                                        << "\tkey = " << (*iter)->get_key ()
                                        << std::endl;
        (*iter)->copy_to_option (plong_options_[i]);
        // short option?
        if ((*iter)->has_short ()) {
            short_options_ += (char) (*iter)->get_key ();
            if ((*iter)->has_arg ()) {
                short_options_ += ':';
            }
        }
    }

    // The last element
    plong_options_[i].name    = 0;
    plong_options_[i].has_arg = 0;
    plong_options_[i].flag    = 0;
    plong_options_[i].val     = 0;
}


int
CmdOptionParser::parse( int argc, char **argv )
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);

    cmdline_ = MLL::concat (argv, argv + argc);
    dbg::out (dbg::tracing, dbgsrc) << "Command Line is " << cmdline_
                                    << std::endl;

    int c;
    // Global variables
    ::opterr = 0;
    ::optarg = 0;

    std::vector<option_ptr_t>::iterator opt_iter;

    while (1) {
        /* getopt_long stores the option index here. */
        int option_index = 0;
        c = getopt_long (argc, argv, short_options_.c_str (),
                         plong_options_, &option_index);

        dbg::out (dbg::tracing, dbgsrc) << "Got an "
                                        << (isascii (c) ? char (c) : c)
                                        << std::endl;

        /* end of the options */
        if (c == -1) {
            break;
        }
        for (opt_iter = optargs_.begin (); opt_iter != optargs_.end ();
             ++opt_iter) {
            if ((*opt_iter)->get_key () == c) {
                break;
            }
        }

        if (opt_iter == optargs_.end ()) {
            // invalid argument, getopt_long already printed an error
            // message.
            print_errmsg ();
            exit (1);
        } else {
            dbg::out (dbg::tracing, dbgsrc) << "option name is "
                                            << (*opt_iter)->get_name ()
                                            << std::endl;
            (*opt_iter)->setval (::optarg);
        }
    }

    if (*help_flag_) {
        print_help ();
        exit (0);
    }
    if (*version_flag_) {
        print_version ();
        exit (0);
    }

    // deal with positional arguments
    if (argc - ::optind < int (cmdargs_.size ())) {
        print_errmsg ();
        print_help ();
        exit (1);
    } else {
        for (std::size_t i = 0; i < cmdargs_.size (); ++i, ++::optind) {
            cmdargs_[i]->setval (argv[::optind]);
        }
    }
    // if there are any arguments left, save them in a string vector,
    while (::optind < argc) {
        unused_.push_back (argv[::optind++]);
    }

    return unused_.size ();
}

} // namespace MLL

/* {{{ Log */
/*
 * $Log
 */
/* }}} */
