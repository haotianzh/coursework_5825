/**
 * @file   strutil.cpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/12 05:39:57
 *
 * @brief
 *
 * \$Id: strutil.cpp,v 1.1 2003/02/13 19:59:48 nali Exp $
 */

#include "mll/strutil.hpp"
#include <boost/tokenizer.hpp>

namespace MLL
{

dbg::dbg_source strutil_dbg = "MLL::strutil";

std::string
line_break( const std::string & str, std::size_t line_width)
{
    dbg::trace dtrace (strutil_dbg, DBG_HERE);
    typedef boost::char_separator<char> char_separator_t;
    typedef boost::tokenizer<char_separator_t> tokenizer_t;
    char_separator_t sep (" \n\t");
    tokenizer_t tok (str, sep);

    std::string outstr;
    std::string tempstr;
    for (tokenizer_t::iterator i = tok.begin (); i != tok.end (); ++i) {
        if (tempstr.size () + i->size() > line_width) {
            outstr += tempstr + "\n";
            tempstr.clear ();
        }
        tempstr += *i;
        tempstr += " ";
    }
    outstr += tempstr;
    return outstr;
}

} // namespace MLL


/* {{{ Log */
/*
 * $Log
 */
/* }}} */
