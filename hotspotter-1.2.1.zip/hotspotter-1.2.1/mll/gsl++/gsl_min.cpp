/**
 * @file   gsl_min.cpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/22 10:01:30
 *
 * @brief
 *
 * \$Id: gsl_min.cpp,v 1.1 2003/02/23 21:57:59 nali Exp $
 */

#include "gsl++/gsl_min.hpp"

namespace GSL
{

dbg::dbg_source OneDMinimizer::dbgsrc = "OneDMinimizer";


double
OneDMinimizer::real_minim_( Function & F,
                            double xx, double ax, double bx,
                            bool trace, double epsrel, double epsabs,
                            int maxiter )
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);

    static const double GOLD = 0.61803399;

    // make sure the (x, a, b) bracket a minimum
    double fa = F (ax);
    double fb = F (bx);
    double fx = F (xx);
    boost::format tracefmt ("%5d [%12f, %12f] %12g %12g %12g");
    if (trace) {
        std::cout << " Minimization with " << this->name ()
                  << " method.\n";
        std::cout << boost::format ("%5s [%12s, %12s] %12s %12s %12s")
            % "iter" %"lower" % "upper" % "min" % "f (min)" % "err(est)"
                  << std::endl;
        std::cout << tracefmt % 0 % ax % bx % xx % fx % fb << std::endl;
    }
    // we want that a < x < b, and fa > fx < fb
    if (fb > fa) {
        // make fa > fb
        std::swap (ax, bx);
        std::swap (fa, fb);
    }
    int status = 0;
    while (fx > fb) {
        if (trace) {
            std::cout << tracefmt % 0 % ax % bx % xx % fx % fb << std::endl;
        }
        status = gsl_min_test_interval (ax, bx, epsrel, epsabs);
        if (status == GSL_SUCCESS) {
            // ax and bx are already too close
            std::cerr << "Error: endpoints do not enclose a minimum"
                      << std::endl;
            return fa < fb ? ax : bx;
        }
        // move a -> x
        ax = xx;
        fa = fx;
        // move x -> closer to b
        xx += GOLD * (bx - xx);
        fx = F (xx);
    }

    // now x is our guess of the minimum, make sure ax < bx
    if (ax > bx) {
        std::swap (ax, bx);
        std::swap (fa, fb);
    }
    status = gsl_min_fminimizer_set_with_values (minimizer_, F.ptrF,
                                                 xx, fx,
                                                 ax, fa,
                                                 bx, fb);
    if (status == GSL_EINVAL) {
        std::cerr << "Error: endpoints do not enclose a minimum"
                  << std::endl;
        return fa < fb ? ax : bx;
    } else if (status != GSL_SUCCESS) {
        std::cerr << "Somethine else is wrong, error code = "
                  << status << std::endl;
        abort ();
    }

    double m (0.0);
    double a (0.0);
    double b (0.0);
    for (int iter = 1; iter <= maxiter; ++iter) {
        status = gsl_min_fminimizer_iterate (minimizer_);
        m = gsl_min_fminimizer_minimum (minimizer_);
        a = gsl_min_fminimizer_x_lower (minimizer_);
        b = gsl_min_fminimizer_x_upper (minimizer_);
        status = gsl_min_test_interval (a, b, epsrel, epsabs);
        if (trace) {
            std::cout << tracefmt % iter % a % b % m % F.eval_f (m) % (b - a)
                      << std::endl;
        }
        if (status == GSL_SUCCESS) {
            if (trace) {
                std::cout << " Converged!" << std::endl;
            }
            break;
        }
    }
    if (status != GSL_SUCCESS) {
        std::cout << "Maximum number of function evaluation exceeded!"
                  << std::endl;
        m = GSL_NAN;
    }
    return m;
}

} // namespace GSL


/* {{{ Log */
/*
 * $Log
 */
/* }}} */
