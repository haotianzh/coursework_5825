/**
 * @file gsl_function.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   Sun, 24 Mar 2002 16:49:02 -0800
 *
 * @brief  A wrapper class to gsl_function
 *
 *
 * \$Id: gsl_function.hpp,v 1.8 2003/02/21 20:05:00 nali Exp $
 */

#ifndef GSL_FUNCTION_HPP
#define GSL_FUNCTION_HPP

#include <gsl/gsl_math.h>
#include "dbg/dbg.hpp"

namespace GSL
{

/**
 * @brief A templated version of the function required by gsl_function.
 *
 * @param x      The parameter (double) at which to evaluate the function.
 * @param pvf    A void pointer to a function object that takes one argument.
 *
 * @return The function value at x.
 */
template <typename functor_type>
double function_gsl (double x, void *pvf)
{
    functor_type *pfunc = static_cast<functor_type *> (pvf);
    return (*pfunc)(x);
}

class Function
{
public :

    // Public Member
    gsl_function *ptrF;

    // Constructor & destructor
    template <typename functor_type>
    Function (functor_type & func)
    {
        ptrF = new gsl_function;
        ptrF->function = &function_gsl<functor_type>;
        ptrF->params   = static_cast<void *> (&func);
    }

    Function (double (*pfunc) (double, void*), void *params)
    {
        ptrF = new gsl_function;
        ptrF->function = pfunc;
        ptrF->params = params;
    }

    explicit
    Function (const Function &F2)
    {
        ptrF = new gsl_function;
        ptrF->function = F2.ptrF->function;
        ptrF->params   = F2.ptrF->params;
    }

    ~Function ()
    {
        delete ptrF;
    }

    double operator () (double x)
    {
        return this->eval_f (x);
    }

    double eval_f (double x)
    {
        // evaluate the function through ptrF, in C style
        return (*((ptrF)->function)) (x, (ptrF)->params);
    }
};

}  // namespace GSL

#endif // GSL_FUNCTION_HPP
