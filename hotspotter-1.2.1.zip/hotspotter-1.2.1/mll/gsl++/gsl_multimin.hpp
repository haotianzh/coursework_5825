/**
 * @file   gsl_multimin.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/21 06:25:49
 *
 * @brief
 *
 * $Id: gsl_multimin.hpp,v 1.4 2003/03/07 09:24:05 nali Exp $
 */
#ifndef _GSL_MULTIMIN_HPP
#define _GSL_MULTIMIN_HPP 1

#include "dbg/dbg.hpp"

#include <boost/format.hpp>

#include <gsl/gsl_multimin.h>
#include <gsl/gsl_errno.h>

namespace GSL
{

template <typename function_t>
double function_gsl_f (const gsl_vector * x, void *pvf)
{
    function_t *pfunc = static_cast<function_t *> (pvf);
    return (*pfunc)(x);
}

template <typename function_t>
void function_gsl_df (const gsl_vector * x, void *pvf, gsl_vector * g)
{
    function_t *pfunc = static_cast<function_t *> (pvf);
    (*pfunc)(x, g);
}

template <typename function_t>
void function_gsl_fdf (const gsl_vector * x, void *pvf,
                      double *f, gsl_vector * g)
{
    function_t *pfunc = static_cast<function_t *> (pvf);
    (*pfunc)(x, f, g);
}

class Multimin_Function_FDF
{
public :
    gsl_multimin_function_fdf *ptrF;

    template <typename function_t>
    Multimin_Function_FDF( function_t & func )
    {
        ptrF = new gsl_multimin_function_fdf;
        ptrF->f = &function_gsl_f<function_t>;
        ptrF->df = &function_gsl_df<function_t>;
        ptrF->fdf = &function_gsl_fdf<function_t>;
        ptrF->n = func.size ();
        ptrF->params = static_cast<void *> (&func);
    }

    explicit
    Multimin_Function_FDF( Multimin_Function_FDF & f2 )
    {
        ptrF = new gsl_multimin_function_fdf;
        ptrF->f = f2.ptrF->f;
        ptrF->df = f2.ptrF->df;
        ptrF->fdf = f2.ptrF->fdf;
        ptrF->n = f2.ptrF->n;
        ptrF->params = f2.ptrF->params;
    }

    ~Multimin_Function_FDF ()
    {
        delete ptrF;
    }

    double operator()( const gsl_vector * x )
    {
        return (*(ptrF->f)) (x, ptrF->params);
    }

    void operator()( const gsl_vector *x, gsl_vector *g )
    {
        (*(ptrF->df)) (x, ptrF->params, g);
    }

    void operator()( const gsl_vector *x, double *f, gsl_vector *g )
    {
        (*(ptrF->fdf)) (x, ptrF->params, f, g);
    }

    std::size_t size( ) const
    {
        return ptrF->n;
    }
};

class MultiMinimizerFDF
{
public :
    static dbg::dbg_source dbgsrc;

    enum multi_minimizer_fdf_type { conjugate_fr,
                                    conjugate_pr,
                                    vector_bfgs,
                                    steepest_descent };

    typedef const gsl_multimin_fdfminimizer_type * method_t;

    template <typename functor_t>
    explicit
    MultiMinimizerFDF( functor_t & func,
                       multi_minimizer_fdf_type mt = vector_bfgs )
        : err_handler_ (gsl_set_error_handler_off ()),
          mmF_ (func)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        switch (mt) {
        case conjugate_fr:
            // Fletcher-Reeves conjugate gradient algorithm
            method_ = gsl_multimin_fdfminimizer_conjugate_fr;
            break;
        case conjugate_pr:
            // Polak-Ribiere conjugate gradient algorithm
            method_ = gsl_multimin_fdfminimizer_conjugate_pr;
            break;
        case vector_bfgs:
            // vector Broyden-Fletcher-Goldfarb-Shanno (BFGS) conjugate
            // gradient algorithm
            method_ = gsl_multimin_fdfminimizer_vector_bfgs;
            break;
        case steepest_descent:
            // steepest descent algorithm
            method_ = gsl_multimin_fdfminimizer_steepest_descent;
        default:
            dbg::sentinel (dbg::error, dbgsrc, DBG_HERE);
            exit (GSL_EINVAL);
        }
        minimizer_ = gsl_multimin_fdfminimizer_alloc (method_, size ());
        if (!minimizer_) {
            std::cerr << "Unable to allocate memory for minimizer."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    MultiMinimizerFDF( MultiMinimizerFDF & m )
        : err_handler_ (gsl_set_error_handler_off ()),
          method_ (m.method_),
          mmF_ (m.mmF_)
    {
        minimizer_ = gsl_multimin_fdfminimizer_alloc (method_, size ());
        if (!minimizer_) {
            std::cerr << "Unable to allocate memory for minimizer."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    ~MultiMinimizerFDF ()
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        gsl_multimin_fdfminimizer_free (minimizer_);
        gsl_set_error_handler (err_handler_);
    }

    const char *name () const
    {
        return gsl_multimin_fdfminimizer_name (minimizer_);
    }

    method_t method () const
    {
        return method_;
    }

    int minim( const gsl_vector * x,
               double step_size,
               int maxiter = 10000,
               double tol_line = 1.0e-4,
               double tol = 1.0e-3,
               bool trace = true )
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        int status = gsl_multimin_fdfminimizer_set (minimizer_, mmF_.ptrF,
                                                    x, step_size, tol_line);
        status = real_minim_ (trace, tol, maxiter);
        return status;
    }

    int restart( int maxiter = 10000,
                 double tol = 1.0e-3,
                 bool trace = true )
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        int status = gsl_multimin_fdfminimizer_restart (minimizer_);
        status = real_minim_ (trace, tol, maxiter);
        return status;
    }

    const gsl_vector *get_x(  ) const
    {
        return gsl_multimin_fdfminimizer_x (minimizer_);
    }

    const gsl_vector *get_dx(  ) const
    {
        return gsl_multimin_fdfminimizer_dx (minimizer_);
    }

    const gsl_vector *get_gradient( ) const
    {
        return gsl_multimin_fdfminimizer_gradient (minimizer_);
    }

    double get_x( std::size_t i ) const
    {
        return gsl_vector_get (gsl_multimin_fdfminimizer_x (minimizer_),
                               i);
    }

    double get_dx( std::size_t i ) const
    {
        return gsl_vector_get (gsl_multimin_fdfminimizer_dx (minimizer_),
                               i);
    }

    double get_gradient( std::size_t i ) const
    {
        return gsl_vector_get (gsl_multimin_fdfminimizer_gradient (minimizer_),
                               i);
    }

    double get_minimum( ) const
    {
        return gsl_multimin_fdfminimizer_minimum (minimizer_);
    }

    std::size_t size( ) const
    {
        return mmF_.size ();
    }

private :
    gsl_multimin_fdfminimizer * minimizer_;
    gsl_error_handler_t * err_handler_;
    method_t method_;
    Multimin_Function_FDF mmF_;

    int real_minim_( bool trace, double tol, int maxiter )
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        int iter = 0;
        int status = GSL_CONTINUE;
        for (; iter < maxiter && status == GSL_CONTINUE; ++iter) {
            status = gsl_multimin_fdfminimizer_iterate (minimizer_);
            if (status) {
                break;
            }
            status = gsl_multimin_test_gradient (get_gradient (), tol);
            if (status == GSL_SUCCESS && trace) {
                std::cout << "Minimum found at: " << std::endl;
            }
            if (trace && (iter % size () == 0)) {
                std::cout << boost::format ("%5d") % iter;
                for (std::size_t i = 0; i < size (); ++i) {
                    std::cout << boost::format (" %.5f") % get_x (i);
                }
                std::cout << boost::format (" %15.5f") % get_minimum ()
                          << std::endl;
            }
        }
        return iter;
    }

};

#ifdef __MAIN
dbg::dbg_source MultiMinimizerFDF::dbgsrc = "MultiMinimizerFDF";
#endif // __MAIN

class Multimin_Function
{
public :
    gsl_multimin_function *ptrF;

    template <typename function_t>
    Multimin_Function( function_t & func )
    {
        ptrF = new gsl_multimin_function;
        ptrF->f = &function_gsl_f<function_t>;
        ptrF->n = func.size ();
        ptrF->params = static_cast<void *> (&func);
    }

    explicit
    Multimin_Function( Multimin_Function & f2 )
    {
        ptrF = new gsl_multimin_function;
        ptrF->f = f2.ptrF->f;
        ptrF->n = f2.ptrF->n;
        ptrF->params = f2.ptrF->params;
    }

    ~Multimin_Function ()
    {
        delete ptrF;
    }

    double operator()( const gsl_vector * x )
    {
        return (*(ptrF->f)) (x, ptrF->params);
    }

    std::size_t size( ) const
    {
        return ptrF->n;
    }
};

class MultiMinimizer
{
public :
    static dbg::dbg_source dbgsrc;
    enum multi_minimizer_type { nelder_mead };

    typedef const gsl_multimin_fminimizer_type * method_t;

    template <typename functor_t>
    explicit
    MultiMinimizer( functor_t & func, multi_minimizer_type mt = nelder_mead )
        : err_handler_ (gsl_set_error_handler_off ()),
          mmF_ (func)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        switch (mt) {
        case nelder_mead:
            method_ = gsl_multimin_fminimizer_nmsimplex;
            break;
        default:
            dbg::sentinel (dbg::error, dbgsrc, DBG_HERE);
            exit (GSL_EINVAL);
        }
        minimizer_ = gsl_multimin_fminimizer_alloc (method_, size ());
        if (!minimizer_) {
            std::cerr << "Unable to allocate memory for minimizer."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    MultiMinimizer( MultiMinimizer & m )
        : err_handler_ (gsl_set_error_handler_off ()),
          method_ (m.method_),
          mmF_ (m.mmF_)
    {
        minimizer_ = gsl_multimin_fminimizer_alloc (method_, size ());
        if (!minimizer_) {
            std::cerr << "Unable to allocate memory for minimizer."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    ~MultiMinimizer ()
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        gsl_multimin_fminimizer_free (minimizer_);
        gsl_set_error_handler (err_handler_);
    }

    const char *name () const
    {
        return gsl_multimin_fminimizer_name (minimizer_);
    }

    int minim( const gsl_vector * x,
               const gsl_vector * step_size,
               double tol = 1e-4,
               int maxiter = 10000,
               bool trace = true )
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        int status = gsl_multimin_fminimizer_set (minimizer_, mmF_.ptrF,
                                                  x, step_size);
        status = real_minim_ (trace, tol, maxiter);
        return status;
    }

    const gsl_vector *get_x(  ) const
    {
        return gsl_multimin_fminimizer_x (minimizer_);
    }

    double get_x( std::size_t i ) const
    {
        return gsl_vector_get (gsl_multimin_fminimizer_x (minimizer_), i);
    }

    double get_minimum( ) const
        {
        return gsl_multimin_fminimizer_minimum (minimizer_);
    }

    double get_test_size( ) const
    {
        return gsl_multimin_fminimizer_size (minimizer_);
    }

    std::size_t size( ) const
    {
        return mmF_.size ();
    }

private :
    gsl_multimin_fminimizer * minimizer_;
    gsl_error_handler_t * err_handler_;
    method_t method_;
    Multimin_Function mmF_;

    int real_minim_( bool trace, double tol, int maxiter )
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        int status = GSL_CONTINUE;
        for (int iter = 0; iter < maxiter && status == GSL_CONTINUE; ++iter) {
            status = gsl_multimin_fminimizer_iterate (minimizer_);
            if (status) {
                break;
            }
            status = gsl_multimin_test_size (get_test_size (), tol);
            if (status == GSL_SUCCESS && trace) {
                std::cout << "Minimum found at: " << std::endl;
            }
            if (status == GSL_SUCCESS || (trace && (iter % size () == 0))) {
                std::cout << boost::format ("%5d") % iter;
                for (std::size_t i = 0; i < size (); ++i) {
                    std::cout << boost::format (" %.5f")
                        % get_x (i);
                }
                std::cout << boost::format (" %15.5f %15.5f")
                    % get_minimum () % get_test_size () << std::endl;
            }
        }
        if (status != GSL_SUCCESS) {
            std::cerr << "Maximum number of iterations exceeded."
                      << std::endl;
        }
        return status;
    }

};

#ifdef __MAIN
dbg::dbg_source MultiMinimizer::dbgsrc = "MultiMinimizer";
#endif // __MAIN

} // namespace GSL


#endif /* _GSL_MULTIMIN_HPP */

