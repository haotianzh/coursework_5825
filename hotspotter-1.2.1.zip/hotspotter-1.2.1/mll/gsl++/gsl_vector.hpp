/**
 * @file   gsl_vector.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2003/02/21 05:31:29
 *
 * @brief
 *
 * $Id: gsl_vector.hpp,v 1.1 2003/02/21 20:03:03 nali Exp $
 */
#ifndef _GSL_VECTOR_HPP
#define _GSL_VECTOR_HPP 1

#include <gsl/gsl_vector.h>

namespace GSL
{

class DoubleVectorAdaptor
{
public:
    gsl_vector *vec;

    DoubleVectorAdaptor( double *v, size_t s )
    {
        vec = new gsl_vector;
        vec->data = v;
        vec->size = s;
        vec->stride = 1;
        vec->block = 0;
        vec->owner = 0;
    }

    ~DoubleVectorAdaptor( )
    {
        if (vec) {
            delete vec;
            vec = 0;
        }
    }
};

} // namespace GSL

#endif /* _GSL_VECTOR_HPP */

