/**
 * @file   gsl_diff.hpp
 * @author Michael Na Li
 * @date   Sun Mar 24 22:15:24 2002
 *
 * @brief Numerical differentiation of one-D function.
 *
 * $Id: gsl_diff.hpp,v 1.6 2003/01/22 22:06:18 nali Exp $
 */

#ifndef GSL_DIFF_HPP
#define GSL_DIFF_HPP

#include <gsl/gsl_errno.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_diff.h>

#include "dbg/dbg.hpp"
#include "gsl++/gsl_function.hpp"

#include <utility>
#include <iostream>
#include <iomanip>

namespace GSL
{

/**
 * The functor class Derivative defines the derivative of the
 * function.
 */
class Derivative
{
public :
    enum diff_method { central, forward, backward };
    static dbg::dbg_source dbgsrc;

    template <typename functor_type>
    explicit
    Derivative( functor_type & func, diff_method method = central )
        : F_ (func)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        choose_method_ (method);
    }

    explicit
    Derivative( double (*pfunc) (double, void*), void *params,
                diff_method method = central )
        : F_ (pfunc, params)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        choose_method_ (method);
    }

    double operator ()( double x )
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        double result = 0.0;
        ptr_gsl_diff (F_.ptrF, x, &result, &err_);
        dbg::out (dbg::tracing, dbgsrc) << "x = " << x
                                        << ", result = " << result
                                        << "\t, error = " << err_
                                        << std::endl;
        return result;
    }

    double get_err () const
    {
        return err_;
    }

private :

    Function F_;
    double err_;

    // a pointer to the gsl_diff_* functions.
    int (*ptr_gsl_diff) (const gsl_function *, double, double *, double *);

    void choose_method_ (diff_method method)
    {
        switch (method) {
        case central :
            ptr_gsl_diff = gsl_diff_central;
            break;
        case forward :
            ptr_gsl_diff = gsl_diff_forward;
            break;
        case backward :
            ptr_gsl_diff = gsl_diff_backward;
            break;
        default :
            std::cerr << "Invalid diff method: " << DBG_HERE
                      << std::endl;
            exit (GSL_EINVAL);
        }
    }
};

dbg::dbg_source Derivative::dbgsrc = "GSL::Derivative";

}       // namespace GSL

#endif // GSL_DIFF_HPP
