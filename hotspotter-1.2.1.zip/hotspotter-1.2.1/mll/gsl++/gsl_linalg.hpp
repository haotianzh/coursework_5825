/**
 * @file gsl_linalg.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   Tue, 23 Apr 2002 21:29:21 -0700
 *
 * @brief Conversion between GSL vector and matrix types.
 *
 *
 * $Id: gsl_linalg.hpp,v 1.1 2002/05/13 17:35:42 nali Exp $
 **/

#ifndef GSL_LINALG_HPP
#define GSL_LINALG_HPP

#include <gsl/gsl_vector.h>

namespace GSL
{

gsl_vector
mlltogsl (TNT::Vector<double> & vec)
{
    gsl_vector gvec;
    gvec.data   = &vec[0];
    gvec.stride = 1;
    gvec.size   = vec.size ();
    gvec.block  = 0;
    gvec.owner  = 0;
    return gvec;
}

gsl_vector_int
mlltogsl (TNT::Vector<int> & vec)
{
    gsl_vector_int gvec;
    gvec.data   = &vec[0];
    gvec.stride = 1;
    gvec.size   = vec.size ();
    gvec.block  = 0;
    gvec.owner  = 0;
    return gvec;
}

}

#endif // GSL_LINALG_HPP
