
#ifndef GSL_MIN_HPP
#define GSL_MIN_HPP

#include <gsl/gsl_errno.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_min.h>

#include "dbg/dbg.hpp"
#include "gsl++/gsl_function.hpp"
#include "boost/format.hpp"

#include <cmath>
#include <iostream>
#include <iomanip>

namespace GSL
{

class OneDMinimizer
{
public :

    static dbg::dbg_source dbgsrc;

    enum minimizer_type { goldensection, brent };

    typedef const gsl_min_fminimizer_type * method_type;

    explicit OneDMinimizer (minimizer_type mt)
        : err_handler_ (gsl_set_error_handler_off ())
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        switch (mt) {
        case goldensection :
            method_ = gsl_min_fminimizer_goldensection;
            break;
        case brent :
            method_ = gsl_min_fminimizer_brent;
            break;
        default :
            std::cerr << "Invalid minimizer type: " << DBG_HERE
                      << std::endl;
            exit (GSL_EINVAL);
        }
        minimizer_ = gsl_min_fminimizer_alloc (method_);
        if (!minimizer_) {
            std::cerr << "Unable to allocate memory for minimizer."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    OneDMinimizer (const OneDMinimizer & m)
        : err_handler_ (gsl_set_error_handler_off ())
    {
        method_ = m.method ();
        minimizer_ = gsl_min_fminimizer_alloc (method_);
        if (!minimizer_) {
            std::cerr << "Unable to allocate memory for minimizer."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    ~OneDMinimizer ()
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        gsl_min_fminimizer_free (minimizer_);
        gsl_set_error_handler (err_handler_);
    }

    const char *name () const
    {
        return gsl_min_fminimizer_name (minimizer_);
    }

    method_type method () const
    {
        return method_;
    }

    template <typename functor_type>
    double  minim (functor_type & func,
                   double minimum, double x_lower, double x_upper,
                   bool trace    = true,
                   double epsrel = 1.0e-7,
                   double epsabs = 1.0e-5,
                   int maxiter   = 60)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        Function F (func);
        return this->real_minim_ (F,
                                  minimum, x_lower, x_upper, trace,
                                  epsrel, epsabs, maxiter);
    }

    double minim (double (*pfunc) (double, void*),
                  void *params,
                  double minimum, double x_lower, double x_upper,
                  bool trace    = true,
                  double epsrel = 1.0e-7,
                  double epsabs = 1.0e-5,
                  int maxiter   = 60)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        Function F (pfunc, params);
        return this->real_minim_ (F,
                                  minimum, x_lower, x_upper, trace,
                                  epsrel, epsabs, maxiter);
    }

private :
    gsl_min_fminimizer * minimizer_;
    gsl_error_handler_t * err_handler_;
    method_type method_;

    double real_minim_( Function & F,
                        double xx, double ax, double bx,
                        bool trace, double epsrel, double epsabs,
                        int maxiter );

};

} // namespace GSL

#endif // GSL_MIN_HPP
