/**
 * @file   gsl_root.hpp
 * @author Michael Na Li
 * @date   Fri Mar 22 17:24:48 2002
 *
 * @brief  C++ Inteface to GSL One Dimension Root Finding Routines.
 *
 * \$Id: gsl_roots.hpp,v 1.7 2002/11/05 19:45:23 nali Exp $
 */

#ifndef GSL_ROOT_HPP
#define GSL_ROOT_HPP

#include <gsl/gsl_errno.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_roots.h>

#include "dbg/dbg.hpp"
#include "gsl++/gsl_function.hpp"

#include <cmath>
#include <iostream>
#include <iomanip>

namespace GSL
{

class RootSolver
{
public:
    enum fsolver_enum { bisection, falsepos, brent };
    static dbg::dbg_source dbgsrc;

    typedef const gsl_root_fsolver_type * method_type;

    explicit RootSolver (fsolver_enum st = brent)
        : solver_ (0)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        switch (st) {
        case bisection :
            method_ = gsl_root_fsolver_bisection;
            break;
        case falsepos :
            method_ = gsl_root_fsolver_falsepos;
            break;
        case brent :
            method_ = gsl_root_fsolver_brent;
            break;
        default :
            std::cerr << "Invalid solve type: " << DBG_HERE
                      << std::endl;
            exit (GSL_EINVAL);
        }
        solver_ = gsl_root_fsolver_alloc (method_);
        if (!solver_) {
            std::cerr << "Unable to allocate memory for solver."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    RootSolver (const RootSolver & rs)
    {
        method_ = rs.method ();
        solver_ = gsl_root_fsolver_alloc (method_);
        if (!solver_) {
            std::cerr << "Unable to allocate memory for solver."
                      << DBG_HERE << std::endl;
            exit (GSL_ENOMEM);
        }
    }

    ~RootSolver ()
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        gsl_root_fsolver_free (solver_);
    }

    const char *name () const
    {
        return gsl_root_fsolver_name (solver_);
    }

    method_type method () const
    {
        return method_;
    }

    /**
     * @brief Find an interval that brackets a root of a function.
     *
     * Given a function func and an initial guessed range x1 to x2, the routine
     * expands the range geometrically until a root is bracketed by the
     * returned values x1 and x2 (in which case zbrac returns 1) or until the
     * range becomes unacceptably large (in which case zbrac returns 0).
     *
     * \param gF      A pointer to gsl_function
     * \param x1
     * \param x2
     *
     * @return 0 if success
     */
    template <typename functor_type>
    static int
    bracket (functor_type & func, double *x1, double *x2, int maxtry = 60)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        static const double FACTOR = 1.618;
        if (*x1 == *x2) {
            GSL_ERROR ("Initial range has width 0.", GSL_EINVAL);
        }
        double f1 = func (*x1);
        double f2 = func (*x2);
        bool success = false;
        for (int j = 0; j < maxtry && !success; ++j) {
            if (f1 * f2 > 0.0) {
                if (std::abs (f1) < std::abs (f2)) {
                    f1 = func (*x1 += FACTOR * (*x1 - *x2));
                } else {
                    f2 = func (*x2 += FACTOR * (*x2 - *x1));
                }
            } else {
                success = true;
            }
        }
        return success ? 0 : 1;
    }

    template <typename functor_type>
    double solve (functor_type & func,
                  double xlo,
                  double xup,
                  bool trace = true,
                  double epsrel = 1.0e-7,
                  double epsabs = 1.0e-5,
                  int maxiter = 60)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        Function F (func);

        return real_root_ (F, xlo, xup, trace, epsrel, epsabs, maxiter);
    }

    double solve (double (*pfunc) (double, void*),
                  void *params,
                  double xlo,
                  double xup,
                  bool trace = true,
                  double epsrel = 1.0e-7,
                  double epsabs = 1.0e-5,
                  int maxiter = 60)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);

        Function F (pfunc, params);

        return real_root_ (F, xlo, xup, trace, epsrel, epsabs, maxiter);
    }

private:
    gsl_root_fsolver * solver_;
    method_type method_;

    double real_root_( Function & F,
                       double xlo, double xup,
                       bool trace,
                       double epsrel,
                       double epsabs,
                       int maxiter);

};

}     // namespace GSL

#endif // GSL_ROOT_HPP
