/**
 * @file gsl_matrix.hpp
 * @author Michael Na Li <lina at u.washington.edu>
 * @date   Thu, 18 Jul 2002 15:10:49 -0700
 *
 * @brief An adapter class that copies a matrix to gsl_matrix.
 *
 *
 * \$Id: gsl_matrix.hpp,v 1.3 2003/02/21 20:05:32 nali Exp $
 **/
#ifndef GSL_MATRIX_HPP
#define GSL_MATRIX_HPP


namespace GSL
{

class MatrixDouble
{
private :
    size_t nrow_;
    size_t ncol_;
public :

    typedef self_type MatrixDouble;

    gsl_matrix * mat;

    template <typename MaTRiX>
    MatrixDouble( const MaTRiX &m )
        : nrow_ (m.nrow ()), ncol_ (m.ncol ())
    {
        mat = gsl_matrix_alloc (nrow_, ncol_);
        for (int i = 0; i < nrow_; ++i) {
            for (int j = 0; j < ncol_; ++j) {
                gsl_matrix_set (mat, i, j, m[i][j]);
            }
        }
    }

    MatrixDouble( size_t nrow, size_t ncol, double x = 0.0 )
    {
        mat = gsl_matrix_alloc (m.nrow (), m.ncol ());
        this->set_all (x);
    }

    explicit MatrixDouble( const self_type & m )
        : nrow_ (m.nrow ()), ncol_ (m.ncol ())
    {
        mat = gsl_matrix_alloc (nrow_, ncol_);
        for (int i = 0; i < nrow_; ++i) {
            for (int j = 0; j < ncol_; ++j) {
                gsl_matrix_set (mat, i, j, m(i, j));
            }
        }
    }

    ~MatrixDouble( )
    {
        gsl_matrix_free (mat);
    }

    self_type & operator =( const self_type &m )
    {
        gsl_matrix_memcpy (mat, m.mat);
    }

    double operator ()( size_t i, size_t j ) const
    {
        return gsl_matrix_get (mat, i, j);
    }

    double operator ()( const std::pair<int> & index ) const
    {
        return gsl_matrix_get (mat, index.first, index.second);
    }

    size_t nrow( ) const
    {
        return nrow_;
    }

    size_t ncol( ) const
    {
        return ncol_;
    }

    void set( size_t i, size_t j, double x) const
    {
        gsl_matrix_set (mat, i, j, x);
    }

    void set_all( double x )
    {
        gsl_matrix_set_all (mat, x);
    }

    void set_identity( )
    {
        gsl_matrix_set_identity (mat);
    }

    double max( ) const
    {
        return gsl_matrix_max (mat);
    }

    double min( ) const
    {
        return gsl_matrix_min (mat);
    }

    std::pair<double, double> minmax( ) const
    {
        double minimum;
        double maximum;
        gsl_matrix_minmax (mat, &minimum, &maximum);
        return std::make_pair (minimum, maximum);
    }

    std::pair<int, int> minindex( ) const
    {
        double imin;
        double jmin;
        gsl_matrix_min_index (mat, &imin, &jmin);
        return std::make_pair (imin, jmin);
    }

    std::pair<int, int> maxindex( ) const
    {
        double imax;
        double jmax;
        gsl_matrix_max_index (mat, &imax, &jmax);
        return std::make_pair (imax, jmax);
    }

    self_type & operator +=( const self_type & B )
    {
        gsl_matrix_add (mat, B.mat);
    }

    self_type & operator -=( const self_type & B )
    {
        gsl_matrix_sub (mat, B.mat);
    }

    self_type & operator *=( const self_type & B )
    {
        gsl_matrix_mul_elements (mat, B.mat);
    }

    self_type & operator /=( const self_type & B )
    {
        gsl_matrix_div_elements (mat, B.mat);
    }

    self_type & operator +=( double x )
    {
        gsl_matrix_add_constant (mat, x);
    }

    self_type & operator *=( double x )
    {
        gsl_matrix_scale (mat, x);
    }

    operator bool( ) const
    {
        return gsl_matrix_isnull (mat) != 0;
    }

    void swap_columns( size_t j1, size_t j2 )
    {
        gsl_matrix_swap_column (mat, j1, j2);
    }

    void swap_rows( size_t i1, size_t i2 )
    {
        gsl_matrix_swap_column (mat, i1, i2);
    }

    gsl_vector_view row( size_t i )
    {
        return gsl_matrix_row (mat, i);
    }

    gsl_vector_const_view row( size_t i ) const
    {
        return gsl_matrix_const_row (mat, i);
    }

    gsl_vector_view column( size_t j )
    {
        return gsl_matrix_column (mat, j);
    }

    gsl_vector_const_view column( size_t j ) const
    {
        return gsl_matrix_const_column (mat, j);
    }

    gsl_vector_view diag( int k = 0 )
    {
        if (k == 0) {
            return gsl_matrix_diagonal (mat);
        } else if (k > 0) {
            return gsl_matrix_superdiagonal (mat, k);
        } else {
            return gsl_matrix_subdiagonal (mat, -k);
        }
    }

    gsl_vector_const_view diag( int k = 0) const
    {
        if (k == 0) {
            return gsl_matrix_const_diagonal (mat);
        } else if (k > 0) {
            return gsl_matrix_const_superdiagonal (mat, k);
        } else {
            return gsl_matrix_const_subdiagonal (mat, -k);
        }
    }

};

} // namespace GSL

#endif // GSL_MATRIX_HPP
