
#include <gsl/gsl_linalg.h>

class LU
{
private :

};
