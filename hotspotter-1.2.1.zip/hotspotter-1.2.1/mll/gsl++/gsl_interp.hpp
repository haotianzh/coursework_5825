/**
 * @file   gsl_interp.hpp
 * @author Michael Na Li <lina@u.washington.edu>
 * @date   2002/11/27 05:54:01
 *
 * @brief
 *
 * $Id: gsl_interp.hpp,v 1.1 2002/11/27 09:31:28 nali Exp $
 */
#ifndef _GSL_INTERP_HPP
#define _GSL_INTERP_HPP 1

#include "dbg/dbg.hpp"

#include <gsl/gsl_interp.h>
#include <gsl/gsl_spline.h>

namespace GSL
{

class Interpolation
{
public :
    enum interp_enum {
        linear,
        polynomial,
        cspline,
        cspline_periodic,
        akima,
        akima_periodic
    };
    static dbg::dbg_source dbgsrc;

    typedef const gsl_interp_type * method_type;

    explicit Interpolation( const double *xa,
                            const double *ya,
                            size_t s,
                            interp_enum it = cspline )
        : xa_ (xa), ya_ (ya), s_ (s)
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        switch (it) {
        case linear :
            method_ = gsl_interp_linear;
            break;
        case polynomial :
            method_ = gsl_interp_polynomial;
            break;
        case cspline :
            method_ = gsl_interp_cspline;
            break;
        case cspline_periodic :
            method_ = gsl_interp_cspline_periodic;
            break;
        case akima :
            method_ = gsl_interp_akima;
            break;
        case akima_periodic :
            method_ = gsl_interp_akima_periodic;
            break;
        default :
            // Shouldn't get here
            dbg::sentinel (dbg::error, dbgsrc, DBG_HERE);
        }

        interp_ = gsl_interp_alloc (method_, s_);
        accel_  = gsl_interp_accel_alloc ();
        gsl_interp_init (interp_, xa_, ya_, s_);
    }

    ~Interpolation ()
    {
        dbg::trace dtrace (dbgsrc, DBG_HERE);
        gsl_interp_free (interp_);
        gsl_interp_accel_free (accel_);
    }

    /**
     * Returns the name of the interpolation type.
     *
     * @return the name of the interpolation type.
     */
    const char *name( ) const
    {
        return gsl_interp_name (interp_);
    }

    /**
     * This function returns the minimum number of points required.  For
     * example, Akima spline interpolation requires a minimum of 5 points.
     *
     * @return the minimum number of points required
     */
    unsigned int min_size( ) const
    {
        return gsl_interp_min_size (interp_);
    }

    double operator()( double x ) const
    {
        return gsl_interp_eval (interp_, xa_, ya_, x, accel_);
    }

    double deriv( double x ) const
    {
        return gsl_interp_eval_deriv (interp_, xa_, ya_, x, accel_);
    }

    double deriv2( double x ) const
    {
        return gsl_interp_eval_deriv2 (interp_, xa_, ya_, x, accel_);
    }

    double integ( double A, double B ) const
    {
        return gsl_interp_eval_integ (interp_, xa_, ya_, A, B, accel_);
    }

private :
    gsl_interp *interp_;
    gsl_interp_accel *accel_;
    method_type method_;

    const double *xa_;
    const double *ya_;
    size_t s_;
};

dbg::dbg_source Interpolation::dbgsrc = "Interpolation";

} // namespace GSL

#endif /* _GSL_INTERP_HPP */

