/**
 * @file   gsl_roots.cpp
 * @author Michael Na Li
 * @date   Sun Jul  7 20:50:45 2002
 *
 * @brief  Implements gsl_roots.hpp
 *
 * \$Id: gsl_roots.cpp,v 1.2 2002/11/05 19:45:23 nali Exp $
 */

#include "gsl++/gsl_roots.hpp"

namespace GSL
{

dbg::dbg_source RootSolver::dbgsrc = "RootSolver";

double
RootSolver::real_root_( Function & F,
                        double xlo,
                        double xup,
                        bool trace,
                        double epsrel,
                        double epsabs,
                        int maxiter )
{
    dbg::trace dtrace (dbgsrc, DBG_HERE);

    gsl_root_fsolver_set (solver_, F.ptrF, xlo, xup);

    double root (0.0);
    int status = GSL_CONTINUE;
    if (trace) {
        std::cout << " Root finding with " << this->name ()
                  << " method.\n";
        std::cout << std::setw (5)  << "iter"  << " ["
                  << std::setw (12) << "lower" << ", "
                  << std::setw (12) << "upper" << "] "
                  << std::setw (12) << "root"  << " "
                  << std::setw (12) << "f (root)" << " "
                  << std::setw (12) << "err(est)" << std::endl;
    }
    for (int iter = 1; status == GSL_CONTINUE && iter <= maxiter; ++iter)
    {
        status = gsl_root_fsolver_iterate (solver_);
        if (status != 0) {
            if (status == GSL_EBADFUNC) {
                std::cerr << "A singular point is encountered in solve."
                          << std::endl;
            } else {
                std::cerr << "Other error in solve." << std::endl;
            }
            root = GSL_NAN;
            break;
        } else {
            root = gsl_root_fsolver_root (solver_);
            xlo  = gsl_root_fsolver_x_lower (solver_);
            xup  = gsl_root_fsolver_x_upper (solver_);
            status = gsl_root_test_interval (xlo, xup, epsrel, epsabs);

            if (status == GSL_SUCCESS && trace) {
                std::cerr << "Converged" << std::endl;
            } else if (status != GSL_CONTINUE) {
                std::cerr << "Some error in root solver."
                          << std::endl;
                root = GSL_NAN;
            } else if (iter >= maxiter) {
                std::cerr << "Maximum number of function evaluation "
                          << "exceeded in solve." << std::endl;
            }
        }
        if (trace) {
            std::cout << std::setw (5) << iter    << " [";
            std::cout.setf (std::ios::scientific);
            std::cout << std::setw (12) << std::setprecision (5)
                      << xlo << ", "
                      << std::setw (12) << std::setprecision (5)
                      << xup << "] "
                      << std::setw (12) << std::setprecision (5)
                      << root  << " "
                      << std::setw (12) << std::setprecision (5)
                      << F.eval_f (root)  << " "
                      << std::setw (12) << std::setprecision (5)
                      << xup - xlo << std::endl;
            std::cout.unsetf (std::ios::scientific);
        }
    }
    return root;
}

} // namespace GSL

// {{{ Log
/*
 * $Log: gsl_roots.cpp,v $
 * Revision 1.2  2002/11/05 19:45:23  nali
 * Updated dbgsrc.
 *
 * Revision 1.1  2002/07/08 04:23:34  nali
 * New cpp files.
 *
 */
// }}}
