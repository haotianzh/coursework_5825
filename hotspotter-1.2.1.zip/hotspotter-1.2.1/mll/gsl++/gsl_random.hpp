/**
 * @file   gsl_random.hpp
 * @author Michael Na Li
 * @date   Sun Jul  7 20:55:34 2002
 *
 * @brief  Interface to GSL random number generators
 *
 * \$Id: gsl_random.hpp,v 1.10 2003/02/21 20:04:19 nali Exp $
 */

#ifndef GSL_RANDOM_HPP
#define GSL_RANDOM_HPP

#include "gsl/gsl_rng.h"
#include "gsl/gsl_randist.h"
#include "dbg/dbg.hpp"
#include <string>
#include <vector>

namespace GSL
{

extern dbg::dbg_source rngdbgsrc;

#ifdef __MAIN
dbg::dbg_source rngdbgsrc = "RandomNumberGenerators";
#endif

class RandomGenerator
{
public:

    // Construction and Initializing:

    // Default args reads environment variable GSL_RNG_TYPE and GSL_RNG_SEED to
    // initialize. If these are not set the generator gsl_rng_mt19937 will be
    // used with seed 0.
    RandomGenerator (unsigned long int seed = 0,
                     const gsl_rng_type* type = 0)
        : _generator (0)
    {
        gsl_rng_env_setup();
        if (!type) {
            _generator = gsl_rng_alloc (gsl_rng_default);
        } else {
            _generator = gsl_rng_alloc (type) ;
        }
        gsl_rng_set (_generator, seed);
        _name = gsl_rng_name (_generator);
    }

    // copy constructor
    RandomGenerator (const RandomGenerator & r)
        : _generator (gsl_rng_clone (r._generator)),
          _name (r.name ())
    {}

    // destructor
    ~RandomGenerator ()
    {
        gsl_rng_free (_generator);
    }

    RandomGenerator & operator= (const RandomGenerator & r)
    {
        assert (r.name () == _name);
        gsl_rng_memcpy (_generator, r._generator);
        return *this;
    }

    void set_seed (unsigned long int seed)
    {
        gsl_rng_set (_generator, seed);
    }

    // Sampling:
    unsigned long int get ()
    {
        return gsl_rng_get (_generator);
    }

    // Information:

    const std::string & name () const
    {
        return _name;
    }

    unsigned long int max () const
    {
        return gsl_rng_max (_generator);
    }

    unsigned long int min () const
    {
        return gsl_rng_min (_generator);
    }

    gsl_rng* generator( )
    {
        return _generator;
    }

private:
    gsl_rng* _generator;
    std::string _name;

    friend class UniformRandomGenerator;
    friend class NormalRandomGenerator;
    friend class TruncatedNormalRandomGenerator;
    friend class GeneralDiscreteRandomGenerator;
    friend class ExponentialRandomGenerator;
};

template <typename T>
inline
void
shuffle( RandomGenerator & rng,
         std::vector<T> & source )
{
    gsl_ran_shuffle (rng.generator (), &source[0], source.size (), sizeof (T));
}

template <typename T>
inline
void
choose( RandomGenerator & rng,
        std::vector<T> & source,
        std::vector<T> & target,
        std::size_t K,
        bool keep_order )
{
    if (K == 0) {
        K = target.size ();
    }
    dbg::assertion (rngdbgsrc, DBG_ASSERTION (K <= source.size ()));
    dbg::assertion (rngdbgsrc, DBG_ASSERTION (K <= target.size ()));
    gsl_ran_choose (rng.generator (),
                    &target[0], K,
                    &source[0], source.size (), sizeof (T));
    if (!keep_order) {
        shuffle (rng, target);
    }
}

template <typename T>
inline
void
sample( RandomGenerator & rng,
        std::vector<T> & source,
        std::vector<T> & target,
        std::size_t K )
{
    if (K == 0) {
        K = target.size ();
    }
    dbg::assertion (rngdbgsrc, DBG_ASSERTION (K <= target.size ()));
    gsl_ran_sample (rng.generator (),
                    &target[0], K,
                    &source[0], source.size (), sizeof (T));
}

class UniformRandomGenerator
{
public :
    UniformRandomGenerator (RandomGenerator & baserng)
        : _baserng (baserng)
    {}

    unsigned long int operator () (unsigned long int Nmax)
    {
        return gsl_rng_uniform_int (_baserng._generator, Nmax);
    }

    double operator () () const
    {
        return gsl_rng_uniform (_baserng._generator);
    }

    double operator () (double a, double b) const
    {
        return gsl_ran_flat (_baserng._generator, a, b);
    }

    double get_positive () const
    {
        return gsl_rng_uniform_pos (_baserng._generator);
    }
private :
    RandomGenerator & _baserng;
};

class NormalRandomGenerator
{
public :
    NormalRandomGenerator (RandomGenerator & baserng,
                           double mu = 0.0, double sigma = 1.0)
        : _baserng (baserng), _mu (mu), _sigma (sigma)
    {}

    double operator () () const
    {
        return gsl_ran_gaussian (_baserng._generator, _sigma) + _mu;
    }

    double operator () (double mu, double sigma) const
    {
        return gsl_ran_gaussian (_baserng._generator, sigma) + mu;
    }
private :
    RandomGenerator & _baserng;
    double _mu;
    double _sigma;
};

class TruncatedNormalRandomGenerator
{
public :
    TruncatedNormalRandomGenerator (RandomGenerator & baserng,
                                    double tr = 0.0,
                                    double mu = 0.0,
                                    double sigma = 1.0)
        : _baserng (baserng), _tr (tr), _mu (mu), _sigma (sigma)
    {}

    double operator () () const
    {
        return gsl_ran_gaussian_tail (_baserng._generator, _tr - _mu, _sigma) +
            _mu;
    }

    double operator () (double tr, double mu, double sigma) const
    {
        return gsl_ran_gaussian_tail (_baserng._generator, tr - mu, sigma) +
            mu;
    }
private :
    RandomGenerator & _baserng;
    double _tr;
    double _mu;
    double _sigma;
};

class GeneralDiscreteRandomGenerator
{
public :

    GeneralDiscreteRandomGenerator (RandomGenerator & baserng,
                                    std::size_t psize, const double *p)
        : _baserng (baserng)
    {
        _table = gsl_ran_discrete_preproc (psize, p);
    }

    ~GeneralDiscreteRandomGenerator ()
    {
        gsl_ran_discrete_free (_table);
    }

    std::size_t operator () () const
    {
        return gsl_ran_discrete (_baserng._generator, _table);
    }

    void reset( std::size_t psize, const double *p )
    {
        dbg::trace dtrace (rngdbgsrc, DBG_HERE);
        gsl_ran_discrete_free (_table);
        _table = gsl_ran_discrete_preproc (psize, p);
    }

private :
    RandomGenerator   & _baserng;
    gsl_ran_discrete_t * _table;
};

class ExponentialRandomGenerator
{
public :
    ExponentialRandomGenerator (RandomGenerator & baserng, double mu = 1.0)
        : _baserng (baserng), _mu (mu)
    {}

    double operator () () const
    {
        return gsl_ran_exponential (_baserng._generator, _mu);
    }

    double operator () (double mu) const
    {
        return gsl_ran_exponential (_baserng._generator, mu);
    }
private :
    RandomGenerator & _baserng;
    double _mu;
};

}  // namespace GSL

#endif // GSL_RANDOM_HPP
