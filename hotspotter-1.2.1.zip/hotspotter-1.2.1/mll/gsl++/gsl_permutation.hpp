
#ifndef GSL_PERMUTATION_HPP
#define GSL_PERMUTATION_HPP

#include <gsl/gsl_permutation.h>

#include "dbg/dbg.hpp"

namespace GSL
{

class Permutation
{
public :

    explicit Permuation (size_t N)
    {
        p = gsl_permutation_calloc (N);
    }

    Permutation (const Permutation & p2)
    {
        p = gsl_permutation_alloc (p2.size ());
        for (int i = 0; i < this->size (); ++i) {
            p.data[i] = p2[i];
        }
    }

    ~Permutation ()
    {
        if (p) {
            gsl_permutation_free (p);
        }
    }

    size_t operator [] (size_t i) const
    {
        return gsl_permutation_get (p, i);
    }

    void swap (size_t i, size_t j)
    {
        gsl_permutation_swap (p, i, j);
    }

    size_t size ()
    {
        return gsl_permutation_size (p);
    }

    size_t *data ()
    {
        return gsl_permutation_data (p);
    }

    bool is_valid ()
    {
        return gsl_permutation_valid (p);
    }

    void reverse ()
    {
        gsl_permutation_reverse (p);
    }

    bool next ()
    {
        int status = gsl_permutation_next (p);
        return status == GSL_SUCCESS;
    }

    bool prev ()
    {
        int status = gsl_permutation_prev (p);
        return status == GSL_SUCCESS;
    }

    void inverse (Permutation * pinv)
    {
        gsl_permutation_inverse (pinv, p);
    }

    void permute (double *data, size_t stride, size_t N)
    {
        gsl_permute (p, data, stride, N);
    }

    void permute_inverse (double *data, size_t stride, size_t N)
    {
        gsl_permute_inverse (p, data, stride, N);
    }

    gsl_permuation * p;
};

} // GSL

#endif // GSL_PERMUTATION_HPP
